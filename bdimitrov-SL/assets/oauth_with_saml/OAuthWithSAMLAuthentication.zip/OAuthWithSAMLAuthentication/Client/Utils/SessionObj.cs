﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Client.Utils
{
    public class SessionObj
    {
        public string User { get; set; }

        public string SAMLToken { get; set; }
    }
}