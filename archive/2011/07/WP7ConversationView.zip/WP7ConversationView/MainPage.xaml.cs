﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Markup;

namespace WP7ConversationView
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();

      var stuff = XamlReader.Load(@"<c:MessageCollection 
                                        xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                                        xmlns:c='clr-namespace:WP7ConversationView;assembly=WP7ConversationView'>
                                      <c:Message Text='Hi, How are you?' Side='You'/>
                                      <c:Message Text='Pretty good thanks. How are things at your end?' Side='Me'/>
                                      <c:Message Text='The weather here is a bit grim' Side='Me'/>
                                      <c:Message Text='Aye, not bad here, a bit of sun' Side='You'/>
                                      <c:Message Text='Do you want to hear a joke?' Side='You'/>
                                      <c:Message Text='Go on then' Side='Me'/>
                                      <c:Message Text='Knock knock' Side='You'/>
                                      <c:Message Text='Whos there?' Side='Me'/>
                                      <c:Message Text='Doctor!' Side='You'/>
                                      <c:Message Text='Doctor who?' Side='Me'/>
                                      <c:Message Text='Doctor Who ... ha ha ROFLMAO' Side='You'/>
                                      <c:Message Text='genius. Pure genius' Side='Me'/>
                                    </c:MessageCollection>");
      this.DataContext = stuff;
    }
  }
}