﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;
using System.Windows.Resources;
using System.IO;
using System.Collections;

namespace SLUGUK.ViewModel
{
  public partial class FeedViewModel 
  {
    // Twitter search for #Silverlight
    private readonly string _twitterUrl = "http://search.twitter.com/search.atom?rpp=100&&q=%23Silverlight";

    private WebClient _webClient = new WebClient();

    private FeedItemViewModelCollection _feedItems = new FeedItemViewModelCollection();

    public FeedViewModel()
    {
      
    }
    
    /// <summary>
    /// Parses the response from our twitter request, creating a list of FeedItemViewModelinstances
    /// </summary>
    private void ParseXMLResponse(string xml)
    {
      var doc = XDocument.Parse(xml);
      var items = doc.Descendants(AtomConst.Entry)
                      .Select(entryElement => new FeedItemViewModel()
                      {
                        Title = entryElement.Descendants(AtomConst.Title).Single().Value,
                        Id = long.Parse(entryElement.Descendants(AtomConst.ID).Single().Value.Split(':')[2]),
                        Timestamp = DateTime.Parse(entryElement.Descendants(AtomConst.Published).Single().Value),
                        Author = entryElement.Descendants(AtomConst.Name).Single().Value
                      });

      _feedItems.Clear();
      foreach (var item in items)
      {
        _feedItems.Add(item);
      }
       
    }
      
    /// <summary>
    /// Gets the feed items
    /// </summary>
    public FeedItemViewModelCollection FeedItems
    {
      get { return _feedItems; }
      set { _feedItems = value; }
    }

    /// <summary>
    /// Gets a feed item by its Id
    /// </summary>
    public FeedItemViewModel GetFeedItem(long id)
    {
      return _feedItems.SingleOrDefault(item => item.Id == id);
    }
    
    /// <summary>
    /// Update the feed items
    /// </summary>
    public void Update()
    {
      _webClient.DownloadStringCompleted += (s, e) => ParseXMLResponse(e.Result);
      _webClient.DownloadStringAsync(new Uri(_twitterUrl));
      
      //ParseXMLResponse(ReadFileToString("data.xml"));
    }



    private string ReadFileToString(string filename)
    {

#if !SILVERLIGHT

      using (var stream = this.GetType().Assembly.GetManifestResourceStream(
        "SLUGUK.ViewModel." + filename))
      {
        StreamReader reader = new StreamReader(stream);
        string xml = reader.ReadToEnd();
        return xml;
      }

#else

      string path = "/SilverlightTwitterApp;component/ViewModel/" + filename;
      Uri uri = new Uri(path, UriKind.Relative);
      StreamResourceInfo sri = Application.GetResourceStream(uri);
      StreamReader reader = new StreamReader(sri.Stream);
      string xml = reader.ReadToEnd();
      return xml;

#endif
    }
  }
}
