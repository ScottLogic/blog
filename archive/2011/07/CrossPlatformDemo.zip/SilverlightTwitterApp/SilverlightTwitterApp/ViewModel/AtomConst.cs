﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace SLUGUK.ViewModel
{
  public static class AtomConst
  {
    private static string AtomNamespace = "http://www.w3.org/2005/Atom";

    public static XName Entry = XName.Get("entry", AtomNamespace);

    public static XName ID = XName.Get("id", AtomNamespace);

    public static XName Link = XName.Get("link", AtomNamespace);

    public static XName Published = XName.Get("published", AtomNamespace);

    public static XName Name = XName.Get("name", AtomNamespace);

    public static XName Title = XName.Get("title", AtomNamespace);
  }
}
