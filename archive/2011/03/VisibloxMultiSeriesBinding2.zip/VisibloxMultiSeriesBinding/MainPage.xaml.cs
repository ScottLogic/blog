﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using System.ComponentModel;
using Visiblox.Charts;

namespace VisibloxMultiSeriesBinding
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();

      // a collection of collections
      var harmonics = new List<List<Point>>();

      // plot each harmonic frequency
      for (int frequency = 1; frequency < 5 ;frequency++)
      {
        // create the upper and lower component
        var upperHarmonic = new List<Point>();
        var lowerHarmonic = new List<Point>();
        for (double phase = 0; phase < Math.PI; phase+= (Math.PI / 100))
        {
          upperHarmonic.Add(new Point(phase, Math.Sin(phase * frequency) + frequency * 2.5));
          lowerHarmonic.Add(new Point(phase, Math.Sin(phase * frequency + Math.PI) + frequency * 2.5));
        }

        // add each to the collection
        harmonics.Add(upperHarmonic);
        harmonics.Add(lowerHarmonic);
      }

      this.DataContext = harmonics;      
    }

  }


}
