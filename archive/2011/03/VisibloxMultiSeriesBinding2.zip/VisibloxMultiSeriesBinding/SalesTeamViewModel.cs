﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace VisibloxMultiSeriesBinding
{
  public class SalesTeamViewModel
  {
    public string TeamName { get; set; }

    public ObservableCollection<SalesInRegionViewModel> TeamSales { get; set; }

    public SalesTeamViewModel()
    {
      TeamSales = new ObservableCollection<SalesInRegionViewModel>();
    }

    public double this[string indexer]
    {
      get
      {
        return TeamSales.Single(p => p.Region == indexer).Sales;
      }
      set
      {
        TeamSales.Single(p => p.Region == indexer).Sales = value;
      }
    }
  }
}
