﻿using System;
using Visiblox.Charts;

namespace VisibloxMultiSeriesBinding
{
  /// <summary>
  /// A ChartTypeProvider that always returns the Visiblox series
  /// type that was supplied in the constructor.
  /// </summary>
  public class DefaultChartTypeProvider : IChartTypeProvider
  {
    private Type _seriesType;

    public DefaultChartTypeProvider(Type seriesType)
    {
      _seriesType = seriesType;
    }

    public IChartSeries GetSeries(object boundObject)
    {
      var ctr = _seriesType.GetConstructor(new Type[] { });
      return (IChartSeries)ctr.Invoke(new object[] { });
    }
  }
}
