﻿using System.ComponentModel;
using Visiblox.Charts;

namespace VisibloxMultiSeriesBinding
{
  /// <summary>
  /// An interface for providing Visiblox chart series.
  /// </summary>
  [TypeConverter(typeof(StringToChartTypeProvider))]
  public interface IChartTypeProvider
  {
    /// <summary>
    /// Creates a suitable chart series for the given data
    /// </summary>
    IChartSeries GetSeries(object boundObject);
  }
}
