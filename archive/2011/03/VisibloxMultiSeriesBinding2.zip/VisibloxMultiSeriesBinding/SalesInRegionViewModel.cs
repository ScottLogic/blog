﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace VisibloxMultiSeriesBinding
{
  public class SalesInRegionViewModel : INotifyPropertyChanged
  {
    private string _region;

    private double _sales;

    public double Sales
    {
      get { return _sales; }
      set
      {
        if (_sales == value)
          return;
        _sales = value;
        OnPropertyChanged("Sales");
      }
    }

    public string Region
    {
      get { return _region; }
      set
      {
        if (_region == value)
          return;
        _region = value;
        OnPropertyChanged("Region");
      }
    }


    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }
  }
}
