﻿using System.Windows.Controls;
using System.Collections.ObjectModel;
using Visiblox.Charts;

namespace VisibloxMultiSeriesBinding
{
  public partial class SalesExample : UserControl
  {
    private CompanySalesViewModel _viewModel;

    public SalesExample()
    {
      _viewModel = new CompanySalesViewModel()
      {
        SalesTeams = new ObservableCollection<SalesTeamViewModel>()
        {
          new SalesTeamViewModel()
          {
            TeamName = "Alpha",
            TeamSales = new ObservableCollection<SalesInRegionViewModel>()
            {
              new SalesInRegionViewModel()
              {
                Region = "US",
                Sales = 12.4
              },
              new SalesInRegionViewModel()
              {
                Region = "UK",
                Sales = 7.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Germany",
                Sales = 8.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Japan",
                Sales = 3.2
              }
            }
          },
          new SalesTeamViewModel()
          {
            TeamName = "Beta",
            TeamSales = new ObservableCollection<SalesInRegionViewModel>()
            {
              new SalesInRegionViewModel()
              {
                Region = "US",
                Sales = 25.4
              },
              new SalesInRegionViewModel()
              {
                Region = "UK",
                Sales = 17.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Germany",
                Sales = 7.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Japan",
                Sales = 3.4
              }
            }
          },
          new SalesTeamViewModel()
          {
            TeamName = "Gamma",
            TeamSales = new ObservableCollection<SalesInRegionViewModel>()
            {
              new SalesInRegionViewModel()
              {
                Region = "US",
                Sales = 35.4
              },
              new SalesInRegionViewModel()
              {
                Region = "UK",
                Sales = 7.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Germany",
                Sales = 6.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Japan",
                Sales = 8.4
              }
            }
          },
          new SalesTeamViewModel()
          {
            TeamName = "Target",
            TeamSales = new ObservableCollection<SalesInRegionViewModel>()
            {
              new SalesInRegionViewModel()
              {
                Region = "US",
                Sales = 17.4
              },
              new SalesInRegionViewModel()
              {
                Region = "UK",
                Sales = 45.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Germany",
                Sales = 44.4
              },
              new SalesInRegionViewModel()
              {
                Region = "Japan",
                Sales = 32.4
              }
            }
          }
        }
      };

      this.DataContext = _viewModel;

      InitializeComponent();
    }
  }

  public class SalesTypeProvider : IChartTypeProvider
  {
    public IChartSeries GetSeries(object boundObject)
    {
      var viewModel = boundObject as SalesTeamViewModel;
      if (viewModel.TeamName == "Target")
        return new LineSeries();
      else
        return new ColumnSeries();
    }
  }
}
