﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using Visiblox.Charts;
using System.Windows.Data;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;

namespace VisibloxMultiSeriesBinding
{
  public static class MultiSeries
  {
    #region XValuePath attached property

    /// <summary>
    /// Identified the XValuePath attached property
    /// </summary>
    public static readonly DependencyProperty XValuePathProperty =
        DependencyProperty.RegisterAttached("XValuePath", typeof(string), typeof(MultiSeries),
            new PropertyMetadata(""));

    /// <summary>
    /// Gets the value of the XValuePath property
    /// </summary>
    public static string GetXValuePath(DependencyObject d)
    {
      return (string)d.GetValue(XValuePathProperty);
    }

    /// <summary>
    /// Sets the value of the XValuePath property
    /// </summary>
    public static void SetXValuePath(DependencyObject d, string value)
    {
      d.SetValue(XValuePathProperty, value);
    }

    #endregion

    #region YValuePath attached property

    /// <summary>
    /// Identified the YValuePath attached property
    /// </summary>
    public static readonly DependencyProperty YValuePathProperty =
        DependencyProperty.RegisterAttached("YValuePath", typeof(string), typeof(MultiSeries),
            new PropertyMetadata(""));

    /// <summary>
    /// Gets the value of the YValuePath property
    /// </summary>
    public static string GetYValuePath(DependencyObject d)
    {
      return (string)d.GetValue(YValuePathProperty);
    }

    /// <summary>
    /// Sets the value of the YValuePath property
    /// </summary>
    public static void SetYValuePath(DependencyObject d, string value)
    {
      d.SetValue(YValuePathProperty, value);
    }

    #endregion

    #region ChartTypeProvider attached property

    /// <summary>
    /// Identified the ChartTypeProvider attached property
    /// </summary>
    public static readonly DependencyProperty ChartTypeProviderProperty =
        DependencyProperty.RegisterAttached("ChartTypeProvider", typeof(IChartTypeProvider), typeof(MultiSeries),
            new PropertyMetadata(null));

    /// <summary>
    /// Gets the value of the ChartTypeProvider property
    /// </summary>
    public static IChartTypeProvider GetChartTypeProvider(DependencyObject d)
    {
      return (IChartTypeProvider)d.GetValue(ChartTypeProviderProperty);
    }

    /// <summary>
    /// Sets the value of the ChartType property
    /// </summary>
    public static void SetChartTypeProvider(DependencyObject d, IChartTypeProvider value)
    {
      d.SetValue(ChartTypeProviderProperty, value);
    }

    #endregion

    #region Source attached property

    /// <summary>
    /// Identified the Source attached property
    /// </summary>
    public static readonly DependencyProperty SourceProperty =
        DependencyProperty.RegisterAttached("Source", typeof(IEnumerable), typeof(MultiSeries),
            new PropertyMetadata("", new PropertyChangedCallback(OnSourcePropertyChanged)));

    /// <summary>
    /// Gets the value of the Source property
    /// </summary>
    public static IEnumerable GetSource(DependencyObject d)
    {
      return (IEnumerable)d.GetValue(SourceProperty);
    }

    /// <summary>
    /// Sets the value of the Source property
    /// </summary>
    public static void SetSource(DependencyObject d, IEnumerable value)
    {
      d.SetValue(SourceProperty, value);
    }

    /// <summary>
    /// Handles property changed event for the Source property
    /// </summary>
    private static void OnSourcePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      Chart targetChart = d as Chart;

      SynchroniseChartWithSource(targetChart);

      IEnumerable Source = GetSource(targetChart);
      INotifyCollectionChanged incc = Source as INotifyCollectionChanged;
      if (incc != null)
      {
        incc.CollectionChanged += (s, e2) => SynchroniseChartWithSource(targetChart);
      }

    }

    #endregion

    #region TitlePath attached property

    /// <summary>
    /// Identified the TitlePath attached property
    /// </summary>
    public static readonly DependencyProperty TitlePathProperty =
        DependencyProperty.RegisterAttached("TitlePath", typeof(string), typeof(MultiSeries),
            new PropertyMetadata(""));

    /// <summary>
    /// Gets the value of the TitlePath property
    /// </summary>
    public static string GetTitlePath(DependencyObject d)
    {
      return (string)d.GetValue(TitlePathProperty);
    }

    /// <summary>
    /// Sets the value of the TitlePath property
    /// </summary>
    public static void SetTitlePath(DependencyObject d, string value)
    {
      d.SetValue(TitlePathProperty, value);
    }

    #endregion

    #region ItemsSourcePath attached property

    /// <summary>
    /// Identified the ItemsSourcePath attached property
    /// </summary>
    public static readonly DependencyProperty ItemsSourcePathProperty =
        DependencyProperty.RegisterAttached("ItemsSourcePath", typeof(string), typeof(MultiSeries),
            new PropertyMetadata(""));

    /// <summary>
    /// Gets the value of the ItemsSourcePath property
    /// </summary>
    public static string GetItemsSourcePath(DependencyObject d)
    {
      return (string)d.GetValue(ItemsSourcePathProperty);
    }

    /// <summary>
    /// Sets the value of the ItemsSourcePath property
    /// </summary>
    public static void SetItemsSourcePath(DependencyObject d, string value)
    {
      d.SetValue(ItemsSourcePathProperty, value);
    }

    #endregion

    private static void SynchroniseChartWithSource(Chart chart)
    {
      chart.Series.Clear();

      IEnumerable Source = GetSource(chart);
      if (Source == null)
        return;

      // iterate over each source series
      foreach (object seriesDataSource in Source)
      {
        // create a visiblox chart series
        IChartSeries chartSeries = GetChartTypeProvider(chart).GetSeries(seriesDataSource);

        // resolve the ItemsSource path (if present).
        var itemsSourcePath = GetItemsSourcePath(chart);
        IEnumerable itemsSource = null;
        if (!string.IsNullOrEmpty(itemsSourcePath))
        {
          itemsSource = seriesDataSource.GetPropertyValue<IEnumerable>(itemsSourcePath);
        }
        else
        {
          // if not present, assume this is a collection of collections
          itemsSource = seriesDataSource as IEnumerable;
        }

        // resolve the title path
        var titlePath = GetTitlePath(chart);
        var seriesTitle = "";
        if (!string.IsNullOrEmpty(titlePath))
        {
          seriesTitle = seriesDataSource.GetPropertyValue<string>(titlePath);
        }

        // create the data series, and add to the chart.
        chartSeries.DataSeries = new BindableDataSeries()
        {
          XValueBinding = new Binding(GetXValuePath(chart)),
          YValueBinding = new Binding(GetYValuePath(chart)),
          ItemsSource = itemsSource,
          Title = seriesTitle
        };
        chart.Series.Add(chartSeries);
      }
    }

    /// <summary>
    /// Gets the value of the named property.
    /// </summary>
    public static T GetPropertyValue<T>(this object source, string propertyName)
    {
      var property = source.GetType().GetProperty(propertyName);
      if (property == null)
      {
        throw new ArgumentException(string.Format("The property {0} does not exist on the type {1}",
          propertyName, source.GetType()));
      }
      return (T)property.GetValue(source, null);
    }
  }

}
