﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace VisibloxMultiSeriesBinding
{
  /// <summary>
  /// A type converter that converts a string into a FixedChartTypeProvider. For example
  /// "LineSeries" is converted into a FixedChartTypeProvider which
  /// always returns Visblox.Chart.LineSeries instances
  /// </summary>
  public class StringToChartTypeProvider : TypeConverter
  {
    public override object ConvertFrom(ITypeDescriptorContext context,
      CultureInfo culture, object value)
    {
      if (value is string)
      {
        // find the type using the assembly qualified name.
        var seriesType = Type.GetType("Visiblox.Charts." + value.ToString()
          + ", Visiblox.Charts, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
        return new DefaultChartTypeProvider(seriesType);
      }
      return base.ConvertFrom(context, culture, value);
    }

    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
    {
      if (sourceType == typeof(string))
        return true;

      return base.CanConvertFrom(context, sourceType);
    }
  }
}
