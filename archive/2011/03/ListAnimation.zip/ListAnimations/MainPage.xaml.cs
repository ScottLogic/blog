﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using LinqToVisualTree;
using System.Diagnostics;
using System.Xml.Linq;

namespace ListAnimations
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
      
      WebClient client = new WebClient();
      client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
      client.DownloadStringAsync(new Uri("http://feeds.bbci.co.uk/news/rss.xml"), bbcNews);

      client = new WebClient();
      client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
      client.DownloadStringAsync(new Uri("http://www.scottlogic.co.uk/blog/colin/feed/"), colinE);
      
    }

    private void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      var rssFeed = XElement.Parse(e.Result);
      var items = rssFeed.Descendants("channel").Descendants("item").Select(el => new RssItem
      {
        Title = el.Element("title").Value,
        Summary = el.Element("description").Value,
        Date = el.Element("pubDate").Value
      });

      var list = e.UserState as ItemsControl;
      list.ItemsSource = items;

    }
    
  }

  public class RssItem
  {
    public string Title { get; set; }
    public string Summary { get; set; }
    public string Date { get; set; }
  }
}