//
//  appcacheAppDelegate.h
//  appcache
//
//  Created by Chris Price on 03/06/2011.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"
#import "SDURLCache.h"

@interface appcacheAppDelegate : PhoneGapDelegate {
}

@end

