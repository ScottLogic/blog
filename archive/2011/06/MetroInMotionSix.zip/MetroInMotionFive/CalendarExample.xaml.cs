﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace MetroInMotionFive
{
  public partial class CalendarExample : PhoneApplicationPage
  {
    public CalendarExample()
    {
      InitializeComponent();

      Random rand = new Random();

      var people = PersonDataSource.CreateList(50);

      var now = DateTime.Now;
      DateTime time = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0);

      var appointments = people.Select(p => new Appointment()
      {
        Title = string.Format(_appointmentTypes[rand.Next(_appointmentTypes.Length-1)], p.Surname, p.Forename),
        Time = time.AddHours(rand.Next(100))
      });

      this.DataContext = appointments.OrderBy(a => a.Time);
    }

    private static string[] _appointmentTypes = new string[]
    {
      "Lunch with {1}",
      "Interview {0}, {1}",
      "Meeting with {0}",
      "Book holiday",
      "Sleep"
    };

    public class Appointment
    {
      public DateTime Time { get; set; }
      public string Title { get; set; }
    }
  }
}