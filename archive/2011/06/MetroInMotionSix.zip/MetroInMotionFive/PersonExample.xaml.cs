﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using LinqToVisualTree;
using System.Windows.Data;
using System.Windows.Controls.Primitives;
using System.Diagnostics;
using System.ComponentModel;
using System.Xml.Linq;

namespace MetroInMotionFive
{
  public partial class PersonExample : PhoneApplicationPage
  {
    // Constructor
    public PersonExample()
    {
      InitializeComponent();
      
      var items = PersonDataSource.CreateList(100).OrderBy(s => s.Surname.Substring(0,1).ToUpper()).ToList();
      this.DataContext = items;

    }


  }
}