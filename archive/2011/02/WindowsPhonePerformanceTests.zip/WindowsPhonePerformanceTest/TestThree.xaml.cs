﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;

namespace WindowsPhonePerformanceTest
{
  public partial class TestThree : PhoneApplicationPage
  {
    public TestThree()
    {
      InitializeComponent();
      
      this.LayoutUpdated += new EventHandler(TestOne_LayoutUpdated);
      this.Loaded += new RoutedEventHandler(TestOne_Loaded);
    }


    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      int count = int.Parse(NavigationContext.QueryString["count"]);
      buttonCount.Text = count.ToString();

      for (int i = 0; i < count; i++)
      {
        buttonContainer.Children.Add(new Button()
        {
          Content = "One"
        });
      }
    } 

    void TestOne_Loaded(object sender, RoutedEventArgs e)
    {
      ((App)Application.Current).OutputTimestamp("TestOne_Loaded");
    }

    void TestOne_LayoutUpdated(object sender, EventArgs e)
    {
      ((App)Application.Current).OutputTimestamp("TestOne_LayoutUpdated");
    }
  }
}