using System;
using System.Linq;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Collections.Specialized;


namespace RssReader
{
    public class RssReaderViewModel
    {

        private AddRangeObservableCollection<FeedItemViewModel> _latestItems =
            new AddRangeObservableCollection<FeedItemViewModel>();

        private AddRangeObservableCollection<FeedItemViewModel> _favouriteItems =
            new AddRangeObservableCollection<FeedItemViewModel>();


        public RssReaderViewModel()
        {
            Feeds = new ObservableCollection<FeedViewModel>() {
               new FeedViewModel() { FeedName = "The Silverlight Blog",
                   ParentModel = this,
                   FeedUrl = "http://feeds.feedburner.com/TheSilverlightBlog?format=xml"},
            new FeedViewModel() { FeedName = "MSDN UK Team",
                 ParentModel = this,
                   FeedUrl = "http://blogs.msdn.com/b/ukmsdn/rss.aspx"},
            new FeedViewModel() { FeedName = "Windows Phone Developer Blog",
                 ParentModel = this,
                   FeedUrl = "http://windowsteamblog.com/windows_phone/b/wpdev/rss.aspx"},
            new FeedViewModel() { FeedName = "Scottish Developers",
                 ParentModel = this,
                   FeedUrl = "http://scottishdevelopers.com/feed/"},
                   new FeedViewModel() { FeedName = "Google SightSeeing",
                        ParentModel = this,
                   FeedUrl = "http://feeds.feedburner.com/GoogleSightseeing/"},
                   new FeedViewModel() { FeedName = "Coding Horror",
                        ParentModel = this,
                   FeedUrl = "http://feeds.feedburner.com/codinghorror"}            
            };

        }

        internal void UpdateLatestItems()
        {
            // update the latest items
            var latest = new ObservableCollection<FeedItemViewModel>();
            foreach (var item in Feeds.SelectMany(f => f.Items)
                                    .OrderByDescending(i => i.DatePublished)
                                    .Take(30))
            {
                latest.Add(item);
            }
            LatestItems.Clear();
            LatestItems.AddRange(latest);
        }

        public AddRangeObservableCollection<FeedItemViewModel> LatestItems
        {
            get { return _latestItems; }
            set { _latestItems = value; NotifyPropertyChanged("LatestItems"); }
        }

        public AddRangeObservableCollection<FeedItemViewModel> FavouriteItems
        {
            get { return _favouriteItems; }
            set { _favouriteItems = value; NotifyPropertyChanged("FavouriteItems"); }
        }

        public ObservableCollection<FeedViewModel> Feeds { get; private set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        internal void UpdateFavourites()
        {
            // update the latest items
            var favs = new ObservableCollection<FeedItemViewModel>();
            foreach (var item in Feeds.SelectMany(f => f.Items)
                                    .Where(i => i.Favourite))
            {
                favs.Add(item);
            }
            FavouriteItems.Clear();
            FavouriteItems.AddRange(favs);
        }
    }
}