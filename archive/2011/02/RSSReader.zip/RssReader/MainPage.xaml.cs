﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;

namespace RssReader
{
    public partial class MainPage : PhoneApplicationPage
    {
        object _selectedItem;
        RssReaderViewModel model;

        public MainPage()
        {
            InitializeComponent();
            SupportedOrientations = SupportedPageOrientation.Portrait;
            Loaded += new RoutedEventHandler(MainPage_Loaded);
            PageTransitionList.Completed += new EventHandler(PageTransitionList_Completed);

            model = new RssReaderViewModel();
            DataContext = model;

            foreach (var feed in model.Feeds)
            {
                feed.LoadFeed();
            }


        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            this.ListBoxOne.SelectedIndex = -1;
            this.ListBoxTwo.SelectedIndex = -1;
            this.ListBoxThree.SelectedIndex = -1;
        }

        private void PageTransitionList_Completed(object sender, EventArgs e)
        {
            if (navigateToArticle)
            {
                // Set datacontext of details page to selected listbox item
                NavigationService.Navigate(new Uri("/FeedItemDetailsPage.xaml", UriKind.Relative));
                
            }
            else
            {
                // Set datacontext of details page to selected listbox item
                NavigationService.Navigate(new Uri("/FeedDetailsPage.xaml", UriKind.Relative));
            };

            FrameworkElement root = Application.Current.RootVisual as FrameworkElement;
            root.DataContext = _selectedItem;
        }
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Reset page transition
            ResetPageTransitionList.Begin();

        }

        private bool navigateToArticle = false;

        private void ListBoxOne_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Capture selected item data
            _selectedItem = (sender as ListBox).SelectedItem;
            if (_selectedItem == null)
                return;

            navigateToArticle = false;

            // Start page transition animation
            PageTransitionList.Begin();
        }

        private void lstLatestItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Capture selected item data
            var selectedItem = (sender as ListBox).SelectedItem as FeedItemViewModel;
            if (selectedItem == null)
                return;

            selectedItem.ParentFeed.CurrentFeedItem = selectedItem;
            _selectedItem = selectedItem.ParentFeed;

            // Start page transition animation
            navigateToArticle = true;
            PageTransitionList.Begin();
        }
        
    }
}