﻿//dedicated to maestros

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Device.Location;
using System.Windows.Media.Imaging;

namespace googlemaps
{
    public partial class MainPage : PhoneApplicationPage
    {
        public List<MessierObject> _messierObjects = new List<MessierObject>()
        {
             new MessierObject() { Name = "M1", Coords = new GeoCoordinate(22.01447, 96.36687), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Crab_Nebula.jpg/60px-Crab_Nebula.jpg"}, 
             new MessierObject() { Name = "M2", Coords = new GeoCoordinate(-0.82333, -143.3625), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Messier_2_Hubble_WikiSky.jpg/60px-Messier_2_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M3", Coords = new GeoCoordinate(28.37544, -25.54679), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/73/M3LRGB_891x674.jpg/60px-M3LRGB_891x674.jpg"}, 
             new MessierObject() { Name = "M4", Coords = new GeoCoordinate(-26.52553, -65.89754), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Messier_4_Hubble_WikiSky.jpg/60px-Messier_4_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M5", Coords = new GeoCoordinate(2.08269, -49.64062), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Messier_5_Hubble_WikiSky.jpg/60px-Messier_5_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M6", Coords = new GeoCoordinate(-32.2, -85.07), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/M6a.jpg/60px-M6a.jpg"}, 
             new MessierObject() { Name = "M7", Coords = new GeoCoordinate(-34.78, -88.45), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Open-cluster-Messier-7.jpeg/60px-Open-cluster-Messier-7.jpeg"}, 
             new MessierObject() { Name = "M8", Coords = new GeoCoordinate(-24.387, -90.904), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/76/LagoonHunterWilson.jpg/60px-LagoonHunterWilson.jpg"}, 
             new MessierObject() { Name = "M9", Coords = new GeoCoordinate(-18.51625, -79.79908), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Messier_object_009.jpg/60px-Messier_object_009.jpg"}, 
             new MessierObject() { Name = "M10", Coords = new GeoCoordinate(-4.09933, -74.28746), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Messier_10_Hubble_WikiSky.jpg/60px-Messier_10_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M11", Coords = new GeoCoordinate(-6.27, -102.75), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Messier11.jpg/60px-Messier11.jpg"}, 
             new MessierObject() { Name = "M12", Coords = new GeoCoordinate(-1.94781, -71.8105), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/50/M12_Hubble.jpg/60px-M12_Hubble.jpg"}, 
             new MessierObject() { Name = "M13", Coords = new GeoCoordinate(36.461319, -70.423475), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Messier_13_Hubble_WikiSky.jpg/60px-Messier_13_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M14", Coords = new GeoCoordinate(-3.24592, -84.40062), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Messier_object_014.jpg/60px-Messier_object_014.jpg"}, 
             new MessierObject() { Name = "M15", Coords = new GeoCoordinate(12.16683, -142.49325), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Messier_15_Hubble_WikiSky.jpg/60px-Messier_15_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M16", Coords = new GeoCoordinate(-13.82, -94.7), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/97/Stellar_spire_eagle_nebula.jpg/30px-Stellar_spire_eagle_nebula.jpg"}, 
             new MessierObject() { Name = "M17", Coords = new GeoCoordinate(-16.177, -95.108), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Messier_17.jpg/60px-Messier_17.jpg"}, 
             new MessierObject() { Name = "M18", Coords = new GeoCoordinate(-17.1, -95), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Messier18.jpg/60px-Messier18.jpg"}, 
             new MessierObject() { Name = "M19", Coords = new GeoCoordinate(-26.26794, -75.65704), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Messier_object_019.jpg/60px-Messier_object_019.jpg"}, 
             new MessierObject() { Name = "M20", Coords = new GeoCoordinate(-23.03, -90.596), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Trifid.nebula.arp.750pix.jpg/60px-Trifid.nebula.arp.750pix.jpg"}, 
             new MessierObject() { Name = "M21", Coords = new GeoCoordinate(-22.48, -91.05), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/28/Messier_object_021.jpg/60px-Messier_object_021.jpg"}, 
             new MessierObject() { Name = "M22", Coords = new GeoCoordinate(-23.90339, -99.10087), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Messier_object_022.jpg/60px-Messier_object_022.jpg"}, 
             new MessierObject() { Name = "M23", Coords = new GeoCoordinate(-18.98, -89.25), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Messier_object_023.jpg/60px-Messier_object_023.jpg"}, 
             new MessierObject() { Name = "M24", Coords = new GeoCoordinate(-18.55, -94.2), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Messier_024_2MASS.jpg/60px-Messier_024_2MASS.jpg"}, 
             new MessierObject() { Name = "M25", Coords = new GeoCoordinate(-19.12, -97.92), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Messier_object_025.jpg/60px-Messier_object_025.jpg"}, 
             new MessierObject() { Name = "M26", Coords = new GeoCoordinate(-9.38, -101.32), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Messier_object_026.jpg/60px-Messier_object_026.jpg"}, 
             new MessierObject() { Name = "M27", Coords = new GeoCoordinate(22.721042, -119.901579), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Messier27.jpg/60px-Messier27.jpg"}, 
             new MessierObject() { Name = "M28", Coords = new GeoCoordinate(-24.86983, -96.13704), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/04/Messier28.jpg/60px-Messier28.jpg"}, 
             new MessierObject() { Name = "M29", Coords = new GeoCoordinate(38.523, -125.983), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Messier_object_029.jpg/60px-Messier_object_029.jpg"}, 
             new MessierObject() { Name = "M30", Coords = new GeoCoordinate(-23.17906, -145.09179), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/13/Messier_object_030.jpg/60px-Messier_object_030.jpg"}, 
             new MessierObject() { Name = "M31", Coords = new GeoCoordinate(41.26875, 169.315292), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Andromeda_galaxy.jpg/60px-Andromeda_galaxy.jpg"}, 
             new MessierObject() { Name = "M32", Coords = new GeoCoordinate(40.86589, 169.32554), Thumb="http://upload.wikimedia.org/wikipedia/en/thumb/5/5d/M32.jpg/60px-M32.jpg"}, 
             new MessierObject() { Name = "M33", Coords = new GeoCoordinate(30.659942, 156.5379), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/M33.jpg/60px-M33.jpg"}, 
             new MessierObject() { Name = "M34", Coords = new GeoCoordinate(42.77, 139.47), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/M34_2mass_atlas.jpg/60px-M34_2mass_atlas.jpg"}, 
             new MessierObject() { Name = "M35", Coords = new GeoCoordinate(24.35, 87.72), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/12/M35atlas.jpg/60px-M35atlas.jpg"}, 
             new MessierObject() { Name = "M36", Coords = new GeoCoordinate(34.14, 95.95), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/M29a.jpg/60px-M29a.jpg"}, 
             new MessierObject() { Name = "M37", Coords = new GeoCoordinate(32.553, 91.921), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/46/M37a.jpg/60px-M37a.jpg"}, 
             new MessierObject() { Name = "M38", Coords = new GeoCoordinate(35.855, 97.821), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Messier_object_038.jpg/60px-Messier_object_038.jpg"}, 
             new MessierObject() { Name = "M39", Coords = new GeoCoordinate(48.45, -142.95), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Messier_object_039.jpg/60px-Messier_object_039.jpg"}, 
             new MessierObject() { Name = "M40", Coords = new GeoCoordinate(58.08, -5.59999999999999), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Messier_object_40.jpg/60px-Messier_object_40.jpg"}, 
             new MessierObject() { Name = "M41", Coords = new GeoCoordinate(-20.77, 78.5), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Messier_041_2MASS.jpg/60px-Messier_041_2MASS.jpg"}, 
             new MessierObject() { Name = "M42", Coords = new GeoCoordinate(-5.3911, 96.1779), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Orion_Nebula_-_Hubble_2006_mosaic_18000.jpg/60px-Orion_Nebula_-_Hubble_2006_mosaic_18000.jpg"}, 
             new MessierObject() { Name = "M43", Coords = new GeoCoordinate(-5.27, 96.121), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Messier_object_043.jpg/60px-Messier_object_043.jpg"}, 
             new MessierObject() { Name = "M44", Coords = new GeoCoordinate(19.68, 49.9), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Messier_044_2MASS.jpg/60px-Messier_044_2MASS.jpg"}, 
             new MessierObject() { Name = "M45", Coords = new GeoCoordinate(24.12, 123.15), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Bob_Star_-_M45_Carranza_Field_%28by%29.jpg/60px-Bob_Star_-_M45_Carranza_Field_%28by%29.jpg"}, 
             new MessierObject() { Name = "M46", Coords = new GeoCoordinate(-14.82, 64.57), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/M46a.jpg/60px-M46a.jpg"}, 
             new MessierObject() { Name = "M47", Coords = new GeoCoordinate(-14.48, 65.85), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/55/M47a.jpg/60px-M47a.jpg"}, 
             new MessierObject() { Name = "M48", Coords = new GeoCoordinate(-5.75, 56.57), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/66/M48a.jpg/60px-M48a.jpg"}, 
             new MessierObject() { Name = "M49", Coords = new GeoCoordinate(8.000411, -7.44499200000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Messier_49_Hubble_WikiSky.jpg/60px-Messier_49_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M50", Coords = new GeoCoordinate(-8.377, 74.3), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/M50a.jpg/60px-M50a.jpg"}, 
             new MessierObject() { Name = "M51", Coords = new GeoCoordinate(47.195258, -22.469575), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Whirlpool_%28M51%29.jpg/60px-Whirlpool_%28M51%29.jpg"}, 
             new MessierObject() { Name = "M52", Coords = new GeoCoordinate(61.58, -171.2), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/M52atlas.jpg/60px-M52atlas.jpg"}, 
             new MessierObject() { Name = "M53", Coords = new GeoCoordinate(18.16917, -18.23042), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Globular_Cluster_M53.jpg/60px-Globular_Cluster_M53.jpg"}, 
             new MessierObject() { Name = "M54", Coords = new GeoCoordinate(-30.4785, -103.76367), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Messier54.jpg/60px-Messier54.jpg"}, 
             new MessierObject() { Name = "M55", Coords = new GeoCoordinate(-30.96208, -114.9975), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Messier55.jpg/60px-Messier55.jpg"}, 
             new MessierObject() { Name = "M56", Coords = new GeoCoordinate(30.1845, -109.14792), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/97/M56-LRGB.jpg/60px-M56-LRGB.jpg"}, 
             new MessierObject() { Name = "M57", Coords = new GeoCoordinate(33.029175, -103.396163), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Ring_Nebula.jpg/60px-Ring_Nebula.jpg"}, 
             new MessierObject() { Name = "M58", Coords = new GeoCoordinate(11.81789, -9.43117000000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/M58s.jpg/60px-M58s.jpg"}, 
             new MessierObject() { Name = "M59", Coords = new GeoCoordinate(11.646931, -10.509675), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/04/Messier59.jpg/60px-Messier59.jpg"}, 
             new MessierObject() { Name = "M60", Coords = new GeoCoordinate(11.552611, -10.9167), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Messier_object_060.jpg/60px-Messier_object_060.jpg"}, 
             new MessierObject() { Name = "M61", Coords = new GeoCoordinate(4.473589, -5.47895800000001), Thumb="http://upload.wikimedia.org/wikipedia/en/thumb/b/b7/M61.jpg/60px-M61.jpg"}, 
             new MessierObject() { Name = "M62", Coords = new GeoCoordinate(-30.11236, -75.3025), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Messier_object_062.jpg/60px-Messier_object_062.jpg"}, 
             new MessierObject() { Name = "M63", Coords = new GeoCoordinate(42.029289, -18.955537), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Messier_63_GALEX_WikiSky.jpg/60px-Messier_63_GALEX_WikiSky.jpg"}, 
             new MessierObject() { Name = "M64", Coords = new GeoCoordinate(21.682658, -14.182067), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Blackeyegalaxy.jpg/60px-Blackeyegalaxy.jpg"}, 
             new MessierObject() { Name = "M65", Coords = new GeoCoordinate(13.092211, 10.266846), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/47/M65.jpg/60px-M65.jpg"}, 
             new MessierObject() { Name = "M66", Coords = new GeoCoordinate(12.991289, 9.93739199999999), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Sig05-016.jpg/60px-Sig05-016.jpg"}, 
             new MessierObject() { Name = "M67", Coords = new GeoCoordinate(11.8, 47.175), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Messier_object_067.jpg/60px-Messier_object_067.jpg"}, 
             new MessierObject() { Name = "M68", Coords = new GeoCoordinate(-26.74303, -9.86671000000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Messier_object_068.jpg/60px-Messier_object_068.jpg"}, 
             new MessierObject() { Name = "M69", Coords = new GeoCoordinate(-32.34797, -97.84679), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Messier_object_069.jpg/60px-Messier_object_069.jpg"}, 
             new MessierObject() { Name = "M70", Coords = new GeoCoordinate(-32.29189, -100.80267), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Messier70.jpg/60px-Messier70.jpg"}, 
             new MessierObject() { Name = "M71", Coords = new GeoCoordinate(18.77842, -118.44212), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Messier71.jpg/60px-Messier71.jpg"}, 
             new MessierObject() { Name = "M72", Coords = new GeoCoordinate(-12.53706, -133.36629), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Messier72.jpg/60px-Messier72.jpg"}, 
             new MessierObject() { Name = "M73", Coords = new GeoCoordinate(-12.63, -134.75), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Messier73.jpg/60px-Messier73.jpg"}, 
             new MessierObject() { Name = "M74", Coords = new GeoCoordinate(15.783461, 155.82595), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/NGC_628.jpg/60px-NGC_628.jpg"}, 
             new MessierObject() { Name = "M75", Coords = new GeoCoordinate(-21.922261, -121.520171), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Messier75.jpg/60px-Messier75.jpg"}, 
             new MessierObject() { Name = "M76", Coords = new GeoCoordinate(51.575319, 154.416883), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/M76-RL5-DDmin-Gamma-LRGB_883x628.jpg/60px-M76-RL5-DDmin-Gamma-LRGB_883x628.jpg"}, 
             new MessierObject() { Name = "M77", Coords = new GeoCoordinate(-0.013289, 139.330121), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/18/NGC1068-hst-R658GB814.jpg/60px-NGC1068-hst-R658GB814.jpg"}, 
             new MessierObject() { Name = "M78", Coords = new GeoCoordinate(0.0139, 93.3054), Thumb=""}, 
             new MessierObject() { Name = "M79", Coords = new GeoCoordinate(-24.52425, 98.95588), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/M79a.jpg/60px-M79a.jpg"}, 
             new MessierObject() { Name = "M80", Coords = new GeoCoordinate(-22.97511, -64.26046), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/A_Swarm_of_Ancient_Stars_-_GPN-2000-000930.jpg/60px-A_Swarm_of_Ancient_Stars_-_GPN-2000-000930.jpg"}, 
             new MessierObject() { Name = "M81", Coords = new GeoCoordinate(69.065295, 31.111779), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Sig07-009.jpg/60px-Sig07-009.jpg"}, 
             new MessierObject() { Name = "M82", Coords = new GeoCoordinate(69.68022, 31.03254), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Messier82.jpg/60px-Messier82.jpg"}, 
             new MessierObject() { Name = "M83", Coords = new GeoCoordinate(-29.865761, -24.253829), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/M83g.jpg/60px-M83g.jpg"}, 
             new MessierObject() { Name = "M84", Coords = new GeoCoordinate(12.886983, -6.26559700000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Messier84a.jpg/60px-Messier84a.jpg"}, 
             new MessierObject() { Name = "M85", Coords = new GeoCoordinate(18.191081, -6.350221), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Messier_85_Hubble_WikiSky.jpg/60px-Messier_85_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M86", Coords = new GeoCoordinate(12.945969, -6.54922500000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Messier_86_Hubble_WikiSky.jpg/60px-Messier_86_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M87", Coords = new GeoCoordinate(12.391123, -7.70593099999999), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/39/M87_jet.jpg/60px-M87_jet.jpg"}, 
             new MessierObject() { Name = "M88", Coords = new GeoCoordinate(14.420411, -7.99673300000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Messier_object_088.jpg/60px-Messier_object_088.jpg"}, 
             new MessierObject() { Name = "M89", Coords = new GeoCoordinate(12.556039, -8.91618299999999), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Messier_object_089.jpg/60px-Messier_object_089.jpg"}, 
             new MessierObject() { Name = "M90", Coords = new GeoCoordinate(13.162869, -9.20756700000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Messier_object_090.jpg/60px-Messier_object_090.jpg"}, 
             new MessierObject() { Name = "M91", Coords = new GeoCoordinate(14.496319, -8.86012500000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Messier91.jpg/60px-Messier91.jpg"}, 
             new MessierObject() { Name = "M92", Coords = new GeoCoordinate(43.13653, -79.28029), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Globular_Cluster_M92.JPG/60px-Globular_Cluster_M92.JPG"}, 
             new MessierObject() { Name = "M93", Coords = new GeoCoordinate(-23.87, 63.85), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Messier_object_093.jpg/60px-Messier_object_093.jpg"}, 
             new MessierObject() { Name = "M94", Coords = new GeoCoordinate(41.120153, -12.72145), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Messier_object_094.jpg/60px-Messier_object_094.jpg"}, 
             new MessierObject() { Name = "M95", Coords = new GeoCoordinate(11.703611, 19.009446), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Messier95_spitzer.jpg/60px-Messier95_spitzer.jpg"}, 
             new MessierObject() { Name = "M96", Coords = new GeoCoordinate(11.819939, 18.3094), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Messier_object_096.jpg/60px-Messier_object_096.jpg"}, 
             new MessierObject() { Name = "M97", Coords = new GeoCoordinate(55.019028, 11.301108), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/M97_FTN.jpg/60px-M97_FTN.jpg"}, 
             new MessierObject() { Name = "M98", Coords = new GeoCoordinate(14.900469, -3.45121700000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/2/21/M-98.jpg/60px-M-98.jpg"}, 
             new MessierObject() { Name = "M99", Coords = new GeoCoordinate(14.416489, -4.706771), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/M99.jpg/60px-M99.jpg"}, 
             new MessierObject() { Name = "M100", Coords = new GeoCoordinate(15.822381, -5.728746), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Spiral_Galaxy_M100.jpg/60px-Spiral_Galaxy_M100.jpg"}, 
             new MessierObject() { Name = "M101", Coords = new GeoCoordinate(54.34808, -30.80212), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/M101_hires_STScI-PRC2006-10a.jpg/60px-M101_hires_STScI-PRC2006-10a.jpg"}, 
             new MessierObject() { Name = "M102", Coords = new GeoCoordinate(55.763308, -46.623171), Thumb=""}, 
             new MessierObject() { Name = "M103", Coords = new GeoCoordinate(60.65, 156.65), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Messier_object_103.jpg/60px-Messier_object_103.jpg"}, 
             new MessierObject() { Name = "M104", Coords = new GeoCoordinate(-11.623054, -9.99763300000001), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/M104_ngc4594_sombrero_galaxy_hi-res.jpg/60px-M104_ngc4594_sombrero_galaxy_hi-res.jpg"}, 
             new MessierObject() { Name = "M105", Coords = new GeoCoordinate(12.581631, 18.043333), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Messier_object_105.jpg/60px-Messier_object_105.jpg"}, 
             new MessierObject() { Name = "M106", Coords = new GeoCoordinate(47.303719, -4.740083), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Messier_106_by_Spitzer.jpg/60px-Messier_106_by_Spitzer.jpg"}, 
             new MessierObject() { Name = "M107", Coords = new GeoCoordinate(-13.05364, -68.13296), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Messier_object_107.jpg/60px-Messier_object_107.jpg"}, 
             new MessierObject() { Name = "M108", Coords = new GeoCoordinate(55.674122, 12.120971), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Messier_108_Hubble_WikiSky.jpg/60px-Messier_108_Hubble_WikiSky.jpg"}, 
             new MessierObject() { Name = "M109", Coords = new GeoCoordinate(53.374519, 0.600066999999996), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Messier_object_109.jpg/60px-Messier_object_109.jpg"}, 
             new MessierObject() { Name = "M110", Coords = new GeoCoordinate(41.6853, 169.908021), Thumb="http://upload.wikimedia.org/wikipedia/commons/thumb/4/43/M110_Lanoue.png/60px-M110_Lanoue.png"}, 
        };


        // Constructor
        public MainPage()
        {
            InitializeComponent();

            MessierObjects.ItemsSource = _messierObjects;

            map.SetView(_messierObjects[74].Coords, 11);
        }

        private void ButtonZoomIn_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            map.ZoomLevel++;
        }

        private void ButtonZoomOut_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            map.ZoomLevel--;
        }

        private void Grid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var messier = ((FrameworkElement)sender).DataContext as MessierObject;

            map.SetView(messier.Coords, 11);
        }
    }



    public class MessierObject
    {
        public string Name { get; set; }
        public string Thumb { get; set; }
        public GeoCoordinate Coords { get; set; }

        public object ThumbSource
        {
            get
            {
                return new BitmapImage(new Uri((string)Thumb));
            }
        }
    }


    public class GoogleTile : Microsoft.Phone.Controls.Maps.TileSource
    {
        public GoogleTile()
        {
            UriFormat = @"http://mw1.google.com/mw-planetary/sky/skytiles_v1/{0}_{1}_{2}.jpg";
        }

        public override Uri GetUri(int x, int y, int zoomLevel)
        {
            if (zoomLevel > 0)
            {
                var Url = string.Format(UriFormat, x, y, zoomLevel);
                return new Uri(Url);
            }
            return null;
        }
    }
}