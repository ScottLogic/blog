﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;

namespace WindowsPhoneMVVMExample.ViewModel
{
  public static class AtomConst
  {
    private static string AtomNamespace = "http://www.w3.org/2005/Atom";

    public static XName Entry = XName.Get("entry", AtomNamespace);

    public static XName ID = XName.Get("id", AtomNamespace);

    public static XName Link = XName.Get("link", AtomNamespace);

    public static XName Published = XName.Get("published", AtomNamespace);

    public static XName Name = XName.Get("name", AtomNamespace);

    public static XName Title = XName.Get("title", AtomNamespace);
  }

  public class FeedViewModel 
  {
    // Twitter search for #WP7
    private readonly string _twitterUrl = "http://search.twitter.com/search.atom?rpp=100&&q=%23wp7";

    private WebClient _webClient = new WebClient();

    private readonly ObservableCollection<FeedItemViewModel> _feedItems = new ObservableCollection<FeedItemViewModel>();

    public FeedViewModel()
    {
      _webClient.DownloadStringCompleted += WebClient_DownloadStringCompleted;
    }

    /// <summary>
    /// Parses the response from our twitter request, creating a list of FeedItemViewModelinstances
    /// </summary>
    private void WebClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      var doc = XDocument.Parse(e.Result);
      var items = doc.Descendants(AtomConst.Entry)
                      .Select(entryElement => new FeedItemViewModel()
                      {
                        Title = entryElement.Descendants(AtomConst.Title).Single().Value,
                        Id = long.Parse(entryElement.Descendants(AtomConst.ID).Single().Value.Split(':')[2]),
                        Timestamp = DateTime.Parse(entryElement.Descendants(AtomConst.Published).Single().Value),
                        Author = entryElement.Descendants(AtomConst.Name).Single().Value
                      });

      _feedItems.Clear();
      foreach (var item in items)
      {
        _feedItems.Add(item);
      }
    }

    /// <summary>
    /// Gets the feed items
    /// </summary>
    public ObservableCollection<FeedItemViewModel> FeedItems
    {
      get { return _feedItems; }
    }

    /// <summary>
    /// Gets a feed item by its Id
    /// </summary>
    public FeedItemViewModel GetFeedItem(long id)
    {
      return _feedItems.SingleOrDefault(item => item.Id == id);
    }
    
    /// <summary>
    /// Update the feed items
    /// </summary>
    public void Update()
    {
      _webClient.DownloadStringAsync(new Uri(_twitterUrl));
    }
  }
}
