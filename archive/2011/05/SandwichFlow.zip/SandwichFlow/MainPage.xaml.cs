﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Resources;
using System.Xml.Linq;
using System.IO;
using MetroInMotionUtils;
using JumpListControl;
using LinqToVisualTree;

namespace SandwichFlow
{
  public partial class MainPage : PhoneApplicationPage
  {
    private ItemFlyInAndOutAnimations _flyOutAnimation = new ItemFlyInAndOutAnimations();
    
    // Constructor
    public MainPage()
    {
      this.Loaded += new RoutedEventHandler(MainPage_Loaded);
      InitializeComponent();
    }

    void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      Dispatcher.BeginInvoke(() => _flyOutAnimation.ItemFlyIn());
    }

    private void SandwichesJumpList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      JumpList jumpList = sender as JumpList;
      if (jumpList.SelectedItem == null)
        return;

      var selectedItem = jumpList.SelectedItem as Sandwich;
      jumpList.SelectedItem = null;


      // grab the Title element
      var exitAnimationElement = jumpList.Descendants()
                                        .OfType<TextBlock>()
                                        .Where(el => el.DataContext == selectedItem)
                                        .Where(el => el.Name == "Title")
                                        .Single();      

      if (exitAnimationElement != null)
      {
        // animate the element, navigating to the new page when the animation finishes
        _flyOutAnimation.ItemFlyOut(this, exitAnimationElement, () =>
        {
          NavigationService.Navigate(new Uri("/SandwichRecipe.xaml?id=" +
            selectedItem.Id.ToString(), UriKind.Relative));
        });
      } 
    }

    private void KeywordsJumpList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      JumpList jumpList = sender as JumpList;
      if (jumpList.SelectedItem == null)
        return;

      var selectedItem = jumpList.SelectedItem as Keyword;
      jumpList.SelectedItem = null;
      
      // grab the Title element
      var exitAnimationElement = jumpList.Descendants()
                                        .OfType<TextBlock>()
                                        .Where(el => el.DataContext == selectedItem)
                                        .Where(el => el.Name == "Title")
                                        .Single();

      if (exitAnimationElement != null)
      {
        // animate the element, navigating to the new page when the animation finishes
        _flyOutAnimation.ItemFlyOut(this, exitAnimationElement, () =>
        {
          NavigationService.Navigate(new Uri("/KeywordPage.xaml?id=" +
           selectedItem.Id.ToString(), UriKind.Relative));
        });
      }
    }
  }
}