﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.Diagnostics;

namespace MidAxis
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            var chartRelay = new ChartAxesEventRelay(Chart, AxisEventEnumeration.ActualRangeEffectiveLimitsChanged | AxisEventEnumeration.ValueConversion);
            chartRelay.AxisEvent += RepositionAxesEvent;
            Chart.SizeChanged += RepositionAxesEvent;
            Chart.Loaded += Chart_Loaded;

            AddSeries(x => Math.Sin(x));
        }

        private void Chart_Loaded(object sender, RoutedEventArgs e)
        {
            Chart.ApplyTemplate();
            RepositionAxes();
            Chart.XAxis.Element.SizeChanged += RepositionAxesEvent;
            Chart.YAxis.Element.SizeChanged += RepositionAxesEvent;
        }

        private void AddSeries(Func<double,double> f)
        {
            var ds = new DataSeries<double, double>();
            for (double x = -10; x <= 10; x += 0.01)
            {
                ds.Add(new DataPoint<double, double>(x, f(x))); ;
            }
            Chart.Series.Add(new LineSeries { DataSeries = ds });
        }

        private void RepositionAxesEvent(object sender, EventArgs e)
        {
            RepositionAxes();
        }

        /// <summary>
        /// Position axes appropriately - axes need to be repositioned after changes in the axis ranges,
        /// or the rendered layout (eg chart or axis size).
        /// </summary>
        private void RepositionAxes()
        {
            if (Chart.YAxis == null || Chart.XAxis == null) { return; }
            var yAxisContainer = VisualTreeHelper.GetParent(Chart.YAxis.Element) as FrameworkElement;
            var xAxisContainer = VisualTreeHelper.GetParent(Chart.XAxis.Element) as FrameworkElement;

            if (yAxisContainer == null || xAxisContainer == null) { return; }

            var xPos = Chart.XAxis.GetDataValueAsRenderPositionWithZoom(0.0);
            //var yPos = Chart.YAxis.GetDataValueAsRenderPositionWithZoom(0.0);
            var yPos = Chart.YAxis.GetDataValueAsRenderPositionWithZoom(0.0);
            yPos = Math.Min(yPos, yAxisContainer.ActualHeight - xAxisContainer.ActualHeight);

            //Canvas.SetLeft(yAxisContainer,  Math.Floor(xPos)+0.5 - yAxisContainer.ActualWidth);
            //Canvas.SetTop(xAxisContainer, (Math.Floor(yPos) + 0.5));
            Canvas.SetLeft(yAxisContainer, Math.Floor(xPos) + 0.5 - yAxisContainer.ActualWidth);
            Canvas.SetTop(xAxisContainer, (Math.Floor(yPos) + 0.5));
        }
    }
}
