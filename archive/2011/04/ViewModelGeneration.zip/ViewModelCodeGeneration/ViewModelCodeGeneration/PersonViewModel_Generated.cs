





using System.ComponentModel;

namespace ViewModelCodeGeneration
{
  public partial class PersonViewModel  
  {
	
    #region INotifyPropertyChanged Members

    /// <summary>
    /// Occurs when a property changes
    /// </summary>
    public event PropertyChangedEventHandler  PropertyChanged;

    /// <summary>
    /// Raises a PropertyChanged event
    /// </summary>
    protected void OnPropertyChanged(string property)
    {
	    if (PropertyChanged != null)
	    {
		    PropertyChanged(this, new PropertyChangedEventArgs(property));
	    }
    }

    #endregion
    

    /// <summary>
    /// Field which backs the Surname property
    /// </summary>
    private string _surname = null;

    public static readonly string SurnameProperty = "Surname";
				
    /// <summary>
    /// Gets / sets the Surname value
    /// </summary>
    public string Surname
    {
	    get { return _surname; }
	    set
	    {
		    if (_surname == value)
			    return;
			
		    _surname = value;
        
        OnSurnameChanged(value);
		
		    OnPropertyChanged(SurnameProperty);
	    }
    }
    
    /// <summary>
    /// Invoked when the value of Surname changes
    /// </summary>
    partial void OnSurnameChanged(string value);
    

    /// <summary>
    /// Field which backs the Forename property
    /// </summary>
    private string _forename = null;

    public static readonly string ForenameProperty = "Forename";
				
    /// <summary>
    /// Gets / sets the Forename value
    /// </summary>
    public string Forename
    {
	    get { return _forename; }
	    set
	    {
		    if (_forename == value)
			    return;
			
		    _forename = value;
        
        OnForenameChanged(value);
		
		    OnPropertyChanged(ForenameProperty);
	    }
    }
    
    /// <summary>
    /// Invoked when the value of Forename changes
    /// </summary>
    partial void OnForenameChanged(string value);
    	}
}
	