﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Snippets;
using System.ComponentModel;


namespace ViewModelCodeGeneration
{
  [SnippetINotifyPropertyChanged]
  [SnippetPropertyINPC(field = "_surname", type = "string", property = "Surname")]
  [SnippetPropertyINPC(field = "_forename", type = "string", property = "Forename")]
  public partial class PersonViewModel : INotifyPropertyChanged
  {
    public static readonly string FullNameProperty = "FullName";

    partial void OnForenameChanged(string value)
    {
      OnPropertyChanged(FullNameProperty);
    }

    partial void OnSurnameChanged(string value)
    {
      OnPropertyChanged(FullNameProperty);
    }

    public string FullName
    {
      get
      {
        return Surname + ", " + Forename;
      }
    }
  }
}
