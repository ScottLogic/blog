﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using LinqToVisualTree;
using System.Diagnostics;
using System.Xml.Linq;
using System.ComponentModel;
using MetroInMotionUtils;
using System.Windows.Data;
using System.Windows.Controls.Primitives;
using System.Windows.Media.Imaging;

namespace ListAnimations
{
  public partial class MainPage : PhoneApplicationPage
  {
    private ItemFlyInAndOutAnimations _flyOutAnimation = new ItemFlyInAndOutAnimations();

    // Constructor
    public MainPage()
    {
      InitializeComponent();
      
      WebClient client = new WebClient();
      client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
      client.DownloadStringAsync(new Uri("http://feeds.bbci.co.uk/news/rss.xml"), bbcNews);

      client = new WebClient();
      client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
      client.DownloadStringAsync(new Uri("http://www.scottlogic.co.uk/blog/colin/feed/"), colinE);

      this.Loaded += MainPage_Loaded;
    }

    private void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
      Dispatcher.BeginInvoke(() => _flyOutAnimation.ItemFlyIn() );
    }

    private void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      var rssFeed = XElement.Parse(e.Result);
      var items = rssFeed.Descendants("channel").Descendants("item").Select(el => new RssItem
      {
        Title = el.Element("title").Value,
        Summary = el.Element("description").Value,
        Date = el.Element("pubDate").Value
      });

      var list = e.UserState as ItemsControl;
      list.ItemsSource = items;

    }
    
    protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
    {
      e.Cancel = true;

      // obtain the list from the current pivot item - and the items currently visible in this list
      var listInView = ((PivotItem)pivot.SelectedItem).Descendants().OfType<ItemsControl>().Single();
      var listItems = listInView.GetItemsInView().ToList();

      // locate the pivot control  header
      var header = this.Descendants().OfType<FrameworkElement>().Single(d => d.Name == "HeadersListElement");
      
      // create the list of items to peel
      var peelList = new FrameworkElement[] { TitlePanel, header }.Union(listItems);
      
      peelList.Peel(() =>
        {
          App.Quit();
        });

      base.OnBackKeyPress(e);
    }


    private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ListBox list = sender as ListBox;

      // find the selected ListBoxItem
      var selectedContainer = list.ItemContainerGenerator.ContainerFromItem(list.SelectedItem);

      // grab the Title element
      var exitAnimationElement = selectedContainer.Descendants()
                                                  .OfType<FrameworkElement>()
                                                  .SingleOrDefault(el => el.Name == "Title");

      if (exitAnimationElement != null)
      {
        // animate the element, navigating to the new page when the animation finishes
        _flyOutAnimation.ItemFlyOut(exitAnimationElement, () =>
          {
            FrameworkElement root = Application.Current.RootVisual as FrameworkElement;
            root.DataContext = list.SelectedItem;
            NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.Relative));
          });
      }     
    }

  }

  public class RssItem
  {
    public string Title { get; set; }
    public string Summary { get; set; }
    public string Date { get; set; }
  }
}