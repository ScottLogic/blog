﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Diagnostics;

namespace NavigationList
{
  public partial class ListBoxExample : PhoneApplicationPage
  {
    private bool _loadTimed = false;

    public ListBoxExample()
    {
      InitializeComponent();

      this.DataContext = ((FrameworkElement)Application.Current.RootVisual).DataContext;

      this.Loaded += Page_Loaded;
    }

    private void Page_Loaded(object sender, RoutedEventArgs e)
    {
      if (_loadTimed)
        return;

      long end = System.Environment.TickCount;
      long start = ((App)Application.Current).Timestamp;
      ApplicationTitle.Text = string.Format("Page Render Time {0}ms", end - start);

      _loadTimed = true;
    }


    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      // reset selection so that the same item can be re-selected
      navigationListBox.SelectedItem = null;      
    }

    

    private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (navigationListBox.SelectedItem == null)
        return;

      // pass the datacontext to the page we are navigating to via the RootVisual.
      FrameworkElement root = Application.Current.RootVisual as FrameworkElement;
      root.DataContext = navigationListBox.SelectedItem;

      Debug.WriteLine(string.Format("foo {0}", navigationListBox.SelectedItem));
      NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.RelativeOrAbsolute));
    }
  }
}