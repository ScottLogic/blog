﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using NavigationListControl;

namespace NavigationList
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();                 
    }

    protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      var data = new List<string>();
      for (int i = 0; i < 100; i++)
      {
        data.Add("Item #" + i.ToString());
      } 

      FrameworkElement root = Application.Current.RootVisual as FrameworkElement;
      root.DataContext = data;

    }


    private void Button_Click(object sender, RoutedEventArgs e)
    {
      ((App)Application.Current).Timestamp = System.Environment.TickCount;

      var button = sender as Button;
      string uri = button.Tag as string;
      NavigationService.Navigate(new Uri("/" + uri, UriKind.RelativeOrAbsolute));
    }

  }
}