﻿var propertyTemplate,
    propertyDetailsTemplate;

$(document).ready(function () {
  $(".detailsPage").hide();

  document.addEventListener("deviceready", onDeviceReady, false);
  document.addEventListener("backbutton", onBackButton, false);
});

// phonegap is initialised
function onDeviceReady() {
  $("#welcomeMsg").append("...");

  $("#form").submit(searchProperties);
  $("#getLocationButton").click(getGeolocation);

  propertyTemplate = $("#propertyTemplate").template();
  propertyDetailsTemplate = $("#propertyDetailsTemplate").template();

  $(".progress").hide();

  // create an animation loop for the progress bar;
  startAnimation();
  var tid = setInterval(startAnimation, 3500);
}

function startAnimation() {
  var delay = 200;
  $(".pip").each(function () {
    animatePip($(this), delay);
    delay += 200;
  });
}

function animatePip(element, delay) {
  element.css("left", 0)
        .hide()
        .delay(delay)
        .show()
        .animate({ left: 240 }, { duration: 1000, easing: "easeOutSine" })
        .animate({ left: 480 }, { duration: 1000, easing: "easeInSine" });
}

// show the search page
function onBackButton() {
  showSearchPage();
}

function showSearchPage() {
  $(".detailsPage").animate({ left: 480 }, 300, function () {
    $(this).hide();
  });
  $(".searchPage").show().animate({ left: 0 }, 300);
};

function showDetailsPage() {
  $(".detailsPage").show().animate({ left: 0 }, 300);
  $(".searchPage").animate({ left: -480 }, 300, function () {
    $(this).hide();
  });
};


// searches for properties based on the current search text
function searchProperties() {      
  var query = "http://api.nestoria.co.uk/api?" +
                  "country=uk&pretty=1&action=search_listings&encoding=json&listing_type=buy" +
                  "&place_name=" + $("#searchText").val();

  var resultsContainer = $("#resultsContainer");
  resultsContainer.empty();

  $(".progress").show().delay(500);

  $.ajax({
    dataType: "jsonp",
    url: query,
    success: function (result) {            
      $.each(result.response.listings, function (index, property) {
        var $itemNode = $.tmpl(propertyTemplate, property).data("propertyData", property);
        $itemNode.appendTo(resultsContainer);
      });
      $(".progress").hide();
    }
  });

  return false;
}

// handle clicks on properties
function propertyClick(propertyNode) {

  // get the property
  var property = $(propertyNode).data("propertyData");

  // render the template
  $("#detailsContainer").empty();
  $.tmpl(propertyDetailsTemplate, property).appendTo("#detailsContainer");

  // switch pages
  showDetailsPage();
}

// gets the current phone location
function getGeolocation() {
  navigator.geolocation.getCurrentPosition(function (position) {
    // geocode via Bing Maps
    var apiKey = "Ai9-KNy6Al-r_ueyLuLXFYB_GlPl-c-_iYtu16byW86qBx9uGbsdJpwvrP4ZUdgD";
    var query = "http://dev.virtualearth.net/REST/v1/Locations/" + position.coords.latitude +
                    "," + position.coords.longitude + "?jsonp=onGeocode&key=" + apiKey

    $(".progress").show();
    $.ajax({
      dataType: "jsonp",
      url: query
    });
  });
}

// handle the geocode results
function onGeocode(result) {
  $(".progress").hide();
  // extract the 'outward' part of the postcode
  var postalCode = result.resourceSets[0].resources[0].address.postalCode;
  var codeSplit = postalCode.split(" ");
  if (codeSplit.length > 0) {
    $("#searchText").val(codeSplit[0]);
  }
}