using System;
using System.Net;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;
using System.IO;
using System.Collections;

namespace SLUGUK.ViewModel
{
  public interface IMarshalInvoke
  {
    void Invoke(Action action);
  }
}