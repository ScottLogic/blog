﻿using System;
using System.Net;
using System.Collections.ObjectModel;

namespace SLUGUK.ViewModel
{
  public class TweetViewModel
  {
    public TweetViewModel()
    {
    }

    public long Id { get; set; }

    public string Title { get; set; }

    public string Author { get; set; }

    public string ProfileImageUrl { get; set; }

    public DateTime Timestamp { get; set; }
  }

  public class TweetViewModelCollection : ObservableCollection<TweetViewModel>
  {
  }
}
