﻿using System;
using System.Net;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;
using System.IO;
using System.Collections;

#if WINRT

// used for ICommand
using Windows.UI.Xaml.Input;

// used for INotifyPropertyChanged
using Windows.UI.Xaml.Data;

#else

using System.ComponentModel;
using System.Windows.Input;

#endif

namespace SLUGUK.ViewModel
{
  public partial class TwitterSearchViewModel : INotifyPropertyChanged
  {
    #region fields

    // Twitter search for #Silverlight
    private readonly string _twitterUrl = "http://search.twitter.com/search.atom?rpp=100&&q=";

    private TweetViewModelCollection _tweets = new TweetViewModelCollection();

    private IMarshalInvoke _marshalInvoke;

    private string _searchText = "WinRT";

    private bool _isSearching = false;

    #endregion

    #region public API

    public TwitterSearchViewModel(IMarshalInvoke marshalInvoke)
    {
      _marshalInvoke = marshalInvoke;
    }

    /// <summary>
    /// Gets / sets the search term
    /// </summary>
    public string SearchText
    {
      get
      {
        return _searchText;
      }
      set
      {
        _searchText = value;
        OnPropertyChanged("SearchText");
      }
    }

    /// <summary>
    /// Gets whether a search is in progress
    /// </summary>
    public bool IsSearching
    {
      get
      {
        return _isSearching;
      }
      private set
      {
        _isSearching = value;
        OnPropertyChanged("IsSearching");
      }
    }


    /// <summary>
    /// Gets the search results
    /// </summary>
    public TweetViewModelCollection Tweets
    {
      get { return _tweets; }
      set { _tweets = value; }
    }

    /// <summary>
    /// Gets a command that executes the search
    /// </summary>
    public ICommand ExecuteSearchCommand
    {
      get
      {
        return new DelegateCommand(() => ExecuteSearch());
      }
    }

    #endregion

    #region private

    /// <summary>
    /// Parses the response from our twitter request, creating a list of TweetViewModel instances
    /// </summary>
    private void ParseXMLResponse(string xml)
    {
      var doc = XDocument.Parse(xml);
      var items = doc.Descendants(AtomConst.Entry)
                      .Select(entryElement => new TweetViewModel()
                      {
                        Title = entryElement.Descendants(AtomConst.Title).Single().Value,
                        Id = long.Parse(entryElement.Descendants(AtomConst.ID).Single().Value.Split(':')[2]),
                        ProfileImageUrl =  entryElement.Descendants(AtomConst.Link).Skip(1).First().Attribute("href").Value,
                        Timestamp = DateTime.Parse(entryElement.Descendants(AtomConst.Published).Single().Value),
                        Author = entryElement.Descendants(AtomConst.Name).Single().Value
                      });

      _tweets.Clear();
      foreach (var item in items)
      {
        _tweets.Add(item);
      }
    }

    /// <summary>
    /// Searches for the given term
    /// </summary>
    private void ExecuteSearch()
    {
      IsSearching = true;

      // perform the search
      string uri = _twitterUrl + SearchText;
      HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(new Uri(uri));
      request.BeginGetResponse(new AsyncCallback(ReadCallback), request);
    }

    /// <summary>
    /// A callback that receives the search results
    /// </summary>
    private void ReadCallback(IAsyncResult asynchronousResult)
    {
      HttpWebRequest request = (HttpWebRequest)asynchronousResult.AsyncState;
      HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);
      using (StreamReader streamReader1 = new StreamReader(response.GetResponseStream()))
      {
        string resultString = streamReader1.ReadToEnd();

        // marshall onto the UI thread and parse
        _marshalInvoke.Invoke(() =>
          {
            Tweets.Clear();
            ParseXMLResponse(resultString);
            IsSearching = false;
          });
      }
    }

    #endregion

    #region INPC

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }

    #endregion
  }
}
