using System;
using System.Net;
using System.Collections.ObjectModel;

#if WINRT

// used for ICommand
using Windows.UI.Xaml.Input;

#else

using System.Windows.Input;

#endif

namespace SLUGUK.ViewModel
{
  public class DelegateCommand : ICommand
  {
    private Action _action;

    public DelegateCommand(Action action)
    {
      _action = action;
    }

    public bool CanExecute(object parameter)
    {
      return true;
    }

#if WINRT
    public event Windows.UI.Xaml.EventHandler CanExecuteChanged;
#else
    public event EventHandler CanExecuteChanged;
#endif

    public void Execute(object parameter)
    {
      _action();
    }
  }
}