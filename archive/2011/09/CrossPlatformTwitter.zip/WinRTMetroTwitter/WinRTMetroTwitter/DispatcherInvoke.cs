﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SLUGUK.ViewModel;
using Windows.UI.Core;

namespace WinRTMetroTwitter
{
  class DispatcherInvoke : IMarshalInvoke
  {
    private CoreDispatcher _dispatcher;

    public DispatcherInvoke(CoreDispatcher dispatcher)
    {
      _dispatcher = dispatcher;
    }

    public void Invoke(Action action)
    {
      _dispatcher.InvokeAsync(CoreDispatcherPriority.Normal, (s, a) =>
        {
          action();
        }, this, null); 
    }
  }
}
