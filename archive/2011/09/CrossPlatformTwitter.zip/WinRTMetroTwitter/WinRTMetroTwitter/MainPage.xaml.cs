﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SLUGUK.ViewModel;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;

namespace WinRTMetroTwitter
{
  partial class MainPage
  {
    private TwitterSearchViewModel _viewModel;

    public MainPage()
    {
      InitializeComponent();

      _viewModel = new TwitterSearchViewModel(new DispatcherInvoke(this.Dispatcher));
      this.DataContext = _viewModel;
    }

  }
}
