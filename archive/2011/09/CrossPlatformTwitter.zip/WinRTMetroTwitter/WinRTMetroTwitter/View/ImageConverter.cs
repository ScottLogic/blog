﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media.Imaging;

namespace WinRTMetroTwitter.View
{
  public class ImageConverter : IValueConverter
  {
    public object Convert(object value, string typeName, object parameter, string language)
    {
      try
      {
        return new BitmapImage(new Uri((string)value));
      }
      catch
      {
        return new BitmapImage();
      }
    }

    public object ConvertBack(object value, string typeName, object parameter, string language)
    {
      throw new NotImplementedException();
    }
  }
}
