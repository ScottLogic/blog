﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Threading.Tasks;
using SLUGUK.ViewModel;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;

namespace WinRTMetroTwitter.View
{
  public sealed partial class TwitterSearchView : UserControl
  {
    private TwitterSearchViewModel feedViewModel;

    public TwitterSearchView()
    {
      InitializeComponent();

      this.Loaded += ResultsView_Loaded;
    }


    private void ResultsView_Loaded(object sender, RoutedEventArgs e)
    { 
      feedViewModel = this.DataContext as TwitterSearchViewModel;

      // see: http://social.msdn.microsoft.com/Forums/en-US/winappswithcsharp/thread/aec84969-0947-4fe8-bcf6-ab533e7ab894
      feedViewModel.Tweets.CollectionChanged += FeedItems_CollectionChanged;
    }


    private void FeedItems_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      itemsControl.ItemsSource = null;
      itemsControl.ItemsSource = feedViewModel.Tweets;
    }
  }
}
