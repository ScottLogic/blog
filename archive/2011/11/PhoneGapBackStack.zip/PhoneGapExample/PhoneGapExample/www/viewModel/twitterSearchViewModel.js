﻿
/// <summary>
/// A view model for searching twitter for a given term
/// </summary>
function TwitterSearchViewModel() {

  var that = this;

  // --- properties

  this.isSearching = ko.observable(false);

  this.searchTerm = ko.observable("#wp7dev");
  
  this.tweets = ko.observableArray();

  this.scrollPosition = 0;

  this.template = "twitterSearchView";

  this.factoryName = "twitterSearchViewModelFactory";

  // --- functions
  
  // search twitter for the given string
  this.search = function () {
    if (this.searchTerm() != "") {

      this.isSearching(true);
      var url = "http://search.twitter.com/search.json?q=" +
            encodeURIComponent(that.searchTerm());

      $.ajax({
        dataType: "jsonp",
        url: url,
        success: function (response) {
          // clear the results
          that.tweets.removeAll();
          // add the new items
          $.each(response.results, function () {
            var tweet = new TweetViewModel();
            tweet.initialize(this);
            that.tweets.push(tweet);
          });

          that.isSearching(false);
        }
      });
    }
  }
}

// a factory for creating a TwitterSearchViewModel from a JSON object
function twitterSearchViewModelFactory(state) {
  var viewModel = new TwitterSearchViewModel();

  viewModel.isSearching(state.isSearching);
  viewModel.searchTerm(state.searchTerm);

  $.each(state.tweets, function () {
    var tweetViewModel = tweetViewModelFactory(this);
    viewModel.tweets.push(tweetViewModel);
  });

  return viewModel;
}

