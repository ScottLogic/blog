﻿
/// <summary>
/// A view model that represents a single tweet
/// </summary>
function TweetViewModel() {

  var that = this;

  // --- properties
  this.author = undefined;
  this.text = undefined;
  this.id = undefined;
  this.time = undefined;
  this.thumbnail = undefined;

  this.template = "tweetDetailView";
  this.factoryName = "tweetViewModelFactory";

  // --- functions

  this.initialize = function(tweet) {
    this.author = tweet.from_user,
    this.text = tweet.text,
    this.id = tweet.id,
    this.time = this.parseDate(tweet.created_at);
    this.thumbnail = tweet.profile_image_url;
  };

  this.select = function () {
    application.navigateTo(this);
  };

  // parses the tweet date to give a more readable format
  this.parseDate = function(date) {
    var diff = (new Date() - new Date(date)) / 1000;

    if (diff < 60) {
      return diff.toFixed(0) + " seconds ago";
    }

    diff = diff / 60;
    if (diff < 60) {
      return diff.toFixed(0) + " minutes ago";
    }

    diff = diff / 60;
    if (diff < 10) {
      return diff.toFixed(0) + " hours ago";
    }

    diff = diff / 24;
    return diff.toFixed(0) + " days ago";
  }
};

// a factory for creating a TweetViewModel from a JSON object
function tweetViewModelFactory(state) {
  var viewModel = new TweetViewModel();

  viewModel.author = state.author,
  viewModel.text = state.text,
  viewModel.id = state.id,
  viewModel.time = state.time;
  viewModel.thumbnail = state.thumbnail;

  return viewModel;
}
