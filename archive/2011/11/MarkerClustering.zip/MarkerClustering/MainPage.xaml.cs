﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Maps;
using System.Device.Location;
using System.Xml.Linq;

namespace MarkerClustering
{
  public partial class MainPage : PhoneApplicationPage
  {
    private Random _rand = new Random();
    
    // Constructor
    public MainPage()
    {
      InitializeComponent();

      var doc = XDocument.Load("MarkerClustering;component/jugglingclubs.xml");

      var pins = doc.Descendants("club")
                    // get clubs with coordinates
                    .Where(club => club.Descendants("coordinates").Any())
                    .Select(el => new {
                      lat = double.Parse(el.Descendants("latitude").Single().Value),
                      lon = double.Parse(el.Descendants("longitude").Single().Value),
                      name = el.Descendants("name").Single().Value
                      })
                    // verify the coordinates are sensible!
                    .Where(coord => coord.lat < 90 &&  coord.lat > -90 && coord.lon < 90 &&  coord.lon > -90)
                    // create a pushpin for each club
                    .Select(i => new Pushpin()
                            {
                              Location = new GeoCoordinate(i.lat, i.lon),
                              Content = i.name,
                              DataContext = i.name,
                              ContentTemplate = this.Resources["MarkerTemplate"] as DataTemplate
                            }).ToList();

      var clusterer = new PushpinClusterer(map, pins,
        this.Resources["ClusterTemplate"] as DataTemplate);

      map.MouseLeftButtonUp += new MouseButtonEventHandler(Map_MouseLeftButtonUp);
    }

    private void Map_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      var fe = e.OriginalSource as FrameworkElement;
      if (fe.DataContext is string)
      {
        itemList.ItemsSource = new List<string>() { (string)fe.DataContext };
      }

      if (fe.DataContext is IEnumerable<object>)
      {
        itemList.ItemsSource = (fe.DataContext as IEnumerable<object>).Cast<string>();
      }
    }


  }
}