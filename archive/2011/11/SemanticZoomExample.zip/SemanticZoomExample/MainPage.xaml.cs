﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using LinqToVisualTree;
using WP7JumpList;

namespace SemanticZoomExample
{
  partial class MainPage
  {
    public MainPage()
    {
      InitializeComponent();

      var people = WP7JumpList.PersonDataSource.CreateList(100);

      var source = people.GroupBy(person => person.Surname.Substring(0, 1),
                                  (key, items) => new GroupInfoList(key, items))
                         .OrderBy(group => group.Key);

      var cvs = new CollectionViewSource();
      cvs.Source = source;
      jumpViewer.DataContext = cvs;
      (jumpViewer.JumpView as ListViewBase).ItemsSource = cvs.View.CollectionGroups;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      jumpViewer.IsContentViewActive = false;
    }
  }

  public class GroupInfoList : List<object>, IGroupInfo
  {
    public GroupInfoList(object key, IEnumerable<object> values)
    {
      Key = key;
      AddRange(values);
    }

    public object Key { get; set; }

    public new IEnumerator<object> GetEnumerator()
    {
      return (System.Collections.Generic.IEnumerator<object>)base.GetEnumerator();
    }
  }

}
