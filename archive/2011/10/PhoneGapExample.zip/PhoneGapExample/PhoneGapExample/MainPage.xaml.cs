﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using Microsoft.Phone.Shell;
using System.Threading;
using System.Diagnostics;
using WP7GapClassLib;
using System.Windows.Navigation;
using System.IO.IsolatedStorage;


namespace PhoneGapExample
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();

      phoneGapView.Browser.ScriptNotify += Browser_ScriptNotify;
    }


    private void Browser_ScriptNotify(object sender, NotifyEventArgs e)
    {
      string commandStr = e.Value;

      if (commandStr == "getState" && App.Current.TombstoneState != null)
      {
        phoneGapView.Browser.InvokeScript("setState", new string[] { App.Current.TombstoneState });
      }
    }

    public PGView PhoneGapView
    {
      get
      {
        return phoneGapView;
      }
    }
  }
}