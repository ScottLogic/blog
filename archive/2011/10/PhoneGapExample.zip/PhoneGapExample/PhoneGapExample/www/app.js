﻿
$(document).ready(function () {
  document.addEventListener("deviceready", onDeviceReady, false);
});

// phonegap is initialised
function onDeviceReady() {

  // create the view model
  twitterSearchViewModel = new TwitterSearchViewModel();

  // check for tombstoned state
  window.external.Notify("getState");

  // instantiate the view an bind
  $("#twitterSearchView").tmpl("").appendTo("#app");
  ko.applyBindings(twitterSearchViewModel)
}

// returns the view model state
function getState() {
  return twitterSearchViewModel.getState();
}

// sets the view model state
function setState(state) {
  twitterSearchViewModel.setState(state);
}

