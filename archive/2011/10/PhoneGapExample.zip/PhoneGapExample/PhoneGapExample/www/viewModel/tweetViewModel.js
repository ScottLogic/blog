﻿
/// <summary>
/// A view model that represents a single tweet
/// </summary>
function TweetViewModel(tweet) {

    // --- properties

    this.author = tweet.from_user,
    this.text = tweet.text,
    this.time = parseDate(tweet.created_at);
    this.thumbnail = tweet.profile_image_url;

    // --- functions

    // parses the tweet date to give a more readable format
    function parseDate(date) {
      var diff = (new Date() - new Date(date)) / 1000;

      if (diff < 60) {
        return diff.toFixed(0) + " seconds ago";
      }

      diff = diff / 60;
      if (diff < 60) {
        return diff.toFixed(0) + " minutes ago";
      }

      diff = diff / 60;
      if (diff < 10) {
        return diff.toFixed(0) + " hours ago";
      }

      diff = diff / 24;
      return diff.toFixed(0) + " days ago";
    }
};
