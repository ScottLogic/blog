﻿
/// <summary>
/// A view model for searching twitter for a given term
/// </summary>
function TwitterSearchViewModel() {

  var that = this;

  // --- properties

  this.isSearching = ko.observable(false);

  this.searchTerm = ko.observable("#wp7dev");

  this.tweets = ko.observableArray();

  // --- functions

  // search twitter for the given string
  this.search = function () {
    if (that.searchTerm() != "") {

      that.isSearching(true);
      var url = "http://search.twitter.com/search.json?q=" +
            encodeURIComponent(that.searchTerm());

      $.ajax({
        dataType: "jsonp",
        url: url,
        success: function (response) {
          // clear the results
          that.tweets.removeAll();
          // add the new items
          $.each(response.results, function () {
            var tweet = new TweetViewModel(this);
            that.tweets.push(tweet);
          });

          that.isSearching(false);
        }
      });
    }
  }

  // gets the view model state as a JSON string
  this.getState = function () {
    return ko.toJSON(this);
  }

  // sets the view model state based on the given JSON string.
  this.setState = function (stateString) {
    var state = $.parseJSON(stateString),
        that = this;

    this.isSearching(state.isSearching);
    this.searchTerm(state.searchTerm);

    this.tweets.removeAll();
    $.each(state.tweets, function () {
      that.tweets.push(this);
    });
  } 
}