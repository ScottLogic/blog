﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;

namespace ObservableCollectionExample
{
  partial class MainPage
  {
    private ObservableCollection<object> _items;

    public MainPage()
    {
      InitializeComponent();

      _items = new ObservableCollection<object>()
            {
                "one",
                "two"
            };

      this.DataContext = Items;
    }


    public object Items
    {
      get
      {
        return _items;
      }
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _items.Add("foo");
    }
  }
}
