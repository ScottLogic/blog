﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.ComponentModel;

namespace UserFunctionPlotter
{
    public partial class FunctionChart : UserControl
    {
        bool init = false;
        public FunctionChart()
        {
            InitializeComponent();
            var chartRelay = new ChartAxesEventRelay(Chart, AxisEventEnumeration.ActualRangeEffectiveLimitsChanged | AxisEventEnumeration.ValueConversion);
            chartRelay.AxisEvent += RepositionAxesEvent;
            Chart.SizeChanged += RepositionAxesEvent;
            Chart.Loaded += Chart_Loaded;
        }

        private void Chart_Loaded(object sender, RoutedEventArgs e)
        {
            if (DesignerProperties.GetIsInDesignMode(this)) { return; }
            Chart.ApplyTemplate();
            RepositionAxes();
            if (Chart.XAxis != null && Chart.YAxis != null)
            {
                init = true;
                Chart.XAxis.Element.SizeChanged += RepositionAxesEvent;
                Chart.YAxis.Element.SizeChanged += RepositionAxesEvent;
            }
        }

        private void RepositionAxesEvent(object sender, EventArgs e)
        {
            RepositionAxes();
        }

        /// <summary>
        /// Position axes appropriately - axes need to be repositioned after changes in the axis ranges,
        /// or the rendered layout (eg chart or axis size).
        /// </summary>
        private void RepositionAxes()
        {
            if (Chart.YAxis == null || Chart.XAxis == null) { return; }
            var yAxisContainer = VisualTreeHelper.GetParent(Chart.YAxis.Element) as FrameworkElement;
            var xAxisContainer = VisualTreeHelper.GetParent(Chart.XAxis.Element) as FrameworkElement;

            if (yAxisContainer == null || xAxisContainer == null) { return; }

            var xPos = Chart.XAxis.GetDataValueAsRenderPositionWithZoom(0.0);
            var yPos = Chart.YAxis.GetDataValueAsRenderPositionWithZoom(0.0);

            if (xPos > xAxisContainer.ActualWidth)
            {
                xPos = xAxisContainer.ActualWidth;
            }
            else if (xPos < yAxisContainer.ActualWidth)
            {
                xPos = yAxisContainer.ActualWidth;
            }
            if (yPos > yAxisContainer.ActualHeight - xAxisContainer.ActualHeight)
            {
                yPos = yAxisContainer.ActualHeight - xAxisContainer.ActualHeight;
            }
            else if (yPos < 0)
            {
                yPos = 0;
            }



            Canvas.SetLeft(yAxisContainer, Math.Floor(xPos) + 0.5 - yAxisContainer.ActualWidth);
            Canvas.SetTop(xAxisContainer, (Math.Floor(yPos) + 0.5));
        }

        private void PanBehaviour_PanEnded(object sender, EventArgs e)
        {
            Chart.XAxis.AdoptZoomAsRange();
        }
    }
}
