﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using Visiblox.Charts;

namespace UserFunctionPlotter
{
    public class FunctionDataSeries : List<IDataPoint>, IDataSeries, IChartSeriesAwareDataSeries
    {
        double _min = -10.0, _max = 10.0;
        IChartSeries _chartSeries;
        AxisEventRelay _xAxisRelay;
        Func<double, double> _function;

        public FunctionDataSeries(Func<double, double> function, double min, double max)
        {
            if (function == null)
                throw new ArgumentNullException("function");
            _function = function;
            _min = min;
            _max = max;
        }

        public FunctionDataSeries(Func<double, double> function) : this(function, -10.0, 10.0)
        {
        }

        #region event boilerplate
        public IChartSeries ChartSeries
        {
            get
            {
                return _chartSeries;
            }
            set
            {
                if (_chartSeries == value) { return; }
                if (_chartSeries != null)
                {
                    _chartSeries.PropertyChanged -= ChartSeries_PropertyChanged;
                    UnsubscribeAxis(_xAxisRelay);
                }
                _chartSeries = value;
                if (_chartSeries != null)
                {
                    _xAxisRelay = SubscribeAxis(_chartSeries.XAxis);
                    _chartSeries.PropertyChanged += ChartSeries_PropertyChanged;
                }
            }
        }

        private void ChartSeries_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "XAxis")
            {
                UnsubscribeAxis(_xAxisRelay);
                _xAxisRelay = SubscribeAxis(_chartSeries.XAxis);
            }
        }

        private AxisEventRelay SubscribeAxis(IAxis axis)
        {
            AxisEventRelay relay = null;
            if (axis != null)
            {
                relay = new AxisEventRelay(axis, AxisEventEnumeration.ActualRangeLimitsChanged);
                relay.AxisEvent += Relay_AxisEvent;
                GenerateData();
                OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
            }
            return relay;
        }


        private void Relay_AxisEvent(object sender, AxisEventRelayEventArgs e)
        {
            if (_xAxisRelay == null) { return; }
            var xAxis = _xAxisRelay.Axis;
            if (xAxis == null || xAxis.ActualRange == null) { return; }
            _min = (double)xAxis.ActualRange.Minimum;
            _max = (double)xAxis.ActualRange.Maximum;

            GenerateData();
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        private void GenerateData()
        {
            this.Clear();
            double step = Math.Max(0.0001, (_max - _min) / 1000);
            for (double x = _min; x <= _max; x += step)
            {
                this.Add(new DataPoint<double, double>(x, _function(x)));
            }
        }

        private void UnsubscribeAxis(AxisEventRelay relay)
        {
            if (relay != null)
            {
                relay.UnSubscribe();
            }
        }


        protected void OnCollectionChanged(NotifyCollectionChangedEventArgs args)
        {
            if (CollectionChanged != null)
            {
                CollectionChanged(this, args);
            }
        }

        public event NotifyCollectionChangedEventHandler CollectionChanged;
        #endregion

        public string Title { get; set; }
    }
}
