﻿module SimpleExprParser
open FParsec

exception ParseException
let sym = pstring

(* environment is just a single double (the x value) *)
type env = double

(* variable becomes function returning the 'environment' x *)
let var = sym "x" >>% id

(* float literal becomes function returning that literal, ignoring the environment *)
let num = (pfloat |>> (fun z _ -> z))

(* helper function converting a numeric operator to a function of the environment *)
(* fop : (double -> double -> double) -> (env -> double) -> (env -> double) -> env -> double *)
let fop op fa fb env = fa env |> op <| fb env

(* Parse single operators - return function taking two operands and giving the result *)
let (addop : Parser<_,unit>) = 
    sym "+" >>% fop (+)
    <|> ( sym "-" >>% fop (-) )
let (mulop : Parser<_,unit>) = 
    sym "*" >>% fop (*)
    <|> ( sym "/" >>% fop (/) )


let (atom: Parser<float->float,unit>), atomImpl = createParserForwardedToRef() // break circular reference

(*  Parse math function name - return the function itself *)
let (mathOp: Parser<_,unit>) = 
       sym "sin" >>% sin
       <|> ( sym "cos" >>% cos )
       <|> ( sym "tan" >>% tan )

(* f(x) or f(2+3) *)
(* compose result of parsing the expression with the given function *)
let mathExpr = mathOp .>>. atom |>> fun (f,g) -> g >> f

(* term, expr - chain of operators of a given precedence *)
let term = chainl1 atom mulop
let expr = chainl1 term addop
atomImpl := num <|> var  <|> mathExpr <|> between (sym "(") (sym ")") expr

let taggedExpr =
    attempt (manySatisfy isLetter .>> sym ":" .>>. expr)
    <|> ( expr |>> (fun f -> ("f", f)) )

let fullExpr = sepBy1 taggedExpr skipNewline .>> eof

// Get the result of the parse without giving any nice error info if it failed...
let result p str = 
    match run p str with
    | Success(result, _, _) -> Some result
    | _ -> None

let toFunc (f: 'a->'b) = new System.Func<'a,'b>(f)
let toNullable (x:'a) = new System.Nullable<'a>(x)

let ParseExpr = result fullExpr
let ParseExprMain s = 
    match ParseExpr s with 
      Some fs -> fs |> List.map (fun (x,f) -> (x, toFunc(f))) |> Seq.ofList |> Some
    | None -> None