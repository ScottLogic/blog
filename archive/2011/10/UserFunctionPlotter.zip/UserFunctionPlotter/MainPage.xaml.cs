﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.Collections.Specialized;

namespace UserFunctionPlotter
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            DataContext = this;
            InitializeComponent();
            SetDefaultSeries();
        }

        private void AddFunction()
        {
            FunctionChart.Chart.Series.Clear();
            string text = CodeEntryBox.Text;
            var result = SimpleExprParser.ParseExprMain(text);
            if (IsSome(result))
            {
                foreach (var f in result.Value)
                {
                    FunctionChart.Chart.Series.Add(new LineSeries
                    {
                        DataSeries = new FunctionDataSeries(f.Item2) { Title = f.Item1 }
                    });
                }
            }
        }

        private bool IsSome<T>(Microsoft.FSharp.Core.FSharpOption<T> option)
        {
            return Microsoft.FSharp.Core.FSharpOption<T>.get_IsSome(option);
        }

        private void SetDefaultSeries()
        {
            FunctionChart.Chart.Series.Clear();
            FunctionChart.Chart.XAxis = new LinearAxis { Range = new DoubleRange(-10.0, 10.0) };
            CodeEntryBox.Text =
@"sin:sin(x)
cos:cos(x)
xcosx:x*sin(x)";
            AddFunction();
        }

        private void StartBtn_Click(object sender, RoutedEventArgs e)
        {
            AddFunction();
        }
    }
}
