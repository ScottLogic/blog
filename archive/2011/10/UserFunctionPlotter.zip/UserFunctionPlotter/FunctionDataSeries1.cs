﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.Collections.Specialized;

namespace UserFunctionPlotter
{
    public class FunctionDataSeries1 : IDataSeries
    {
        private Func<double, double> _function;
        private double _min, _max;

        public string Title { get; set; }

        public FunctionDataSeries1(Func<double, double> function, double min, double max)
        {
            if (function == null)
                throw new ArgumentNullException("function");
            _function = function;
            if (min >= max)
                throw new ArgumentException("Minimum must be less than maximum", "min");
            _min = min;
            _max = max;
        }

        public FunctionDataSeries1(Func<double, double> function)
            : this(function, -10.0, 10.0)
        { }

        /// <summary>
        /// Simplest IDataSeries implementation - directly enumerate the data when asked for it.
        /// </summary>
        public System.Collections.IEnumerator GetEnumerator()
        {
            double step = Math.Max(0.0001, (_max - _min) / 100);
            for (double x = _min; x <= _max; x += step)
            {
                yield return new DataPoint<double, double>(x, _function(x));
            }
        }

        /// <summary>
        /// Trivial INotifyCollectionChanged implementation - do nothing as we don't change.
        /// </summary>
        public event NotifyCollectionChangedEventHandler CollectionChanged;
    }
}
