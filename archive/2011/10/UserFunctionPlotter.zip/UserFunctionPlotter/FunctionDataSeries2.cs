﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.Collections.Specialized;
using System.Collections.Generic;

namespace UserFunctionPlotter
{
    public class FunctionDataSeries2 : List<IDataPoint>, IDataSeries
    {
        private Func<double, double> _function;
        private double _min, _max;

        public string Title { get; set; }

        public FunctionDataSeries2(Func<double, double> function, double min, double max)
        {
            if (function == null)
                throw new ArgumentNullException("function");
            _function = function;
            if (min >= max)
                throw new ArgumentException("Minimum must be less than maximum", "min");
            _min = min;
            _max = max;
            GenerateData();
        }

        public FunctionDataSeries2(Func<double, double> function)
            : this(function, -10.0, 10.0)
        { }

        private void GenerateData()
        {
            this.Clear();
            double step = Math.Max(0.0001, (_max - _min) / 100);
            for (double x = _min; x <= _max; x += step)
            {
                this.Add(new DataPoint<double, double>(x, _function(x)));
            }
        }

        /// <summary>
        /// Trivial INotifyCollectionChanged implementation - do nothing as we don't change.
        /// </summary>
        public event NotifyCollectionChangedEventHandler CollectionChanged;
    }
}
