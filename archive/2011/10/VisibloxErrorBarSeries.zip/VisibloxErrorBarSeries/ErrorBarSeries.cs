﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using Visiblox.Charts.Primitives;
using System.Collections.Generic;

namespace VisibloxErrorBarSeries
{
  public class ErrorBarSeries : MultiValueSeriesBase
  {
    public static readonly string ErrorUp = "ErrorUp";

    public static readonly string ErrorDown = "ErrorDown";

    public static readonly string Value = "Value";

    /// <summary>
    /// The width of the error bars, as a proportion of the distance between points.
    /// </summary>
    private const double WidthFactor = 0.1;

    protected override FrameworkElement CreatePoint(IDataPoint dataPoint)
    {
      var lineGeometry = BuildGeometry(dataPoint);

      Path line = new Path();
      line.Stroke = new SolidColorBrush(Colors.Black);
      line.Fill = new SolidColorBrush(Colors.Gray);
      line.StrokeThickness = 1.0;
      line.StrokeLineJoin = PenLineJoin.Bevel;
      line.Data = lineGeometry;
      line.SetValue(ZoomCanvas.IsScaledPathProperty, true);
   
      return line;
    }    

    /// <summary>
    /// Creates the geometry for the given datapoint
    /// </summary>
    private PathGeometry BuildGeometry(IDataPoint dataPoint)
    {
      var halfWidth = SuggestedPointWidth * WidthFactor;

      // obtain the data values
      var topDataValue = dataPoint[ErrorUp] as IComparable;
      var middleDataValue = dataPoint[Value] as IComparable;
      var bottomDataValue = dataPoint[ErrorDown] as IComparable;

      // convert to a the required render coordinates
      double topRenderPos = YAxis.GetDataValueAsRenderPositionWithoutZoom(topDataValue);
      double middleRenderPos = YAxis.GetDataValueAsRenderPositionWithoutZoom(middleDataValue);
      double bottomRenderPos = YAxis.GetDataValueAsRenderPositionWithoutZoom(bottomDataValue);

      double xMiddleRenderPos = XAxis.GetDataValueAsRenderPositionWithoutZoom(dataPoint.X);
      double xRightRenderPos = xMiddleRenderPos - halfWidth;
      double xLeftRenderPos = xMiddleRenderPos + halfWidth;

      // build a suitable gemoetry
      PathGeometry lineGeometry = new PathGeometry();

      PathFigure upperVerticalLine = CreateLineFigure(
        new Point(xMiddleRenderPos, middleRenderPos - halfWidth),
        new Point(xMiddleRenderPos, topRenderPos));
      lineGeometry.Figures.Add(upperVerticalLine);

      PathFigure lowerVerticalLine = CreateLineFigure(
        new Point(xMiddleRenderPos, bottomRenderPos),
        new Point(xMiddleRenderPos, middleRenderPos + halfWidth));
      lineGeometry.Figures.Add(lowerVerticalLine);

      PathFigure upperBar = CreateLineFigure(
        new Point(xLeftRenderPos, topRenderPos),
        new Point(xRightRenderPos, topRenderPos));
      lineGeometry.Figures.Add(upperBar);

      PathFigure lowerBar = CreateLineFigure(
        new Point(xLeftRenderPos, bottomRenderPos),
        new Point(xRightRenderPos, bottomRenderPos));
      lineGeometry.Figures.Add(lowerBar);

      PathFigure center = CreateLineFigure(
        new Point(xMiddleRenderPos - halfWidth, middleRenderPos),
        new Point(xMiddleRenderPos, middleRenderPos + halfWidth),
        new Point(xMiddleRenderPos + halfWidth, middleRenderPos),
        new Point(xMiddleRenderPos, middleRenderPos - halfWidth)
      );
      lineGeometry.Figures.Add(center);

      return lineGeometry;
    }

    /// <summary>
    /// Create a line figure that connects the given points
    /// </summary>
    private PathFigure CreateLineFigure(params Point[] points)
    {
      // add all the points (except the first)
      var pointCollection = new PointCollection();
      foreach (var point in points.Skip(1))
      {
        pointCollection.Add(point);
      }

      // create a figure, using the first point as the StartPoint.
      return new PathFigure()
      {
        IsClosed = true,
        StartPoint = points.First(),
        Segments = new PathSegmentCollection()
        {
          new PolyLineSegment
          {
            Points = pointCollection
          }
        }
      };
    }

    protected override void RenderDataLabels()
    {
    }
    
  
  }
}
