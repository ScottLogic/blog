﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace VisibloxErrorBarSeries
{
  public partial class MainPage : UserControl
  {

    public MainPage()
    {
      InitializeComponent();

      var data = new ObservableCollection<Measurement>();
      data.Add(CreateMeasurement(-195, 1.4, 0.2));
      data.Add(CreateMeasurement(0, 62.2, 9.3));
      data.Add(CreateMeasurement(20, 70.4, 6.5));
      data.Add(CreateMeasurement(100, 77.4, 1.9));
      this.DataContext = data;
    

      //var data = new DataSeries<double, double>();
      //data.Add(CreatePoint(-195, 1.4, 0.2));
      //data.Add(CreatePoint(0, 62.2, 9.3));
      //data.Add(CreatePoint(20, 70.4, 6.5));
      //data.Add(CreatePoint(100, 77.4, 1.9));
      
      //chart.Series[0].DataSeries = data;
    }

    private Measurement CreateMeasurement(double x, double y, double error)
    {
      return new Measurement()
        {
          XValue = x,
          YValue = y,
          YValueErrorUp = y + error,
          YValueErrorDown = y - error
        };
    }

    private MultiValuedDataPoint<double, double> CreatePoint(double x, double y, double error)
    {
      var point = new MultiValuedDataPoint<double, double>(x,
        new Dictionary<object, double>()
        {
          { ErrorBarSeries.ErrorUp, y + error },
          { ErrorBarSeries.ErrorDown, y - error },
          { ErrorBarSeries.Value, y }
        });
      return point;
    }

  }

  public class Measurement : INotifyPropertyChanged
  {
    private double xValue;
    private double yValue;
    private double yValueErrorUp;
    private double yValueErrorDown;

    public double XValue
    {
      get { return xValue; }
      set { xValue = value; OnPropertyChanged("XValue"); }
    }

    public double YValue
    {
      get { return yValue; }
      set { yValue = value; OnPropertyChanged("YValue"); }
    }

    public double YValueErrorUp
    {
      get { return yValueErrorUp; }
      set { yValueErrorUp = value; OnPropertyChanged("YValueErrorUp"); }
    }

    public double YValueErrorDown
    {
      get { return yValueErrorDown; }
      set { yValueErrorDown = value; OnPropertyChanged("YValueErrorDown"); }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }
  }
}
