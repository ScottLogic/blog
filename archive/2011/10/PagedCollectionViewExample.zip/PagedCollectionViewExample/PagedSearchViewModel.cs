﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.ServiceModel.Syndication;
using System.IO;

namespace PagedCollectionViewExample
{
  /// <summary>
  /// A view model that demonstrates paging data from the server
  /// </summary>
  public class PagedSearchViewModel : INotifyPropertyChanged
  {
    private string _searchText = "test";

    private ServerSidePagedCollectionView<SyndicationItem> _searchResults;
    
    /// <summary>
    /// Gets / sets the search string
    /// </summary>
    public String SearchText
    {
      get
      {
        return _searchText;
      }
      set
      {
        SetField(ref _searchText, value, "SearchText");
      }
    }

    /// <summary>
    /// Gets the paged search results
    /// </summary>
    public ServerSidePagedCollectionView<SyndicationItem> SearchResults
    {
      get
      {
        return _searchResults;
      }
      private set
      {
        SetField(ref _searchResults, value, "SearchResults");
      }
    }

    /// <summary>
    /// Gets a command which executes the search
    /// </summary>
    public ICommand ExecuteSearchCommand
    {
      get
      {
        return new DelegateCommand(() =>
        {
          SearchResults = new ServerSidePagedCollectionView<SyndicationItem>(
            new NetFlixDataSource(SearchText));
        });
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }

    private void SetField<T>(ref T field, T value, string propertyName)
    {
      if (object.Equals(field, value))
        return;

      field = value;
      OnPropertyChanged(propertyName);
    }
  }
      
}
