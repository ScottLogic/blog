﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.ServiceModel.Syndication;
using System.Xml;
using System.Xml.Linq;
using System.Linq;

namespace PagedCollectionViewExample
{
  /// <summary>
  /// A paged NetFlix movies search datasource.
  /// </summary>
  public class NetFlixDataSource : IPagedDataSource<SyndicationItem>
  {
    private string _searchString;

    private int _pageSize = 10;

    public NetFlixDataSource(string searchString)
    {
      _searchString = searchString;
    }

    public void FetchData(int pageNumber, Action<PagedDataResponse<SyndicationItem>> responseCallback)
    {
      WebClient client = new WebClient();

      // create a url for fetching movies with a name that contains the search string
      string url = string.Format("http://odata.netflix.com/Catalog/Titles?"
        + "$top={0}&$orderby=Name&$select=Name&$inlinecount=allpages&$skip={1}&$filter=indexof(Name,'{2}') ne -1",
        _pageSize, pageNumber * _pageSize, _searchString);

      client.DownloadStringCompleted += (s, e) =>
      {
        // parse the response using SyndaicationFeed
        XmlReader reader = XmlReader.Create(new StringReader(e.Result));
        SyndicationFeed feed = SyndicationFeed.Load(reader);

        // locate the item count 
        var itemCount = feed.ElementExtensions[0].GetObject<XElement>().Value;

        // invoke the response callback
        responseCallback(new PagedDataResponse<SyndicationItem>()
        {
          Items = feed.Items.ToList(),
          TotalItemCount = int.Parse(itemCount)
        });
      };
      client.DownloadStringAsync(new Uri(url));
    }
  }
}
