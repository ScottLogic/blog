﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Linq;

namespace PagedCollectionViewExample
{
  /// <summary>
  /// A dummy paged data source for testing
  /// </summary>
  public class MockDataSource : IPagedDataSource<int>
  {
    public void FetchData(int pageNumber, Action<PagedDataResponse<int>> responseCallback)
    {
      DispatcherTimer timer = new DispatcherTimer();
      timer.Interval = TimeSpan.FromSeconds(2);
      EventHandler timerHandler = null;

      timerHandler = (s, e) =>
      {
        responseCallback(new PagedDataResponse<int>()
        {
          TotalItemCount = 105,
          Items = GetItems(pageNumber)
        });
        timer.Tick -= timerHandler;
      };
      timer.Tick += timerHandler;
      timer.Start();
    }

    private List<int> GetItems(int pageNumber)
    {
      if (pageNumber == 10)
        return Enumerable.Range(100, 5).ToList();

      return Enumerable.Range(pageNumber * 10, 10).ToList();
    }
  }

}
