﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Shapes;

namespace AnimationsExample
{
    public sealed partial class PageFour
    {
        private Random _rand = new Random();

        public PageFour()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           // Canvas.SetTop(rect, _rand.Next(250));
            //Canvas.SetLeft(rect, _rand.Next(350));
            rect.Margin = new Thickness()
            {
                Left = _rand.Next(350),
                Top = _rand.Next(250)
            };
        }

        private Rectangle CreateRect()
        {
            return new Rectangle()
            {
                Width = 100,
                Height = 100,
                Fill = new SolidColorBrush(App.GetRandColor())
            };
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            itemsTwo.Items.Add(CreateRect());
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (itemsTwo.Items.Count > 0)
                itemsTwo.Items.RemoveAt(0);
        }

       
    }
}
