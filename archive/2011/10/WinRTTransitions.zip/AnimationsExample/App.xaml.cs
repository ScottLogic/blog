using System;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace AnimationsExample
{
    partial class App
    {
        public App()
        {
            InitializeComponent();
        }

        protected override void OnLaunched(LaunchActivatedEventArgs args)
        {
            Window.Current.Content = new MainPage();
            Window.Current.Activate();
        }

        public static App Instance
        {
            get
            {
                return Application.Current as App;
            }
        }

        private static Random radn = new Random();

        public static Color GetRandColor()
        {
            return new Color()
            {
                B = (byte)radn.Next(255),
                G = (byte)radn.Next(255),
                R = (byte)radn.Next(255),
                A = 255
            };
        }
    }
}
