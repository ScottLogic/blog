﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Shapes;

namespace AnimationsExample
{
    partial class MainPage
    {
        private List<FrameworkElement> _pages = new List<FrameworkElement>()
        {
            new PageOne(),
            new PageThree(),
            new PageTwo(),
            new PageFour(),
            new PageFive()
        };

        private int _pageIndex = 0;

        public MainPage()
        {
            InitializeComponent();

            SetContent();
        }

        private void ForwardButton_Click(object sender, RoutedEventArgs e)
        {
            _pageIndex++;
            SetContent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            _pageIndex--;
            SetContent();
        }

        private void SetContent()
        {
            if (_pageIndex < 0)
                _pageIndex = 0;
            if (_pageIndex >= _pages.Count)
                _pageIndex = _pages.Count;

            backButton.IsEnabled = _pageIndex > 0;
            forwardButton.IsEnabled = _pageIndex < _pages.Count;

            contentCtrl.Content = _pages[_pageIndex];
        }
        
    }
}
