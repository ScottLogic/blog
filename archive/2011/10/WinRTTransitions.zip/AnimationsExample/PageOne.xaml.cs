﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Shapes;

namespace AnimationsExample
{
    public sealed partial class PageOne
    {
        public PageOne()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            itemsOne.Items.Add(CreateRect());   
        }

        private Rectangle CreateRect()
        {
            return new Rectangle()
            {
                Width = 100,
                Height = 100,
                Fill = new SolidColorBrush(App.GetRandColor())
            };
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var rect = CreateRect();
            rect.Transitions = new TransitionCollection()
            {
                new EntranceThemeTransition()
            };
            itemsTwo.Items.Add(rect);
        }
    }
}
