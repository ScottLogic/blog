﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Shapes;

namespace AnimationsExample
{
    public sealed partial class PageSix
    {
        private CollectionViewSource _view;

        public PageSix()
        {
            InitializeComponent();

            ObservableCollection<Color> colors = new ObservableCollection<Color>();
            for (int i=0;i<20;i++)
                colors.Add(App.GetRandColor());

            _view = new CollectionViewSource();
            _view.Source = colors;
            itemsOne.ItemsSource = _view.View;
        }


        private void RButton_Click(object sender, RoutedEventArgs e)
        {
            _view.View.MoveCurrentToLast();
        }

        private void GButton_Click(object sender, RoutedEventArgs e)
        {
        }

        private void BButton_Click(object sender, RoutedEventArgs e)
        {
        }
       
    }
}
