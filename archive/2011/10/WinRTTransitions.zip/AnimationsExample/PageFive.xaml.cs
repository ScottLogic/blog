﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Shapes;

namespace AnimationsExample
{
    public sealed partial class PageFive
    {
        private Random _rand = new Random();

        public PageFive()
        {
            InitializeComponent();
        }
        
        private Rectangle CreateRect()
        {
            return new Rectangle()
            {
                Width = 80,
                Height = 80,
                Margin = new Thickness()
                {
                  Bottom = 2,
                  Top = 2,
                  Left = 2,
                  Right = 2
                },
                Fill = new SolidColorBrush(App.GetRandColor())
            };
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            itemsTwo.Items.Add(CreateRect());
            itemsOne.Items.Add(CreateRect());
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (itemsTwo.Items.Count > 0)
                itemsTwo.Items.RemoveAt(0);
            if (itemsOne.Items.Count > 0)
                itemsOne.Items.RemoveAt(0);
        }

       
    }
}
