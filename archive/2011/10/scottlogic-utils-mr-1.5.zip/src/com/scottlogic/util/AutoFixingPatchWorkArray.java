package com.scottlogic.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Subclass of the PatchWorkArray which automatically fixes itself
 * if the number of alterations reaches some specified limit.
 *
 * @author Mark Rhodes
 * @version 1.0
 * @see List
 * @see Collection
 * @see ArrayList
 * @see PatchWorkArray
 * @param <T> The type of element that this list should store.
 */
public class AutoFixingPatchWorkArray<T> extends PatchWorkArray<T> {

      private static final long serialVersionUID = -1503441625193979839L;

      /**
       * The default maximum factor of the size of a list that the performance
       * hit can reach before it automatically fixes itself.
       */
      public static final float DEFAULT_MAX_PERFORMANCE_HIT_FACTOR = 0.1f;

      /**
       * The default minimum performance factor at which a list will automatically
       * fix itself.
       */
      public static final int DEFAULT_MIN_PERFORMANCE_HIT_BEFORE_FIX = 10;

      /**
       *  The maximum factor of the size of this list that the performance
       *  hit can reach before it automatically fixes itself.
       */
      protected final float maxPerformanceHitFactor;

      /**
       * The minimum performance factor at which this list will automatically
       * fix itself.
       */
      protected final int minPerformanceHitBeforeFix;

      /**
       * Default constructor which fixes after the default limits are breached.
       */
      public AutoFixingPatchWorkArray(){
          maxPerformanceHitFactor = DEFAULT_MAX_PERFORMANCE_HIT_FACTOR;
          minPerformanceHitBeforeFix = DEFAULT_MIN_PERFORMANCE_HIT_BEFORE_FIX;
      }

      /**
       * Constructor which fixes after the default limits are breached and the
       * backing list has the given initial capacity.
       *
       * @param initialCapacity the initial capacity of the backing list.
       */
      public AutoFixingPatchWorkArray(int initialCapacity){
              super(initialCapacity);
          maxPerformanceHitFactor = DEFAULT_MAX_PERFORMANCE_HIT_FACTOR;
          minPerformanceHitBeforeFix = DEFAULT_MIN_PERFORMANCE_HIT_BEFORE_FIX;
      }

      /**
       * Constructor which allows the limits controlling the when this list auto-fixes.
       * The list automatically calls {@code fix()} when the performance hit is greater than both
       * {@code minPerformanceHitBeforeFix} and {@code maxPerformanceHitFactor} * {@code size()}.
       *
       * @param initialCapacity the initial size of the backing list.
       * @param maxPerformanceHitFactor the fraction of size of the list that the performance hit
       *        must exceed in order for this list to fix itself.  This value must be between 0 and 1 inclusive.
       * @param minPerformanceHitBeforeFix the smallest value for the performance hit at which this
       *        list will fix itself.
       * @throws IllegalArgumentException in the case that the {@code maxPerformanceHitFactor} is smaller than
       *         0 or larger than 1.
       */
      public AutoFixingPatchWorkArray(int initialCapacity,
                  float maxPerformanceHitFactor, int minPerformanceHitBeforeFix){
          super(initialCapacity);
          this.minPerformanceHitBeforeFix = minPerformanceHitBeforeFix;

          if(maxPerformanceHitFactor < 0 || maxPerformanceHitFactor > 1.0){
    		  throw new IllegalArgumentException("The maxPerformanceHitFactor must be between 0 and 1 inclusive.");
    	  }
          this.maxPerformanceHitFactor = maxPerformanceHitFactor;
      }

      /**
       * Removes and returns the element at the given index in this list.
       * <p>
       * This method can potentially increase or decrease the number of alterations, and hence the
       * performance hit. If after removing the element at the given index the performance hit breaches the
       * auto-fixing limit, {@code fix} is called.
       *
       * @param index the index of the element to remove.
       * @return the element which was removed from the list.
       * @throws IllegalArgumentException in the case that the index is not a valid index.
       */
      @Override
      public T remove(int index){
          T removed = super.remove(index);
          if(isFixRequired()){
              fix();
          }
          return removed;
      }

      /**
       * Inserts the specified element at the specified position in this list. Shifts the
       * element currently at that position (if any) and any subsequent elements to the
       * right (adds one to their indices).
       * <p>
       * This method can potentially increase or decrease the number of alterations, and hence the
       * performance hit.  If after inserting the given element the performance hit breaches
       * the auto-fixing limit, {@code fix} is called.
       *
       * @param index at which the element should be added.
       * @param obj the object to by inserted.
       * @throws IllegalArgumentException in the case that the given element is null.
       * @throws IndexOutOfBoundsException in the case that (0 <= index <= size()) does not hold.
       */
      @Override
      public void add(int index, T obj){
          super.add(index, obj);
          if(isFixRequired()){
        	  fix();
          }
      }

      /**
       * Determines if this list needs to be fixed or not.
       * <p>
       * This implementation returns true when the performance hit is at least
       * {@code minPerformanceHitBeforeFix} and is more than {@code maxPerformanceHitFactor}
       * of the total size of the list.
       *
       * @return <code>true</code> if this list needs to be fixed and <code>false</code>
       *         otherwise.
       */
      protected boolean isFixRequired(){
          int performanceHit = getPerformanceHit();
          return (performanceHit >= minPerformanceHitBeforeFix &&
                  size() * maxPerformanceHitFactor < performanceHit);
      }
}