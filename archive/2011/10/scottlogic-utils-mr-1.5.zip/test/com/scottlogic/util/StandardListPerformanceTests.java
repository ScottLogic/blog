package com.scottlogic.util;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

import org.junit.Test;

/**
 * Sets up a test rig and tests the performance of the
 * standard lists (i.e. non-sorted) in this package against
 * the java.util list implementations.
 *
 * @author Mark Rhodes
 * @version 1.0
 */
public class StandardListPerformanceTests {

	//TODO: this class would be better if refactored to remove repetitive code..

	/**
	 * Performs by-index add, remove and get operations on the on the regular list
	 * implementations in this package (i.e. the non-sorted ones) and Java's standard
	 * {@code ArrayList}.
	 * <p>
	 * Tests are randomly generated and run numerous times and over a range of
	 * probabilities that operations alter the state of the list.
	 */
	@Test
	public void byIndexOperationsOverChanceOfAlteration(){

		List<List<Integer>> listsToTest = new ArrayList<List<Integer>>();
		listsToTest.add(new ArrayList<Integer>());
		listsToTest.add(new UnsortedList<Integer>());
		listsToTest.add(new PatchWorkArray<Integer>());
		listsToTest.add(new AutoFixingPatchWorkArray<Integer>());

		List<Double> chancesOfAlteration = new LinkedList<Double>();
		chancesOfAlteration.add(0.001);
		chancesOfAlteration.add(0.001);
		chancesOfAlteration.add(0.01);
		chancesOfAlteration.add(0.05);
		for(int i = 0; i <= 3; i++){
			chancesOfAlteration.add(i*0.1);
		}

		int numTests = 10000; //number of times to run the whole test..
		long randomSeed = 1;
		int initialListSize = 100000;
		int numOperations = 100000;
		long [][] timeTaken = new long [listsToTest.size()][chancesOfAlteration.size()];

		for(int testNum = 0; testNum < numTests; testNum++){
			for(int listNum = 0; listNum < listsToTest.size(); listNum++){
				List<Integer> listToTest = listsToTest.get(listNum);
				for(int chanceNum = 0; chanceNum < chancesOfAlteration.size(); chanceNum++){
					double chanceOfAlteration = chancesOfAlteration.get(chanceNum);
					long testTime = addRemoveAndGetByIndexPerformanceTest(
							listToTest, numOperations, initialListSize,
							chanceOfAlteration, new Random(randomSeed));
					timeTaken[listNum][chanceNum] += testTime;
				}
			}
			randomSeed++; //change the seed for next time..
		}

		// print the results in a simple table..
		printResultsTable("byIndexOperationsOverChanceOfAlteration", timeTaken,
				numOperations, numTests, listsToTest, chancesOfAlteration);
	}

	/**
	 * Performs iterator based operator on the regular list implementations in this
	 * package and Java's standard {@code ArrayList} and {@code LinkedList}.
	 * <p>
	 * Tests are randomly generated and run numerous times and over a range of
	 * probabilities that operations alter the state of the list.
	 */
	@Test
	public void iteratorOperationsOverChanceOfAlteration(){

		List<List<Integer>> listsToTest = new ArrayList<List<Integer>>();
		listsToTest.add(new ArrayList<Integer>());
		listsToTest.add(new LinkedList<Integer>());
		listsToTest.add(new UnsortedList<Integer>());
		listsToTest.add(new PatchWorkArray<Integer>());
		listsToTest.add(new AutoFixingPatchWorkArray<Integer>());

		List<Double> chancesOfAlteration = new LinkedList<Double>();
		chancesOfAlteration.add(0.0);
		chancesOfAlteration.add(0.01);
		chancesOfAlteration.add(0.02);
		chancesOfAlteration.add(0.05);
		chancesOfAlteration.add(0.1);
		chancesOfAlteration.add(0.2);
		for(int i = 0; i <= 3; i++){
			chancesOfAlteration.add(i*0.1);
		}

		int numTests = 10000; //number of times to run the whole test..
		long randomSeed = 1;
		int initialListSize = 100000;
		int numIterations = 1;
		long [][] timeTaken = new long [listsToTest.size()][chancesOfAlteration.size()];

		for(int testNum = 0; testNum < numTests; testNum++){
			for(int listNum = 0; listNum < listsToTest.size(); listNum++){
				List<Integer> listToTest = listsToTest.get(listNum);
				for(int chanceNum = 0; chanceNum < chancesOfAlteration.size(); chanceNum++){
					double chanceOfAlteration = chancesOfAlteration.get(chanceNum);
					long testTime = iterateThroughAlteratingPerformanceTest(
							listToTest, numIterations, initialListSize,
							chanceOfAlteration, new Random(randomSeed));
					timeTaken[listNum][chanceNum] += testTime;
				}
			}
			randomSeed++; //change the seed for next time..
		}

		// print the results in a simple table..
		printResultsTable("iteratorOperationsOverChanceOfAlteration", timeTaken,
				numIterations, numTests, listsToTest, chancesOfAlteration);
	}

	//Prints the results in a table, the results should be by list then chance of alteration..
	private static void printResultsTable(String testName, long [][] results,
			int numOperations, int numTests, List<List<Integer>> listsTested,
			List<Double> chancesOfAlteration){

		// print the results in a simple table..
		System.out.println();
		System.out.println(testName);
		System.out.println("Performing " + numOperations + " " + numTests + " times.");
		printStringWithPadding("List Class", 30);
		DecimalFormat df = new DecimalFormat("0.00");
		for(double chanceNum : chancesOfAlteration){
			printStringWithPadding(df.format(chanceNum), 8);
		}
		System.out.println();
		System.out.println();

		for(int i = 0; i < listsTested.size(); i++){
			List<Integer> list = listsTested.get(i);
			String className = list.getClass().getSimpleName();
			printStringWithPadding(className, 30);
			for(int chanceNum = 0; chanceNum < chancesOfAlteration.size(); chanceNum++){
				printStringWithPadding("" + results[i][chanceNum], 8);
			}
			System.out.println();
		}
		System.out.println();
	}

	//Util method for printing a string followed by spaces so that it takes up the given number
	//of characters...
	private static void printStringWithPadding(String toPrint, int charactersToTake){
		System.out.print(toPrint);
		for(int i = 0; i < charactersToTake-toPrint.length(); i++){
			System.out.print(" ");
		}
	}

	/**
	 * Takes the given list, empties it and fills it with the given number of
	 * elements, then loops for numIterations, adding/removing with probability
	 * changeOfAlteration, and getting elements by index otherwise.
	 *
	 * @param listToTest the list to test the performance of.
	 * @param numOperations the number of operations that will be executed an operation on the list.
	 * @param initialSize the initial number of elements to put in the list.
	 * @param chanceOfAlteration the probability that an add or remove operation occurs,
	 *        there is equal probability given to both operations.
	 * @param random the random number generating object to use.
	 * @return the number of milliseconds required to complete the test.
	 */
	private long addRemoveAndGetByIndexPerformanceTest(
			List<Integer> listToTest, int numOperations,
			int initialSize, double chanceOfAlteration, Random rand){

		//initially populate the list..
		populateList(initialSize, listToTest);

		long startTime = System.currentTimeMillis();
		for(int i=0; i < numOperations; i++){
			int listSize = listToTest.size();
			int nextIndex = ((int) Math.round(rand.nextDouble()*listSize)) % listSize;

			double makeAlteration = rand.nextDouble();
			if(makeAlteration <= chanceOfAlteration){
				double addOrRemove = rand.nextDouble();
				if(addOrRemove < 0.5){
					listToTest.add(nextIndex, i);
				} else {
					listToTest.remove(nextIndex);
				}
			} else {
				listToTest.get(nextIndex);
			}
		}
		return System.currentTimeMillis() - startTime;
	}

	//Clears the given list and populates it with the integers 0 to the given size - 1.
	private static void populateList(int size, List<Integer> list){
		list.clear();
		for(int i=0; i< size; i++){
			list.add(i);
		}
	}

	/**
	 * Takes the given list, empties it and fills it with the given number of
	 * elements, then iterates through the entire list {@code #numIterations} times
	 * adding/removing with probability {@code #changeOfAlteration}.
	 *
	 * @param list the list to test the performance of.
	 * @param numIterations the number of times to iterate through the list.
	 * @param initialSize the initial number of elements to put in the list.
	 * @param chanceOfAlteration the probability that an add or remove operation occurs,
	 *        there is equal probability given to both operations.
	 * @param random the random number generating object to use.
	 * @return the number of milliseconds required to complete the test.
	 */
	private long iterateThroughAlteratingPerformanceTest(
			List<Integer> list, int numIterations,
			int initialSize, double chanceOfAlteration, Random random){

		//initially populate the list..
		populateList(initialSize, list);

		long startTime = System.currentTimeMillis();
		for(int i=0; i < numIterations; i++){
			ListIterator<Integer> itr = list.listIterator();
			while(itr.hasNext()){
				@SuppressWarnings("unused")
				int next = itr.next(); //take the next element out auto-unboxing..
				double makeAlteration = random.nextDouble();
				if(makeAlteration <= chanceOfAlteration){
					double addOrRemove = random.nextDouble();
					if(addOrRemove < 0.5){
						itr.add(i); //add any old value..
					} else {
						itr.remove();
					}
				}
			}
		}
		return System.currentTimeMillis() - startTime;
	}

}