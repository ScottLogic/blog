﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Util
{
  public class TextBlockUtils
  {
    /// <summary>
    /// Gets the value of the AutoTooltipProperty dependency property
    /// </summary>
    public static bool GetAutoTooltip(DependencyObject obj)
    {
      return (bool)obj.GetValue(AutoTooltipProperty);
    }

    /// <summary>
    /// Sets the value of the AutoTooltipProperty dependency property
    /// </summary>
    public static void SetAutoTooltip(DependencyObject obj, bool value)
    {
      obj.SetValue(AutoTooltipProperty, value);
    }
   
    /// <summary>
    /// Identified the attached AutoTooltip property. When true, this will set the TextBlock TextTrimming
    /// property to WordEllipsis, and display a tooltip with the full text whenever the text is trimmed.
    /// </summary>
    public static readonly DependencyProperty AutoTooltipProperty = DependencyProperty.RegisterAttached("AutoTooltip",
            typeof(bool), typeof(TextBlockUtils), new PropertyMetadata(false, OnAutoTooltipPropertyChanged));

    private static void OnAutoTooltipPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      TextBlock textBlock = d as TextBlock;
      if (textBlock == null)
        return;

      if (e.NewValue.Equals(true))
      {
        textBlock.TextTrimming = TextTrimming.WordEllipsis;
        ComputeAutoTooltip(textBlock);
        textBlock.SizeChanged += TextBlock_SizeChanged;
      }
      else
      {
        textBlock.SizeChanged -= TextBlock_SizeChanged;
      }
    }

    private static void TextBlock_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      TextBlock textBlock = sender as TextBlock;
      ComputeAutoTooltip(textBlock);
    }

    /// <summary>
    /// Assigns the ToolTip for the given TextBlock based on whether the text is trimmed
    /// </summary>
    private static void ComputeAutoTooltip(TextBlock textBlock)
    {
      FrameworkElement parentElement = VisualTreeHelper.GetParent(textBlock) as FrameworkElement;
      if (parentElement != null)
      {
        if (textBlock.ActualWidth > parentElement.ActualWidth)
        {
          ToolTipService.SetToolTip(textBlock, textBlock.Text);
        }
        else
        {
          ToolTipService.SetToolTip(textBlock, null);
        }
      }
    }
  }
}
