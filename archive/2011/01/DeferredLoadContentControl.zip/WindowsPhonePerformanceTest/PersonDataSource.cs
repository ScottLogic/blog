﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using SCG.General;
using System.Collections;

namespace WindowsPhonePerformanceTest
{
  public class PersonDataSource
  {
    private static List<string> _forenames = new List<string>()
    {
      "Brian", "Fred", "Carol", "Philip", "Ian", "James", "Archie", "Marlon",
      "Josh", "Sacha", "Laurent", "Robert", "Sarra", "Jessica", "Lauren",
      "Mike", "John", "Josh", "Peter", "Lucy", "Anna", "Hannah", "Lilly",
      "Digby", "Elizabeth", "Jonathan", "Andrew", "Alexander", "Christopher",
      "Nicholas", "Addison", "Madison", "Samantha", "Abigail", "Mia", "Ava",
      "Taylor"

    };

    private static List<string> _surnames = new List<string>()
    {
      "Smith", "Blessed", "Barber", "Jones", "Newsome", "Price", "Page", "Pounder",
      "Scott", "Martin", "Wildsmith", "Wilder", "King", "Ferguson", "Batchelor", "Peter",
      "Elliot", "Fritz", "Gregg", "Harper", "Karl", "Lees", "Ousbourne", "Quincey", "Rogers",
      "Rea", "Richards", "Digby", "Daniels", "Phillips", "Eberhardt", "Taylor",
      "Brown", "Johnson", "Walker", "Hill", "Moore", "Baker", "Patel", "Morgan"
    };


    public static IEnumerable CreateList(int count)
    {
      MarkovNameGenerator surnameGen = new MarkovNameGenerator(_surnames, 3, 4);
      MarkovNameGenerator forenameGen = new MarkovNameGenerator(_forenames, 3, 4);

      List<Person> persons = new List<Person>();
      for (int i = 0; i < count; i++)
      {
        persons.Add(new Person()
        {
          Forename = forenameGen.NextName,
          Surname = surnameGen.NextName
        });
      }
      return persons;
    }
  }

  public class PersonCollection: List<Person> 
  {
  }

  public class Person
  {
    public string Surname { get; set; }
    public string Forename { get; set; }
  }
}
