﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;

namespace WP7JumpList
{
  public partial class CustomCategoryAnimation : PhoneApplicationPage
  {
    public CustomCategoryAnimation()
    {
      InitializeComponent();

      var doc = XDocument.Load("WP7JumpList;component/jugglingevents.xml");

      var items = doc.Descendants("event")
                    .Select(el => new JugglingEvent
                    {
                      Description = el.Descendants("description").Single().Value,
                      Date = DateTime.Parse(el.Descendants("time").Single().Descendants("start").Single().Value),
                      Name = el.Descendants("name").Single().Value
                    }).ToList();

      list.ItemsSource = items;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      Button btn = sender as Button;
      list.CategoryButtonTemplate = Resources[btn.Tag.ToString()] as ControlTemplate;
    }
  }
}