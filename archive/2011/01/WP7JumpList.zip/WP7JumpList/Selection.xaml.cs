﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Xml.Linq;
using System.Windows.Data;
using System.IO;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;

namespace WP7JumpList
{
  public partial class Selection : PhoneApplicationPage
  {
    public Selection()
    {
      InitializeComponent();

      var doc = XDocument.Load("WP7JumpList;component/jugglingevents.xml");

      var items = doc.Descendants("event")
                    .Select(el => new JugglingEvent
                    {
                      Description = el.Descendants("description").Single().Value,
                      Date = DateTime.Parse(el.Descendants("time").Single().Descendants("start").Single().Value),
                      Name = el.Descendants("name").Single().Value
                    }).ToList();

      list.ItemsSource = items;

      list.SelectionChanged += List_SelectionChanged;
    }

    private void List_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      Stream stream = TitleContainer.OpenStream("chimes.wav");
      SoundEffect effect = SoundEffect.FromStream(stream);
      FrameworkDispatcher.Update();
      effect.Play();
    }

  }

  public class JugglingEvent
  {
    public string Name { get; set; }
    public DateTime Date { get; set; }
    public string Description { get; set; }

    public int Month
    {
      get
      {
        return Date.Month;
      }
    }
  }

  public class MonthIndexToStringConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      int monthIndex = (int)value;
      DateTime time = new DateTime(2000, monthIndex, 1);
      return time.ToString("MMMM");
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}