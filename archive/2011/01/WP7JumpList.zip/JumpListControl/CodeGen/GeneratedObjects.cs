﻿





using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Media.Animation;




namespace JumpListControl
{
    public partial class JumpList  
    {

        #region ItemsSource
            
        /// <summary>
        /// Gets or sets a collection used to generate the content of the JumpList. This is a Dependency Property.
        /// </summary>    
            
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ItemsSource Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable),
            typeof(JumpList), new PropertyMetadata(null, OnItemsSourcePropertyChanged));
    
        
        private static void OnItemsSourcePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnItemsSourcePropertyChanged(e);
        }
    
        partial void OnItemsSourcePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region ItemTemplate
            
        /// <summary>
        /// Gets or sets the DataTemplate used to display each item. This is a Dependency Property.
        /// </summary>    
            
        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ItemTemplate Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ItemTemplateProperty =
            DependencyProperty.Register("ItemTemplate", typeof(DataTemplate),
            typeof(JumpList), new PropertyMetadata(null, OnItemTemplatePropertyChanged));
    
        
        private static void OnItemTemplatePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnItemTemplatePropertyChanged(e);
        }
    
        partial void OnItemTemplatePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region JumpButtonItemTemplate
            
        /// <summary>
        /// Gets or sets the DataTemplate used to display the Jump buttons. The DataContext of each button is a group key. This is a Dependency Property.
        /// </summary>    
            
        public DataTemplate JumpButtonItemTemplate
        {
            get { return (DataTemplate)GetValue(JumpButtonItemTemplateProperty); }
            set { SetValue(JumpButtonItemTemplateProperty, value); }
        }
    
        /// <summary>
        /// Identifies the JumpButtonItemTemplate Dependency Property.
        /// <summary>
        public static readonly DependencyProperty JumpButtonItemTemplateProperty =
            DependencyProperty.Register("JumpButtonItemTemplate", typeof(DataTemplate),
            typeof(JumpList), new PropertyMetadata(null, OnJumpButtonItemTemplatePropertyChanged));
    
        
        private static void OnJumpButtonItemTemplatePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnJumpButtonItemTemplatePropertyChanged(e);
        }
    
        partial void OnJumpButtonItemTemplatePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region JumpButtonTemplate
            
        /// <summary>
        /// Gets or sets the ControlTemplate for the Jump buttons. This is a Dependency Property.
        /// </summary>    
            
        public ControlTemplate JumpButtonTemplate
        {
            get { return (ControlTemplate)GetValue(JumpButtonTemplateProperty); }
            set { SetValue(JumpButtonTemplateProperty, value); }
        }
    
        /// <summary>
        /// Identifies the JumpButtonTemplate Dependency Property.
        /// <summary>
        public static readonly DependencyProperty JumpButtonTemplateProperty =
            DependencyProperty.Register("JumpButtonTemplate", typeof(ControlTemplate),
            typeof(JumpList), new PropertyMetadata(null, OnJumpButtonTemplatePropertyChanged));
    
        
        private static void OnJumpButtonTemplatePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnJumpButtonTemplatePropertyChanged(e);
        }
    
        partial void OnJumpButtonTemplatePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region CategoryButtonItemTemplate
            
        /// <summary>
        /// Gets or sets the DataTemplate used to display the Category buttons. The DataContext of each Category button is an item from the ICategoryProvider.GetCategoryList list. This is a Dependency Property.
        /// </summary>    
            
        public DataTemplate CategoryButtonItemTemplate
        {
            get { return (DataTemplate)GetValue(CategoryButtonItemTemplateProperty); }
            set { SetValue(CategoryButtonItemTemplateProperty, value); }
        }
    
        /// <summary>
        /// Identifies the CategoryButtonItemTemplate Dependency Property.
        /// <summary>
        public static readonly DependencyProperty CategoryButtonItemTemplateProperty =
            DependencyProperty.Register("CategoryButtonItemTemplate", typeof(DataTemplate),
            typeof(JumpList), new PropertyMetadata(null, OnCategoryButtonItemTemplatePropertyChanged));
    
        
        private static void OnCategoryButtonItemTemplatePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnCategoryButtonItemTemplatePropertyChanged(e);
        }
    
        partial void OnCategoryButtonItemTemplatePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region CategoryButtonTemplate
            
        /// <summary>
        /// Gets or sets the ControlTemplate for the Category buttons. This is a Dependency Property.
        /// </summary>    
            
        public ControlTemplate CategoryButtonTemplate
        {
            get { return (ControlTemplate)GetValue(CategoryButtonTemplateProperty); }
            set { SetValue(CategoryButtonTemplateProperty, value); }
        }
    
        /// <summary>
        /// Identifies the CategoryButtonTemplate Dependency Property.
        /// <summary>
        public static readonly DependencyProperty CategoryButtonTemplateProperty =
            DependencyProperty.Register("CategoryButtonTemplate", typeof(ControlTemplate),
            typeof(JumpList), new PropertyMetadata(null, OnCategoryButtonTemplatePropertyChanged));
    
        
        private static void OnCategoryButtonTemplatePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnCategoryButtonTemplatePropertyChanged(e);
        }
    
        partial void OnCategoryButtonTemplatePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region CategoryProvider
            
        /// <summary>
        /// Gets or sets a category provider which groups the items in the JumpList and specifies the categories in the jump menu. This is a Dependency Property.
        /// </summary>    
            
        public ICategoryProvider CategoryProvider
        {
            get { return (ICategoryProvider)GetValue(CategoryProviderProperty); }
            set { SetValue(CategoryProviderProperty, value); }
        }
    
        /// <summary>
        /// Identifies the CategoryProvider Dependency Property.
        /// <summary>
        public static readonly DependencyProperty CategoryProviderProperty =
            DependencyProperty.Register("CategoryProvider", typeof(ICategoryProvider),
            typeof(JumpList), new PropertyMetadata(null, OnCategoryProviderPropertyChanged));
    
        
        private static void OnCategoryProviderPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnCategoryProviderPropertyChanged(e);
        }
    
        partial void OnCategoryProviderPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region JumpButtonStyle
            
        /// <summary>
        /// Gets or sets the style applied to the Jump buttons. This should be a style with a TargetType of Button. This is a Dependency Property.
        /// </summary>    
            
        public Style JumpButtonStyle
        {
            get { return (Style)GetValue(JumpButtonStyleProperty); }
            set { SetValue(JumpButtonStyleProperty, value); }
        }
    
        /// <summary>
        /// Identifies the JumpButtonStyle Dependency Property.
        /// <summary>
        public static readonly DependencyProperty JumpButtonStyleProperty =
            DependencyProperty.Register("JumpButtonStyle", typeof(Style),
            typeof(JumpList), new PropertyMetadata(null, OnJumpButtonStylePropertyChanged));
    
        
        private static void OnJumpButtonStylePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnJumpButtonStylePropertyChanged(e);
        }
    
        partial void OnJumpButtonStylePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region CategoryButtonStyle
            
        /// <summary>
        /// Gets or sets the style applied to the Category buttons. This should be a style with a TargetType of Button. This is a Dependency Property.
        /// </summary>    
            
        public Style CategoryButtonStyle
        {
            get { return (Style)GetValue(CategoryButtonStyleProperty); }
            set { SetValue(CategoryButtonStyleProperty, value); }
        }
    
        /// <summary>
        /// Identifies the CategoryButtonStyle Dependency Property.
        /// <summary>
        public static readonly DependencyProperty CategoryButtonStyleProperty =
            DependencyProperty.Register("CategoryButtonStyle", typeof(Style),
            typeof(JumpList), new PropertyMetadata(null, OnCategoryButtonStylePropertyChanged));
    
        
        private static void OnCategoryButtonStylePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnCategoryButtonStylePropertyChanged(e);
        }
    
        partial void OnCategoryButtonStylePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region CategoryTileAnimationDelay
            
        /// <summary>
        /// Gets or sets the time delay in milliseconds between firing the animations which reveal the Category button. This is a Dependency Property.
        /// </summary>    
            
        public double CategoryTileAnimationDelay
        {
            get { return (double)GetValue(CategoryTileAnimationDelayProperty); }
            set { SetValue(CategoryTileAnimationDelayProperty, value); }
        }
    
        /// <summary>
        /// Identifies the CategoryTileAnimationDelay Dependency Property.
        /// <summary>
        public static readonly DependencyProperty CategoryTileAnimationDelayProperty =
            DependencyProperty.Register("CategoryTileAnimationDelay", typeof(double),
            typeof(JumpList), new PropertyMetadata(20.0, OnCategoryTileAnimationDelayPropertyChanged));
    
        
        private static void OnCategoryTileAnimationDelayPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnCategoryTileAnimationDelayPropertyChanged(e);
        }
    
        partial void OnCategoryTileAnimationDelayPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region ScrollDuration
            
        /// <summary>
        /// Gets or sets the time taken to 'jump' to a new list location in milliseconds. This is a Dependency Property.
        /// </summary>    
            
        public double ScrollDuration
        {
            get { return (double)GetValue(ScrollDurationProperty); }
            set { SetValue(ScrollDurationProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ScrollDuration Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ScrollDurationProperty =
            DependencyProperty.Register("ScrollDuration", typeof(double),
            typeof(JumpList), new PropertyMetadata(200.0, OnScrollDurationPropertyChanged));
    
        
        private static void OnScrollDurationPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnScrollDurationPropertyChanged(e);
        }
    
        partial void OnScrollDurationPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region SelectedItem
            
        /// <summary>
        /// Gets or sets the selected item. This is a Dependency Property.
        /// </summary>    
            
        public object SelectedItem
        {
            get { return (object)GetValue(SelectedItemProperty); }
            set { SetValue(SelectedItemProperty, value); }
        }
    
        /// <summary>
        /// Identifies the SelectedItem Dependency Property.
        /// <summary>
        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(object),
            typeof(JumpList), new PropertyMetadata(null, OnSelectedItemPropertyChanged));
    
        
        private static void OnSelectedItemPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnSelectedItemPropertyChanged(e);
        }
    
        partial void OnSelectedItemPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region IsCategoryViewShown
            
        /// <summary>
        /// Gets or sets whether the category view is currently shown. This is a Dependency Property.
        /// </summary>    
            
        public bool IsCategoryViewShown
        {
            get { return (bool)GetValue(IsCategoryViewShownProperty); }
            set { SetValue(IsCategoryViewShownProperty, value); }
        }
    
        /// <summary>
        /// Identifies the IsCategoryViewShown Dependency Property.
        /// <summary>
        public static readonly DependencyProperty IsCategoryViewShownProperty =
            DependencyProperty.Register("IsCategoryViewShown", typeof(bool),
            typeof(JumpList), new PropertyMetadata(false, OnIsCategoryViewShownPropertyChanged));
    
        
        private static void OnIsCategoryViewShownPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnIsCategoryViewShownPropertyChanged(e);
        }
    
        partial void OnIsCategoryViewShownPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region JumpListItemStyle
            
        /// <summary>
        /// Gets or sets the style applied to each jump list item. This is a Dependency Property.
        /// </summary>    
            
        public Style JumpListItemStyle
        {
            get { return (Style)GetValue(JumpListItemStyleProperty); }
            set { SetValue(JumpListItemStyleProperty, value); }
        }
    
        /// <summary>
        /// Identifies the JumpListItemStyle Dependency Property.
        /// <summary>
        public static readonly DependencyProperty JumpListItemStyleProperty =
            DependencyProperty.Register("JumpListItemStyle", typeof(Style),
            typeof(JumpList), new PropertyMetadata(null, OnJumpListItemStylePropertyChanged));
    
        
        private static void OnJumpListItemStylePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            JumpList myClass = d as JumpList;
            
            myClass.OnJumpListItemStylePropertyChanged(e);
        }
    
        partial void OnJumpListItemStylePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
     
    }
}


