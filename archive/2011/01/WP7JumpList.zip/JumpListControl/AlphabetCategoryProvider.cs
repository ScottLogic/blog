﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace JumpListControl
{
  /// <summary>
  /// A category provider that categorizes items based on the first character of the
  /// property named via the PropertyName property.
  /// </summary>
  public class AlphabetCategoryProvider : ICategoryProvider
  {
    /// <summary>
    /// Gets or sets the name of the property that is used to assign each item
    /// to a category.
    /// </summary>
    public string PropertyName { get; set;}

    public object GetCategoryForItem(object item)
    {
      var propInfo = item.GetType().GetProperty(PropertyName);
      object propertyValue = propInfo.GetValue(item, null);
      return ((string)propertyValue).Substring(0, 1).ToUpper();
    }

    public List<object> GetCategoryList(IEnumerable items)
    {
      return Enumerable.Range(0, 26)
              .Select(index => Convert.ToChar((Convert.ToInt32('A') + index)).ToString())
              .Cast<object>()
              .ToList();
    }
  }
}
