﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace JumpListControl
{
  /// <summary>
  /// Assigns items to categories based on the value of their PropertyName property.
  /// </summary>
  public class DistinctPropertyValueCategoryProvider : ICategoryProvider
  {
    /// <summary>
    /// Gets or sets the name of the property that is used to assign each item
    /// to a category.
    /// </summary>
    public string PropertyName { get; set; }

    public object GetCategoryForItem(object item)
    {
      var propInfo = item.GetType().GetProperty(PropertyName);
      return propInfo.GetValue(item, null);
    }

    public List<object> GetCategoryList(IEnumerable items)
    {
      return items.Cast<object>()
                  .Select(item => GetCategoryForItem(item))
                  .Distinct()
                  .OrderBy(cat => cat)
                  .ToList();
    }
  }
}
