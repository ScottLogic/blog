﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Security.Cryptography;
using System.Windows.Input;
using System.Windows;

namespace MVVM.ViewModel
{
    /// <summary>
    /// 
    /// </summary>
    internal class MainWindowViewModel : ViewModelBase
    {
        private Model.MainWindowModel _model;

        /// <summary>
        /// When this event is raised, the main window will be closed. See App.xaml.cs.
        /// </summary>
        internal event EventHandler RequestClose;

        /// <summary>
        /// Command for closing the application. Bind this to an 'exit' UI input.
        /// </summary>
        public ICommand CloseCommand { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        internal MainWindowViewModel()
        {
            _model = new Model.MainWindowModel();

            //The predicate argument can be used, for example, to show a close confirmation dialog.
            CloseCommand = new RelayCommand(o => OnRequestClose(), o => true);
        }

        private void OnRequestClose()
        {
            if (RequestClose != null)
            {
                RequestClose(this, new EventArgs());
            }
        }
    }
}
