﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVM.Model
{
    /// <summary>
    /// 
    /// </summary>
    internal class MainWindowModel : IDisposable
    {

        /// <summary>
        /// 
        /// </summary>
        internal MainWindowModel()
        {
            //If needed, populate the model properties from storage, or via constructor.
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {

        }
    }
}
