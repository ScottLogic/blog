﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeGen
{
    [AttributeUsage(AttributeTargets.Class , AllowMultiple = true)]
    public class DependencyPropertyDecl : Attribute
    {
        public DependencyPropertyDecl(string name, Type type, object defaultValue, string summary)
        {
            this.name = name;
            this.type = type;
            this.defaultValue = defaultValue;
            this.summary = summary;
        }

        public string name;
        public Type type;
        public object defaultValue;
        public string summary;
    }
}
