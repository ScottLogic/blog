﻿using System.Collections.Generic;
using System.Collections;

namespace JumpListControl
{
  /// <summary>
  /// A category provider assigns items to categories and details
  /// the full category list for a set of items.
  /// </summary>
  public interface ICategoryProvider
  {
    /// <summary>
    /// Gets the category for the given items
    /// </summary>
    object GetCategoryForItem(object item);

    /// <summary>
    /// Gets the full list of categories for the given items.
    /// </summary>
    List<object> GetCategoryList(IEnumerable items);
  }
}
