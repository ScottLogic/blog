﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using SCG.General;
using System.Xml.Linq;

namespace WP7JumpList
{
  public partial class DemoPageTwo : PhoneApplicationPage
  {
   
   // Constructor
    public DemoPageTwo()
    {
      InitializeComponent();

      var doc = XDocument.Load("WP7JumpList;component/jugglingclubs.xml");

      var items = doc.Descendants("club")
                   .Select(el => new JugglingClub {
                        Name = el.Descendants("name").Single().Value,
                        Id = int.Parse(el.Attribute("id").Value),
                        Country = el.Descendants("country").Single().Value
                      })
                   .Where(i => i.Id % 2==0) // halve the number of items, 800 is too many!
                   .ToList();

      list.ItemsSource = items;      
    }
  }

  public class JugglingClub
  {
    public string Name { get; set; }
    public int Id { get; set; }
    public string Country { get; set; }
  }

}