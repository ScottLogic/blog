﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using SCG.General;
using System.Collections.ObjectModel;

namespace WP7JumpList
{
  public partial class UpdatingTheItemsSource : PhoneApplicationPage
  {

    private ObservableCollection<Person> _people;

    // Constructor
    public UpdatingTheItemsSource()
    {
      InitializeComponent();

      _people = new ObservableCollection<Person>();
      foreach (Person person in PersonDataSource.CreateList(5))
      {
        _people.Add(person);
      }
      list.ItemsSource = _people;

    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _people.Add(PersonDataSource.CreateList(1).Cast<Person>().Single());
    }
  }


}