﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Diagnostics;
using Visiblox.Charts;
using System.ComponentModel;

namespace VisibloxRangeControl
{
  public partial class DateTimeRangeControl : UserControl, INotifyPropertyChanged
  {
    #region Range DP

    /// <summary>
    /// Gets / sets the Range
    /// </summary>
    public DateTimeRange Range
    {
      get { return (DateTimeRange)GetValue(RangeProperty); }
      set { SetValue(RangeProperty, value); }
    }

    DependencyProperty RangeProperty = DependencyProperty.Register("Range", typeof(DateTimeRange),
      typeof(DateTimeRangeControl), new PropertyMetadata(null, OnRangePropertyChanged));

    private static void OnRangePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      var ctrl = (DateTimeRangeControl)d;
      ctrl.OnPropertyChanged("Range");
      ctrl.UpdateExposedBounds();
    }

    #endregion

    #region Bounds DP

    /// <summary>
    /// Gets / sets the Bounds
    /// </summary>
    public DateTimeRange Bounds
    {
      get { return (DateTimeRange)GetValue(BoundsProperty); }
      set { SetValue(BoundsProperty, value); }
    }

    DependencyProperty BoundsProperty = DependencyProperty.Register("Bounds", typeof(DateTimeRange),
      typeof(DateTimeRangeControl), new PropertyMetadata(null, OnBoundsPropertyChanged));

    private static void OnBoundsPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((DateTimeRangeControl)d).OnPropertyChanged("Bounds");
    }

    #endregion

    #region IsUpdateOnMouseUp DP

    /// <summary>
    /// Gets / sets whether the Bounds property is updated on mouse up, otherwise
    /// it is updated continuously as the user drags the thumb controls.
    /// </summary>
    public bool IsUpdateOnMouseUp
    {
      get { return (bool)GetValue(IsUpdateOnMouseUpProperty); }
      set { SetValue(IsUpdateOnMouseUpProperty, value); }
    }

    DependencyProperty IsUpdateOnMouseUpProperty = DependencyProperty.Register("IsUpdateOnMouseUp", typeof(bool),
      typeof(DateTimeRangeControl), new PropertyMetadata(true));
    
    #endregion
    
    public DateTimeRangeControl()
    {
      InitializeComponent();

      this.SizeChanged += new SizeChangedEventHandler(DateTimeRangeControl_SizeChanged);
    }

    private void DateTimeRangeControl_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      UpdateExposedBounds();
    }

    private void UpdateExposedBounds()
    {
      if (Range == null)
        return;

      double deltaMinutes = (Range.Maximum - Range.Minimum).TotalMinutes;
      double width = this.ActualWidth;

      double leftThumbPos = LayoutRoot.ColumnDefinitions[0].Width.Value;
      double rightThumbPos = LayoutRoot.ColumnDefinitions[2].Width.Value;

      DateTime upper = Range.Maximum.AddMinutes(-deltaMinutes * (rightThumbPos / width));
      DateTime lower = Range.Minimum.AddMinutes(deltaMinutes * (leftThumbPos / width));
      Bounds = new DateTimeRange(lower, upper);
    }

    /// <summary>
    /// Handles dragging of the left hand thumb control
    /// </summary>
    private void LeftThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
      // obtain the column width and apply an offset
      var columnDef = LayoutRoot.ColumnDefinitions[0];
      var width = columnDef.Width.Value;
      width += e.HorizontalChange;

      // prevent the user from dragging the thumb outside of the control
      if (width < 0)
      {
        width = 0;
      }

      // prevent the overlap of the left + right regions
      if (width + LayoutRoot.ColumnDefinitions[2].Width.Value + 20 > this.ActualWidth)
      {
        width = columnDef.Width.Value;
      }

      // update the column width
      columnDef.Width = new GridLength(width);

      if (!IsUpdateOnMouseUp)
      {
        UpdateExposedBounds();
      }
    }

    /// <summary>
    /// Handles dragging of the right thumb control
    /// </summary>
    private void RightThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
      var columnDef = LayoutRoot.ColumnDefinitions[2];
      var width = columnDef.Width.Value;
      width -= e.HorizontalChange;

      if (width < 0)
      {
        width = 0;
      }
      if (width + LayoutRoot.ColumnDefinitions[0].Width.Value + 20 > this.ActualWidth)
      {
        width = columnDef.Width.Value;
      }

      columnDef.Width = new GridLength(width);

      if (!IsUpdateOnMouseUp)
      {
        UpdateExposedBounds();
      }
    }

    /// <summary>
    /// Handles dragging of the centre thumb control
    /// </summary>
    private void CentreThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
      var rightColumnDef = LayoutRoot.ColumnDefinitions[2];
      var rightWidth = rightColumnDef.Width.Value;
      var leftColumnDef = LayoutRoot.ColumnDefinitions[0];
      var leftWidth = leftColumnDef.Width.Value;

      double delta = e.HorizontalChange;
      if (e.HorizontalChange > 0)
      {
        if (rightWidth - delta < 0)
        {
          delta = rightWidth;
        }
      }
      else
      {
        if (leftWidth + delta < 0)
        {
          delta = -leftWidth;
        }
      }
      
      rightWidth -= delta;
      leftWidth += delta;

      leftColumnDef.Width = new GridLength(leftWidth);
      rightColumnDef.Width = new GridLength(rightWidth);

      if (!IsUpdateOnMouseUp)
      {
        UpdateExposedBounds();
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }

    private void Thumb_DragCompleted(object sender, DragCompletedEventArgs e)
    {
      if (IsUpdateOnMouseUp)
      {
        UpdateExposedBounds();
      }

    }

  }
}
