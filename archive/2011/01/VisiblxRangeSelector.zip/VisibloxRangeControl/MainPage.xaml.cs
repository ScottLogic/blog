﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using System.ComponentModel;
using System.Reflection;
using System.IO;
using System.Diagnostics;

namespace VisibloxRangeControl
{
  public partial class MainPage : UserControl
  {
    private static int count = 1000;

    private Random _rand = new Random();

    public MainPage()
    {
      InitializeComponent();

      var assembly = this.GetType().Assembly;
      var dataSeries = new DataSeries<DateTime, double>();
      var date = new DateTime(1981,1,1);
      var maxStream = assembly.GetManifestResourceStream("VisibloxRangeControl.melbmax.dat");
      var minStream = assembly.GetManifestResourceStream("VisibloxRangeControl.melbmin.dat");
      using (StreamReader minReader = new StreamReader(minStream))
      using (StreamReader maxReader = new StreamReader(maxStream))
      {
        while (minReader.Peek() > 0)
        {
          string minLine = minReader.ReadLine();
          string maxLine = maxReader.ReadLine();
          var yValues = new Dictionary<object, double>() {
            {BandSeries.Upper, double.Parse(maxLine)},
            {BandSeries.Lower, double.Parse(minLine)}
          };
          dataSeries.Add(new MultiValuedDataPoint<DateTime, double>(date, yValues));
          date = date.AddDays(1);
        }
      }
            
      chart.Series[0].DataSeries = dataSeries;

      var monthlyAverage = dataSeries.GroupBy(pt => new DateTime(pt.X.Year, pt.X.Month, 1))
                                  .Select(group => new DataPoint<DateTime, double>
                                  {
                                    X = group.Key,
                                    Y = group.Select(pt => (double)pt[BandSeries.Upper]).Average()
                                  });

      chartNavigator.Series[0].DataSeries = new DataSeries<DateTime, double>(monthlyAverage);

      rangeControl.PropertyChanged += RangeControl_PropertyChanged;

    }

    private void RangeControl_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (rangeControl.Bounds == null)
        return;

      DateTimeAxis xAxis = chart.XAxis as DateTimeAxis;

      double lower = xAxis.GetDataValueAsRenderPositionWithZoom(rangeControl.Bounds.Minimum);
      double upper = xAxis.GetDataValueAsRenderPositionWithZoom(rangeControl.Bounds.Maximum);
      var zoom = xAxis.GetZoom(lower, upper);
      xAxis.Zoom = zoom;
    }

  }
}
