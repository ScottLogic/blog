﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WP7MazeGame
{
  class Maze
  {
    public const int UP = 1;
    public const int LEFT = 2;
    public const int RIGHT = 4;
    public const int DOWN = 8;

    // The maze array.
    public int[,] cells;
    int rows;
    int cols;

    // Number of cells remaining to be filled.
    int unused;

    public Maze(int rows, int cols)
    {
      this.rows = rows;
      this.cols = cols;

      cells = new int[cols, rows];

      for (int i = 0; i < cols; ++i)
        for (int j = 0; j < rows; ++j)
          cells[i, j] = 0;

      // corners
      cells[0, 0] = DOWN | RIGHT;
      cells[cols - 1, 0] = DOWN | LEFT;
      cells[0, rows - 1] = UP | RIGHT;
      cells[cols - 1, rows - 1] = UP | LEFT;

      // Sides
      for (int i = 1; i < rows - 1; ++i)
      {
        cells[0, i] = DOWN | UP;
        cells[cols - 1, i] = DOWN | UP;
      }
      for (int i = 1; i < cols - 1; ++i)
      {
        cells[i, 0] = LEFT | RIGHT;
        cells[i, rows - 1] = LEFT | RIGHT;
      }

      // Openings
      cells[cols / 2, 0] = UP | LEFT;
      cells[cols / 2 + 1, 0] = UP | RIGHT;
      cells[cols / 2, rows - 1] = DOWN | LEFT;
      cells[cols / 2 + 1, rows - 1] = DOWN | RIGHT;

      unused = (cols - 2) * (rows - 2);

      Generate();
    }

    // Offscreen buffer.
   /*Bitmap image;
    Graphics graphics;

    /// <summary>Draw the maze on an offscreen image buffer.</summary>
    void Draw()
    {
      const int CELLSIZE = 8;

      int xsize = cols * CELLSIZE;
      int ysize = rows * CELLSIZE;

      image = new Bitmap(xsize, ysize);
      graphics = Graphics.FromImage(image);

      graphics.Clear(Color.DarkBlue);

      Pen pen = new Pen(Color.Yellow);

      for (int i = 0; i < cols; ++i)
        for (int j = 0; j < rows; ++j)
        {
          int room = maze[i, j];
          if ((room & UP) != 0)
            graphics.DrawLine(pen,
                  i * CELLSIZE + CELLSIZE / 2,
                  j * CELLSIZE,
                  i * CELLSIZE + CELLSIZE / 2,
                  j * CELLSIZE + CELLSIZE / 2 - 1);
          if ((room & DOWN) != 0)
            graphics.DrawLine(pen,
                  i * CELLSIZE + CELLSIZE / 2,
                  j * CELLSIZE + CELLSIZE / 2,
                  i * CELLSIZE + CELLSIZE / 2,
                  j * CELLSIZE + CELLSIZE - 1);
          if ((room & RIGHT) != 0)
            graphics.DrawLine(pen,
                  i * CELLSIZE + CELLSIZE / 2,
                  j * CELLSIZE + CELLSIZE / 2,
                  i * CELLSIZE + CELLSIZE - 1,
                  j * CELLSIZE + CELLSIZE / 2);
          if ((room & LEFT) != 0)
            graphics.DrawLine(pen,
                  i * CELLSIZE,
                  j * CELLSIZE + CELLSIZE / 2,
                  i * CELLSIZE + CELLSIZE / 2 - 1,
                  j * CELLSIZE + CELLSIZE / 2);
        }
    }

    /// <summary>Paint the image onto the specified graphics
    /// context</summary>
    public void Paint(Graphics g, int x, int y)
    {
      g.DrawImage(image, x, y);
    }*/

    /// <summary>Generate a random maze.</summary>
    /// <remarks>We start at an empty cell in the maze. We create a wall by
    /// doing a random walk through the maze. When we hit an existing wall,
    /// we stop. 
    /// <para>Theory: Since the walk started on an empty cell, that path
    /// can never bisect the maze and so there should still be a solution
    /// to the maze after we add each wall.</para></remarks>

    void Generate()
    {
      // Maximum number of steps to save so that the maze crawler
      // does not close back on itself. Low values may affect the
      // quality of the maze.
      const int Nsave = 20;

      // Array keeping track of the directions the random walk took in
      // the past Nsave steps.
      int[] prevNdir = new int[Nsave];

      // Table stating what we should add to the current row
      // and column to move in that direction.
      int[,] moveTable = { { 0, -1 }, { -1, 0 }, { 1, 0 }, { 0, 1 } };

      // The location of the random walker.
      int curx, cury;

      Random random = new Random(System.Environment.TickCount);

      while (unused > 0)
      {

        // Find an empty cell.
        do
        {
          curx = random.Next(cols);
          cury = random.Next(rows);
        } while (cells[curx, cury] != 0);

        for (int i = 0; i < Nsave; ++i)
          prevNdir[i] = 0;
        --unused;

        for (; ; )
        {
          // 1 << dir will be UP, DOWN, LEFT, RIGHT.
          // Those direction constants are chosen so that
          // the dir values for UP and DOWN and the xor of
          // each other and so are the dir values for LEFT
          // and RIGHT.
          int dir;

          for (int i = 0; i < Nsave - 1; ++i)
            prevNdir[i] = prevNdir[i + 1];

          bool[] gotdir = new bool[4];

          do
          {
            // Choose a direction that doesn't go back on the
            // previous step.
            do
            {
              dir = random.Next(4);
            } while (dir == (prevNdir[Nsave - 2] ^ 3));
            prevNdir[Nsave - 1] = dir;

            for (int i = 0; i < 4; ++i)
              gotdir[i] = false;
            for (int i = 0; i < Nsave; ++i)
              gotdir[prevNdir[i]] = true;

            // Avoid loops within the past nsave steps by
            // making sure not all four directions are used.
            // This is more restrictive than necessary but 
            // it works okay.
          } while (gotdir[0] && gotdir[1] && gotdir[2] && gotdir[3]);

          // Add the wall.
          cells[curx, cury] |= (1 << dir);

          // Go to the next cell.
          curx += moveTable[dir, 0];
          cury += moveTable[dir, 1];

          // Reached another wall?
          bool exitcond = (cells[curx, cury] != 0);

          // Add wall segment needed to join with the previous
          // cell.
          cells[curx, cury] |= (1 << (dir ^ 3));

          if (exitcond)
            break;

          --unused;
        }
      }
    } // Generate

  } // class Maze
}
