﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Spritehand.FarseerHelper;
using Microsoft.Devices.Sensors;
using System.Windows.Threading;
using System.Windows.Interactivity;
using Spritehand.PhysicsBehaviors;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using Microsoft.Xna.Framework;

namespace WP7MazeGame
{
  public partial class MainPage : PhoneApplicationPage
  {
    PhysicsControllerMain _physicsController;

    Accelerometer _sensor;

    SoundEffect _effect;

    int _mazeSize = 9;

    // Constructor
    public MainPage()
    {
      InitializeComponent();

      // locate the physics controller
      _physicsController = mazeContainer.GetValue(PhysicsControllerMain.PhysicsControllerProperty) as PhysicsControllerMain;
      
      // load the WAV file
      Stream stream = TitleContainer.OpenStream("boing1.wav");
      _effect = SoundEffect.FromStream(stream);
      FrameworkDispatcher.Update();

      // play on each collision
      _physicsController.Collision += (s,e) => _effect.Play(); 

      HandleAccelerometer();

      DeferredExecute(2.0, CreateMaze);
    }

    private void HandleAccelerometer()
    {
      _sensor = new Accelerometer();
      _sensor.Start();

      // 10 times a second, update the gravity
      var gtimer = new DispatcherTimer();
      gtimer.Interval = TimeSpan.FromSeconds(0.1);
      gtimer.Tick += (s, e) =>
      {
        if (_physicsController.Simulator != null)
        {
          _physicsController.Simulator.Gravity.Y = 10 * -_sensor.CurrentValue.Acceleration.Y;
          _physicsController.Simulator.Gravity.X = 10 * _sensor.CurrentValue.Acceleration.X;
        }
      };
      gtimer.Start();
    }
    

    private void DeferredExecute(double seconds, Action action)
    {
      var timer = new DispatcherTimer();
      timer.Interval = TimeSpan.FromSeconds(seconds);
      timer.Tick += (s, e2) =>
        {
          action();
          timer.Stop();
        };
      timer.Start();
    }

    private void CreateMaze()
    {
      // compute the number of rows / cols
      double ratio = mazeContainer.ActualHeight / mazeContainer.ActualWidth;
      int cols = _mazeSize;
      int rows = (int)((double)cols * ratio);
      double cellWidth = mazeContainer.ActualWidth / cols;

      // create the maze
      Maze maze = new Maze(rows, cols);

      // render the maze
      for (int i = 0; i < cols; ++i)
      {
        for (int j = 0; j < rows; ++j)
        {
          var room = maze.cells[i, j];
          if ((room & Maze.UP) != 0)
            DrawLine(i * cellWidth + cellWidth / 2,
                   j * cellWidth,
                   i * cellWidth + cellWidth / 2,
                   j * cellWidth + cellWidth / 2 - 1);
          if ((room & Maze.DOWN) != 0)
            DrawLine(i * cellWidth + cellWidth / 2,
                  j * cellWidth + cellWidth / 2,
                  i * cellWidth + cellWidth / 2,
                  j * cellWidth + cellWidth - 1);
          if ((room & Maze.RIGHT) != 0)
            DrawLine(i * cellWidth + cellWidth / 2,
                  j * cellWidth + cellWidth / 2,
                  i * cellWidth + cellWidth - 1,
                  j * cellWidth + cellWidth / 2);
          if ((room & Maze.LEFT) != 0)
            DrawLine(i * cellWidth,
                  j * cellWidth + cellWidth / 2,
                  i * cellWidth + cellWidth / 2 - 1,
                  j * cellWidth + cellWidth / 2);
        }
      }

      // add our ball
      Ellipse ball = new Ellipse()
      {
        Width = cellWidth * 0.7,
        Height = cellWidth * 0.7,
        Fill = this.Resources["brush"] as Brush
      };
      Canvas.SetLeft(ball, ((cols / 2) + 0.7) * cellWidth);
      Canvas.SetTop(ball, 0);
      mazeContainer.Children.Add(ball);

      AddPhysicsBody(ball, false);

      ApplicationTitle.Text = "";
    }

    /// <summary>
    /// Uses Physics Helper to create a physics body for the given element
    /// </summary>
    private void AddPhysicsBody(FrameworkElement element, bool isStatic)
    {
      var behaviorCollection = Interaction.GetBehaviors(element);
      behaviorCollection.Add(new PhysicsObjectBehavior()
      {
        IsStatic = isStatic
      });

      var physicsObject = element.GetValue(PhysicsObjectMain.PhysicsObjectProperty) as PhysicsObjectMain;
      _physicsController.AddPhysicsBody(physicsObject);
    }
   
    private void DrawLine(double x1, double y1, double x2, double y2)
    {
      double thickness = 4.0;

      double width = x2 - x1 + thickness;
      if (width == 0.0) width = thickness;

      double height = y2 - y1 + thickness;
      if (height == 0.0) height = thickness;

      var rec = new System.Windows.Shapes.Rectangle()
      {
        Fill = new SolidColorBrush(Colors.Red),
        Width = width,
        Height = height
      };
      Canvas.SetLeft(rec, x1);
      Canvas.SetTop(rec, y1);
      mazeContainer.Children.Add(rec);

      AddPhysicsBody(rec, true);
    }

  
  }
}