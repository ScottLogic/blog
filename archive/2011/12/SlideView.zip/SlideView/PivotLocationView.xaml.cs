﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.ComponentModel;
using Microsoft.Phone.Controls;

namespace SlideView
{
  public partial class PivotLocationView : UserControl
  {
    public PivotLocationView()
    {
      InitializeComponent();
    }

    #region source DP

    /// <summary>
    /// Gets or sets the Pivot which is the source of this location view.
    /// </summary>
    public Pivot Source
    {
      get { return (Pivot)GetValue(SourceProperty); }
      set { SetValue(SourceProperty, value); }
    }

    public static readonly DependencyProperty SourceProperty =
        DependencyProperty.Register("Source", typeof(Pivot),
        typeof(PivotLocationView), new PropertyMetadata(null, OnSourcePropertyChanged));

    private static void OnSourcePropertyChanged(DependencyObject d,
        DependencyPropertyChangedEventArgs e)
    {
      PivotLocationView myClass = d as PivotLocationView;

      // create a view model for this pivot
      var viewModel = new PivotLocationViewModel(e.NewValue as Pivot);
      myClass.LayoutRoot.DataContext = viewModel;
    }

    #endregion
  }

  public class PivotLocationViewModel
  {
    private Pivot _pivot;

    public PivotLocationViewModel()
    {
    }

    public PivotLocationViewModel(Pivot pivot)
    {
      PivotItems = new PivotItemViewModelCollection();
      SetPivot(pivot);
    }

    /// <summary>
    /// Gets or sets the collection of child view-models
    /// </summary>
    public PivotItemViewModelCollection PivotItems { get; set; }

    private void SetPivot(Pivot pivot)
    {
      _pivot = pivot;

      // handle selection changed
      pivot.SelectionChanged += Pivot_SelectionChanged;

      // create a view model for each pivot item.
      for(int i=0;i<pivot.Items.Count;i++)
      {
        PivotItems.Add(new PivotItemViewModel());
      }

      // set the initial selection
      PivotItems[_pivot.SelectedIndex].IsSelected = true;
    }

    /// <summary>
    /// Handle selection changes to update the view model
    /// </summary>
    private void  Pivot_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
 	    var selectedModel = PivotItems.SingleOrDefault(p => p.IsSelected);
      if (selectedModel != null)
        selectedModel.IsSelected = false;

      PivotItems[_pivot.SelectedIndex].IsSelected = true;
    }

  }

  /// <summary>
  /// A collection of PivotItemViewModel instances
  /// </summary>
  public class PivotItemViewModelCollection : List<PivotItemViewModel>
  {
  }

  /// <summary>
  /// A view model for each 'pip'
  /// </summary>
  public class PivotItemViewModel : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }

    #endregion

    private bool _isSelected;

    public bool IsSelected
    {
      get { return _isSelected; }
      set
      {
        if (_isSelected == value)
          return;

        _isSelected = value;
        OnPropertyChanged("IsSelected");

        Color = IsSelected ? Colors.Black : Colors.White;
      }
    }

    private Color _color;

    public Color Color
    {
      get { return _color; }
      set
      {
        _color = value;
        OnPropertyChanged("Color");
      }
    }

  }
}
