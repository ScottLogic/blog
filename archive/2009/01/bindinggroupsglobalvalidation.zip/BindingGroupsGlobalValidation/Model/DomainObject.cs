﻿using System;
using System.ComponentModel;


namespace GlobalWPFValidation
{
    /// <summary>
    /// /// NOTE: this is a modified version of a class that appeared in Sacha's original article.
    /// 
    /// The class all domain objects must inherit from. 
    /// 
    /// INotifyPropertyChanged : Provides change notification to allow WPF bindings to work, without the 
    /// need to inherit from a WPF specifio class. So this will work even with WinForms/ASP .NET
    /// </summary>
    [Serializable()]
    public abstract class DomainObject : INotifyPropertyChanged
    {
        #region Data
        protected int id;
        #endregion

        #region Ctor
        /// <summary>
        /// Constructor.
        /// </summary>
        public DomainObject()
        {



        }
        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the Address primary key value.
        /// </summary>
        public int ID
        {
            get { return id; }
            set
            {
                id = value;
                NotifyChanged("ID");
            }
        }
        #endregion

        #region INotifyPropertyChanged Implementation

        /// <summary>
        /// Occurs when any properties are changed on this object.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;


        /// <summary>
        /// A helper method that raises the PropertyChanged event for a property.
        /// </summary>
        /// <param name="propertyNames">The names of the properties that changed.</param>
        protected virtual void NotifyChanged(params string[] propertyNames)
        {
            foreach (string name in propertyNames)
            {
                OnPropertyChanged(new PropertyChangedEventArgs(name));
            }
        }

        /// <summary>
        /// Raises the PropertyChanged event.
        /// </summary>
        /// <param name="e">Event arguments.</param>
        protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, e);
            }
        }

        #endregion
    }
}
