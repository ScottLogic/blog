﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace GlobalWPFValidation
{
    /// <summary>
    /// NOTE: this is a modified version of a class that appeared in Sacha's original article.
    /// 
    /// A simple Person domain object
    /// </summary>
    public class Person : DomainObject, IDataErrorInfo
    {
        #region Data
        private String firstName = String.Empty;
        private String lastName = String.Empty;
        private Boolean isAbleToVote = false;
        private Int32 age = 0;
        #endregion

        #region Public Properties
        public String FirstName
        {
            get { return firstName;  }
            set
            {
                firstName = value;
                NotifyChanged("FirstName");
            }
        }

        public String LastName
        {
            get { return lastName; }
            set
            {
                lastName = value;
                NotifyChanged("LastName");
            }
        }


        public Boolean IsAbleToVote
        {
            get { return isAbleToVote; }
            set
            {
                isAbleToVote = value;
                NotifyChanged("IsAbleToVote");
            }
        }


        public Int32 Age
        {
            get { return age; }
            set
            {
                age = value;
                NotifyChanged("Age");
            }
        }
        #endregion

        #region IDataErrorInfo Members

        public string Error
        {
            get { throw new NotImplementedException(); }
        }

        public string this[string columnName]
        {
            get
            {
                if (columnName == "Age")
                {
                    if (Age < 0)
                        return "Age cannot be less than zero";
                }

                if (columnName == "FirstName")
                {
                    if (string.IsNullOrEmpty(FirstName))
                        return "FirstName cannot be empty";
                }

                if (columnName == "LastName")
                {
                    if (string.IsNullOrEmpty(LastName))
                        return "LastName cannot be empty";
                }

                return "";              

            }
        }

        #endregion
    }
}
