﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Controls;
using System.Globalization;
using GlobalWPFValidation;

namespace BindingGroupsGlobalValidation
{
    /// <summary>
    /// A validation rule that enforces constraints relating to the two bound Person
    /// objects on our form.
    /// </summary>
    public class PersonValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            BindingGroup bindingGroup = (BindingGroup)value;
           
            // extract the two bound Person instances.
            Person personOne = bindingGroup.Items[0] as Person;
            Person personTwo = bindingGroup.Items[1] as Person;

            if (personTwo.Age==0 && personOne.Age<18)
            {
                return new ValidationResult(false, "Person 2 Age can't be zero if Person1 Age < 18");
            }           

            return ValidationResult.ValidResult;
        }
    }

   
}
