﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace SLBindingPropertiesTwo
{
    public partial class ContactDetailsControl : UserControl
    {
        public Binding NameBinding { get; set; }
        public Binding CompanyBinding { get; set; }
        public Binding WebBinding { get; set; }
        public Binding EmailBinding { get; set; }

        public ContactDetailsControl()
        {
            InitializeComponent();
        }

        private void Border_Loaded(object sender, RoutedEventArgs e)
        {
            nameText.SetBinding(TextBlock.TextProperty, NameBinding);
            webText.SetBinding(HyperlinkButton.ContentProperty, WebBinding);
            webText.SetBinding(HyperlinkButton.NavigateUriProperty, WebBinding);
            companyText.SetBinding(TextBlock.TextProperty, CompanyBinding);
            emailText.SetBinding(TextBlock.TextProperty, EmailBinding);
        }
    }
}
