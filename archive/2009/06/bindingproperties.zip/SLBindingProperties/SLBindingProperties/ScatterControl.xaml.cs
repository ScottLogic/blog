﻿using System;
using System.Collections;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;

namespace SLBindingProperties
{
    public partial class ScatterControl : UserControl
    {
        #region CLR properties

        /// <summary>
        /// The binding to use to determine the X location
        /// </summary>
        public Binding XValueBinding { get; set; }

        /// <summary>
        /// The binding to use to determine the Y location
        /// </summary>
        public Binding YValueBinding { get; set; }

        /// <summary>
        /// The binding to use to determine the spot fill
        /// </summary>
        public Binding FillBinding { get; set; }

        #endregion


        #region ItemsSource Dependency Property

        /// <summary>
        /// This controls ItemsSource. This is a Dependency property.
        /// </summary>
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable),
            typeof(ScatterControl), new PropertyMetadata(null, ItemsSourcePropertyChanged));

        /// <summary>
        /// Invoked when the ItemsSource property changes of the given object.
        /// </summary>
        private static void ItemsSourcePropertyChanged(DependencyObject obj,
            DependencyPropertyChangedEventArgs args)
        {
            ((ScatterControl)obj).OnItemsSourceChanged();
        }

        /// <summary>
        /// Invoked when the ItemsSource property of this object changes
        /// </summary>
        protected void OnItemsSourceChanged()
        {
            itemsControl.ItemsSource = this.ItemsSource;
        }

        #endregion

        public ScatterControl()
        {
            InitializeComponent();
        }

        private void Ellipse_Loaded(object sender, RoutedEventArgs e)
        {
            Ellipse ellipse = sender as Ellipse;
            ellipse.SetBinding(Canvas.LeftProperty, XValueBinding);
            ellipse.SetBinding(Canvas.TopProperty, YValueBinding);
            ellipse.SetBinding(Ellipse.FillProperty, FillBinding);
        }
    }
}
