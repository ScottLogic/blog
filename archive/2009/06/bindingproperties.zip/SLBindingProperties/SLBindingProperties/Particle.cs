﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SLBindingProperties
{
    /// <summary>
    /// A particle that exhibits Brownian motion
    /// </summary>
    public class Particle : INotifyPropertyChanged
    {
        private static Random rand = new Random();

        private double xLocation;

        private double yLocation;

        private double excitement;

        /// <summary>
        /// How excited this particle is!
        /// </summary>
        public double Excitement
        {
            get { return excitement; }
            set { excitement = value; OnPropertyChanged("Excitement"); }
        }

        /// <summary>
        /// The particles Y location
        /// </summary>
        public double YLocation
        {
            get { return yLocation; }
            set { yLocation = value; OnPropertyChanged("YLocation"); }
        }

        /// <summary>
        /// The particles X location
        /// </summary>
        public double XLocation
        {
            get { return xLocation; }
            set { xLocation = value; OnPropertyChanged("XLocation");  }
        }

        public void RandomWalk()
        {
            // compute the new locations using tenporary variables, so that we set
            // the CLR properties (and raise the PropertyChanged event) just once
            // per property
            double newYLocation = YLocation + (rand.NextDouble() - 0.5) * Excitement;
            double newXLocation = XLocation + (rand.NextDouble() - 0.5) * Excitement;

            ApplyBound(ref newXLocation);
            ApplyBound(ref newYLocation);

            XLocation = newXLocation;
            YLocation = newYLocation;
        }

        private void ApplyBound(ref double location)
        {
            if (location < 0)
                location = 200 - location;

            if (location > 200)
                location = location - 200;
        }

       
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        #endregion
    }
}
