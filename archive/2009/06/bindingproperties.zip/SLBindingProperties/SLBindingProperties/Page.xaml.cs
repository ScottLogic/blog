﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Threading;

namespace SLBindingProperties
{
    public partial class Page : UserControl
    {
        private ObservableCollection<Particle> particles
            = new ObservableCollection<Particle>();

        private Random rand = new Random();

        public Page()
        {
            InitializeComponent();

            for (int i = 0; i < 50; i++)
            {
                particles.Add(new Particle()
                {
                    XLocation = rand.Next(200),
                    YLocation = rand.Next(200),
                    Excitement = rand.NextDouble() * 7.0
                });
            }

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0,0,0,0,50);
            timer.Tick +=new EventHandler(timer_Tick);
            timer.Start();

            scatterControl.ItemsSource = particles;
        }

        void timer_Tick(object sender, EventArgs e)
        {
            foreach (var particle in particles)
                particle.RandomWalk();
        }
    }
}
