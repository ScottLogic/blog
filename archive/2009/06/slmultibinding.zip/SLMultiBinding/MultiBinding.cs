﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Collections.ObjectModel;
using System.Windows.Markup;
using System.ComponentModel;
using System.Collections.Generic;
using System.Globalization;

namespace SLMultiBinding
{
  /// <summary>
  /// Allows multiple bindings to a single property.
  /// </summary>
  [ContentProperty("Bindings")]
  public class MultiBinding : Panel, INotifyPropertyChanged
  {

    #region ConvertedValue dependency property

    public static readonly DependencyProperty ConvertedValueProperty =
        DependencyProperty.Register("ConvertedValue", typeof(object), typeof(MultiBinding),
            new PropertyMetadata(null, OnConvertedValue));

    /// <summary>
    /// This dependency property is set to the resulting output of the
    /// associated Converter.
    /// </summary>
    public object ConvertedValue
    {
      get { return (object)GetValue(ConvertedValueProperty); }
      set { SetValue(ConvertedValueProperty, value); }
    }

    private static void OnConvertedValue(DependencyObject depObj, DependencyPropertyChangedEventArgs e)
    {
      MultiBinding relay = depObj as MultiBinding;
      relay.OnPropertyChanged("ConvertedValue");
    }

    #endregion

    #region CLR properties

    /// <summary>
    /// The target property on the element which this MultiBinding is assocaited with.
    /// </summary>
    public string TargetProperty { get; set; }

    /// <summary>
    /// The Converter which is invoked to compute the result of the multiple bindings
    /// </summary>
    public IMultiValueConverter Converter { get; set; }

    /// <summary>
    /// The configuration parameter supplied to the converter
    /// </summary>
    public object ConverterParameter { get; set; }

    /// <summary>
    /// The bindings, the result of which are supplied to the converter.
    /// </summary>
    public ObservableCollection<Binding> Bindings { get; set; }

    #endregion

    public MultiBinding()
    {
      Bindings = new ObservableCollection<Binding>();
    }

    /// <summary>
    /// Invoked when any of the BindingSlave's Value property changes.
    /// </summary>
    private void Slave_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      UpdateConvertedValue();
    }

    /// <summary>
    /// Uses the Converter to update the ConvertedValue in order to reflect
    /// the current state of the bindings.
    /// </summary>
    private void UpdateConvertedValue()
    {
      List<object> values = new List<object>();
      foreach (BindingSlave slave in Children)
      {
        values.Add(slave.Value);
      }
      ConvertedValue = Converter.Convert(values.ToArray(), typeof(object), ConverterParameter,
        CultureInfo.CurrentCulture);
    }

    /// <summary>
    /// Creates a BindingSlave for each Binding and binds the Value
    /// accordingly.
    /// </summary>
    internal void Initialise()
    {
      foreach (Binding binding in Bindings)
      {
        BindingSlave slave = new BindingSlave();
        slave.SetBinding(BindingSlave.ValueProperty, binding);
        slave.PropertyChanged += new PropertyChangedEventHandler(Slave_PropertyChanged);
        Children.Add(slave);
      }            
    }
    
    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }

    #endregion
  }

  /// <summary>
  /// A simple element with a single Value property, used as a 'slave'
  /// for a Binding.
  /// </summary>
  public class BindingSlave : FrameworkElement, INotifyPropertyChanged
  {
    #region Value

    public static readonly DependencyProperty ValueProperty =
        DependencyProperty.Register("Value", typeof(object), typeof(BindingSlave),
            new PropertyMetadata(null, OnValueChanged));

    public object Value
    {
      get { return (object)GetValue(ValueProperty); }
      set { SetValue(ValueProperty, value); }
    }

    private static void OnValueChanged(DependencyObject depObj, DependencyPropertyChangedEventArgs e)
    {
      BindingSlave slave = depObj as BindingSlave;
      slave.OnPropertyChanged("Value");
    }

    #endregion

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string name)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(name));
      }
    }

    #endregion

  }
}
