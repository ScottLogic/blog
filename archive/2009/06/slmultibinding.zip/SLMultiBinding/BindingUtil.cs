﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.ComponentModel;
using System.Reflection;

namespace SLMultiBinding
{
  /// <summary>
  /// Provides a mechanism for attaching a MultiBinding to an element
  /// </summary>
  public class BindingUtil
  {
    #region DataContextPiggyBack attached property

    /// <summary>
    /// DataContextPiggyBack Attached Dependency Property, used as a mechanism for exposing
    /// DataContext changed events
    /// </summary>
    public static readonly DependencyProperty DataContextPiggyBackProperty =
        DependencyProperty.RegisterAttached("DataContextPiggyBack", typeof(object), typeof(BindingUtil),
            new PropertyMetadata(null, new PropertyChangedCallback(OnDataContextPiggyBackChanged)));

    public static object GetDataContextPiggyBack(DependencyObject d)
    {
      return (object)d.GetValue(DataContextPiggyBackProperty);
    }

    public static void SetDataContextPiggyBack(DependencyObject d, object value)
    {
      d.SetValue(DataContextPiggyBackProperty, value);
    }

    /// <summary>
    /// Handles changes to the DataContextPiggyBack property.
    /// </summary>
    private static void OnDataContextPiggyBackChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      FrameworkElement targetElement = d as FrameworkElement;

      // whenever the targeElement DataContext is changed, copy the updated property
      // value to our MultiBinding.
      MultiBinding relay = GetMultiBinding(targetElement);
      relay.DataContext = targetElement.DataContext;
    }

    #endregion

    #region MultiBinding attached property

    public static MultiBinding GetMultiBinding(DependencyObject obj)
    {
      return (MultiBinding)obj.GetValue(MultiBindingProperty);
    }

    public static void SetMultiBinding(DependencyObject obj, MultiBinding value)
    {
      obj.SetValue(MultiBindingProperty, value);
    }

    public static readonly DependencyProperty MultiBindingProperty =
        DependencyProperty.RegisterAttached("MultiBinding",
        typeof(MultiBinding), typeof(BindingUtil), new PropertyMetadata(null, OnMultiBindingChanged));

    private static readonly BindingFlags dpFlags = BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy;

    /// <summary>
    /// Invoked when the MultiBinding property is set on a framework element
    /// </summary>
    private static void OnMultiBindingChanged(DependencyObject depObj,
      DependencyPropertyChangedEventArgs e)
    {
      FrameworkElement targetElement = depObj as FrameworkElement;

      // bind the target elements DataContext, to our DataContextPiggyBack property
      // this allows us to get property changed events when the targetElement
      // DataContext changes
      targetElement.SetBinding(BindingUtil.DataContextPiggyBackProperty, new Binding());

      MultiBinding relay = GetMultiBinding(targetElement);
      relay.Initialise();

      // find the target dependency property
      FieldInfo[] sourceFields = targetElement.GetType().GetFields(dpFlags);
      FieldInfo targetDependencyPropertyField =
          sourceFields.First(i => i.Name == relay.TargetProperty + "Property");
      DependencyProperty targetDependencyProperty =
          targetDependencyPropertyField.GetValue(null) as DependencyProperty;

      // bind the ConvertedValue of our MultiBinding instance to the target property
      // of our targetElement
      Binding binding = new Binding("ConvertedValue");
      binding.Source = relay;
      targetElement.SetBinding(targetDependencyProperty, binding);
    }

    #endregion

  }
}
