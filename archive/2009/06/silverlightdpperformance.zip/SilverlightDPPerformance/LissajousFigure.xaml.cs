﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Threading;

namespace SilverlightDPPerformance
{
    public partial class LissajousFigure : UserControl
    {
        /// <summary>
        /// Creates a phase 'creep' to keep the figure animated continuously.
        /// </summary>
        double _phase = 0;


        /// <summary>
        /// The duration of the storyboard used to update the 'actual' property
        /// </summary>
        private static readonly int _propertyDelay = 300;

        partial void OnXFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            AnimateProperty("ActualXFrequency", XFrequency, _propertyDelay);

        }

        partial void OnYFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            AnimateProperty("ActualYFrequency", YFrequency, _propertyDelay);
        }

        partial void OnPhasePropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            AnimateProperty("ActualPhase", Phase, _propertyDelay);
        }

        partial void OnActualPhasePropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Invalidate();
        }

        partial void OnActualXFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Invalidate();
        }

        partial void OnActualYFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Invalidate();
        }

        private void AnimateProperty(string propertyName, double targetValue, int milliseconds)
        {
            Storyboard sb = new Storyboard();

            DoubleAnimation b = new DoubleAnimation() { To = targetValue };
            b.Duration = new Duration(new TimeSpan(0, 0, 0, 0, milliseconds));
            sb.Children.Add(b);
            Storyboard.SetTarget(b, this);
            Storyboard.SetTargetProperty(b, new PropertyPath("(" + propertyName + ")"));

            sb.Begin();
        }
       

        public LissajousFigure()
        {
            InitializeComponent();

            Invalidate();

            this.SizeChanged += new SizeChangedEventHandler(LissajousFigure_SizeChanged);

            DispatcherTimer timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = new TimeSpan(0,0,0,0,50);
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            Invalidate();
            _phase += 0.07;
        }

        void LissajousFigure_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Invalidate();
        }

        public override void OnApplyTemplate()
        {
            Dispatcher.BeginInvoke(() => Invalidate());
        }

        private List<Point> GetFigurePoints()
        {
            List<Point> points = new List<Point>();
            
            double actualWidth = PathContainer.ActualWidth;
            double actualHeight = PathContainer.ActualHeight;
            double actualXFrequency = ActualXFrequency;
            double actualPhase = ActualPhase;
            double actualYFrequency = ActualYFrequency;

            for(double t = 0; t < Math.PI * 10; t += Math.PI / 36)
            {
                points.Add(new Point()
                {
                    X = actualWidth * Math.Sin(t * actualXFrequency + _phase) / 2
                        + actualWidth / 2,
                    Y = actualHeight * Math.Cos(t * actualYFrequency + actualPhase + _phase) / 2
                        + actualHeight / 2
                });
            }

            return points;

        }


        private void Invalidate()
        {
            // obtain the points to render
            List<Point> seriesPoints = GetFigurePoints();
                        
            if (lissajousFigure.Data == null)
            {
                // if we have not already created the geometry for our path
                // create a new geometry from our series points

                PathFigure figure = new PathFigure();
                figure.IsClosed = false;
                bool firstPoint = true;
                foreach (Point point in seriesPoints)
                {
                    if (firstPoint)
                    {
                        figure.StartPoint = point;
                        firstPoint = false;
                    }
                    else
                    {
                        figure.Segments.Add(new LineSegment()
                        {
                            Point = point
                        });
                    }
                }

                PathGeometry geometry = new PathGeometry();
                geometry.Figures.Add(figure);

                lissajousFigure.Data = geometry;
            }
            else
            {
                // if we already have a gemoetry - recycle it!

                PathGeometry geometry = lissajousFigure.Data as PathGeometry;
                PathFigure figure = geometry.Figures[0];

                figure.IsClosed = false;
                bool firstPoint = true;
                int segmentIndex = 0;
                foreach (Point point in seriesPoints)
                {
                    if (firstPoint)
                    {
                        figure.StartPoint = point;
                        firstPoint = false;
                    }
                    else
                    {
                        LineSegment segment = figure.Segments[segmentIndex++] as LineSegment;
                        segment.Point = point;
                    }
                }
            }
        }
    }
}
