﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Collections.Generic;

namespace SilverlightDPPerformance
{
    public partial class LissajousFigure : UserControl 
    {

        #region XFrequency
            
            
        public double XFrequency
        {
            get { return (double)GetValue(XFrequencyProperty); }
            set { SetValue(XFrequencyProperty, value); }
        }
    
        /// <summary>
        /// Identifies the XFrequency Dependency Property.
        /// <summary>
        public static readonly DependencyProperty XFrequencyProperty =
            DependencyProperty.Register("XFrequency", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(1.0, OnXFrequencyPropertyChanged));
    
        
        private static void OnXFrequencyPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnXFrequencyPropertyChanged(e);
            
        }

        
        partial void OnXFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region YFrequency
            
            
        public double YFrequency
        {
            get { return (double)GetValue(YFrequencyProperty); }
            set { SetValue(YFrequencyProperty, value); }
        }
    
        /// <summary>
        /// Identifies the YFrequency Dependency Property.
        /// <summary>
        public static readonly DependencyProperty YFrequencyProperty =
            DependencyProperty.Register("YFrequency", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(1.0, OnYFrequencyPropertyChanged));
    
        
        private static void OnYFrequencyPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnYFrequencyPropertyChanged(e);
            
        }

        
        partial void OnYFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region Phase
            
            
        public double Phase
        {
            get { return (double)GetValue(PhaseProperty); }
            set { SetValue(PhaseProperty, value); }
        }
    
        /// <summary>
        /// Identifies the Phase Dependency Property.
        /// <summary>
        public static readonly DependencyProperty PhaseProperty =
            DependencyProperty.Register("Phase", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(0.0, OnPhasePropertyChanged));
    
        
        private static void OnPhasePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnPhasePropertyChanged(e);
            
        }

        
        partial void OnPhasePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region ActualXFrequency
            
            
        public double ActualXFrequency
        {
            get { return (double)GetValue(ActualXFrequencyProperty); }
            set { SetValue(ActualXFrequencyProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ActualXFrequency Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ActualXFrequencyProperty =
            DependencyProperty.Register("ActualXFrequency", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(1.0, OnActualXFrequencyPropertyChanged));
    
        
        private static void OnActualXFrequencyPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnActualXFrequencyPropertyChanged(e);
            
        }

        
        partial void OnActualXFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region ActualYFrequency
            
            
        public double ActualYFrequency
        {
            get { return (double)GetValue(ActualYFrequencyProperty); }
            set { SetValue(ActualYFrequencyProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ActualYFrequency Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ActualYFrequencyProperty =
            DependencyProperty.Register("ActualYFrequency", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(1.0, OnActualYFrequencyPropertyChanged));
    
        
        private static void OnActualYFrequencyPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnActualYFrequencyPropertyChanged(e);
            
        }

        
        partial void OnActualYFrequencyPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region ActualPhase
            
            
        public double ActualPhase
        {
            get { return (double)GetValue(ActualPhaseProperty); }
            set { SetValue(ActualPhaseProperty, value); }
        }
    
        /// <summary>
        /// Identifies the ActualPhase Dependency Property.
        /// <summary>
        public static readonly DependencyProperty ActualPhaseProperty =
            DependencyProperty.Register("ActualPhase", typeof(double),
            typeof(LissajousFigure), new PropertyMetadata(0.0, OnActualPhasePropertyChanged));
    
        
        private static void OnActualPhasePropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            LissajousFigure myClass = d as LissajousFigure;
            myClass.OnActualPhasePropertyChanged(e);
            
        }

        
        partial void OnActualPhasePropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
     
    }
}

