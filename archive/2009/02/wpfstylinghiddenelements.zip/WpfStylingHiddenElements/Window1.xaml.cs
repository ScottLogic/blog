﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfStylingHiddenElements
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        /*
        /// <summary>
        /// Handle the DataGrid's Loaded event and apply a new template to the SelectAll button
        /// </summary>
        private void dataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            DependencyObject dep = sender as DependencyObject;

            // Navigate down the visual tree to the button
            while (!(dep is Button))
            {
                dep = VisualTreeHelper.GetChild(dep, 0);
            }
            Button button = dep as Button;

            // apply our new template
            object res = FindResource("SelectAllButtonTemplate");
            button.Template = res as ControlTemplate
        }
        */
    }
}
