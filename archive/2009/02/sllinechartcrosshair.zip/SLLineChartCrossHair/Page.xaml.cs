﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using Microsoft.Windows.Controls.DataVisualization.Charting;
using Microsoft.Windows.Controls.DataVisualization;

namespace SLLineChartCrossHair
{
    public partial class Page : UserControl
    {

        #region properties which provide convenient access to visual tree elements

        protected LineSeries LineSeries
        {
            get
            {
                return ((LineSeries)Chart.Series[0]);
            }
        }

        protected Border LocationIndicator
        {
            get
            {
                return ChartArea.FindName("LocationIndicator") as Border;
            }
        }

        protected Grid PlotArea
        {
            get
            {
                return ChartArea.FindName("PlotArea") as Grid;
            }
        }

        protected Grid Crosshair
        {
            get
            {
                return ChartArea.FindName("Crosshair") as Grid;
            }
        }

        protected Grid ChartArea
        {
            get
            {
                // chart area is within a different namescope to this page, therefore
                // we must navigate the visual tree to locate it
                return VisualTreeHelper.GetChild(Chart, 0) as Grid;
            }
        }

        protected LinearAxis YAxis
        {
            get
            {
                return (LinearAxis)Chart.Axes[0];
            }
        }

        protected DateTimeAxis XAxis
        {
            get
            {
                return (DateTimeAxis)Chart.Axes[1];
            }
        }

        #endregion

        #region constructor

        public Page()
        {
            InitializeComponent();

            XDocument doc = XDocument.Load("chartData.xml");
            var elements = from dataPoint in doc.Descendants("dataPoint")                           
                           select new KeyValuePair<DateTime, double>
                           (
                               DateTime.Parse(dataPoint.Attribute("date").Value.Substring(0, 19)),
                               Double.Parse(dataPoint.Attribute("value").Value)
                           );

            LineSeries.ItemsSource = elements;
        }

        #endregion

        #region utility methods

        /// <summary>
        /// Transforms the supplied position on the plot area grid into a point within the plot area coordinate system
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        private KeyValuePair<DateTime, double> GetPlotAreaCoordinates(Point position)
        {
            Range<IComparable> yAxisHit = ((IRangeAxis)YAxis).GetPlotAreaCoordinateValueRange(PlotArea.Height - position.Y);
            Range<IComparable> xAxisHit = ((IRangeAxis)XAxis).GetPlotAreaCoordinateValueRange(position.X);

            return new KeyValuePair<DateTime, double>((DateTime)xAxisHit.Minimum, (double)yAxisHit.Minimum);
        }

        #endregion

        #region event handlers

        private void PlotArea_MouseMove(object sender, MouseEventArgs e)
        {
            if (LineSeries.ItemsSource == null)
                return;

            Point mousePos = e.GetPosition(PlotArea);
            KeyValuePair<DateTime, double> crosshairLocation = GetPlotAreaCoordinates(mousePos);

            PlotArea.DataContext = crosshairLocation;
            Crosshair.DataContext = mousePos;
            PlotArea.Cursor = Cursors.None;
        }


        private void PlotArea_MouseEnter(object sender, MouseEventArgs e)
        {
            LocationIndicator.Visibility = Visibility.Visible;
            Crosshair.Visibility = Visibility.Visible;
        }

        private void PlotArea_MouseLeave(object sender, MouseEventArgs e)
        {
            LocationIndicator.Visibility = Visibility.Collapsed;
            Crosshair.Visibility = Visibility.Collapsed;
        }

        #endregion
    }
}
