﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace SilverlightBinding
{
    public static class TestDataProvider
    {
        /// <summary>
        /// Provide a list of characters
        /// </summary>
        /// <returns></returns>
        public static List<Character> GetData()
        {
            return new List<Character>(){
                new Character()
                {
                    Surname = "Grimmes",
                    Forename = "Frank",
                    Sex =SexEnum.Male
                },
                new Character()
                {
                    Surname = "Simpson",
                    Forename = "Bart",
                    Sex=SexEnum.Male
                },
                new Character()
                {
                    Surname = "Simpson",
                    Forename = "Lisa",
                    Sex=SexEnum.Female
                },
                new Character()
                {
                    Surname = "Simpson",
                    Forename = "Maggie",
                    Sex=SexEnum.Female
                },
                new Character()
                {
                    Surname = "Simpson",
                    Forename = "Homer",
                    Sex=SexEnum.Male
                }
            };
        }
    }

    public enum SexEnum
    {
        Male, Female
    }

    public class Character
    {
        public string Surname { get; set; }
        public string Forename { get; set; }
        public SexEnum Sex { get; set; }
    }
}
