namespace Fizzler.Parser.ChunkHandling
{
	public class AttributeSelectorData
	{
		public string Attribute { get; set; }
		public AttributeComparator Comparison { get; set; }
		public string Value { get; set; }
	}
}