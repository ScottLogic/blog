namespace Fizzler.Parser.ChunkHandling
{
	public enum AttributeComparator
	{
		Unknown,
		Exact,
		SpaceSeparated,
		HyphenSeparated
	}
}