namespace Fizzler.Parser.ChunkHandling
{
	public enum ChunkType
	{
		TagName,
		Star,
		Id,
		Class
	}
}