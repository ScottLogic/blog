using System;
using System.Collections.Generic;
using Fizzle.Parser.Extensions;
using Fizzler.Parser;
using Fizzler.Parser.ChunkHandling;
using HtmlAgilityPack;

namespace Fizzler.Parser
{
	public class SelectorEngine
	{
		private readonly ChunkParser _chunkParser = new ChunkParser();
		private readonly NodeMatcher _nodeMatcher = new NodeMatcher();
		private readonly string _html;
        private IDocumentNode _docNode;

        public IDocumentNode DocumentNode
        {
            get { return _docNode; }
            set { _docNode = value; }
        }

        public SelectorEngine()
        {
        }

		public SelectorEngine(string html)
		{
			_html = html;
		}

        public SelectorEngine(IDocumentNode docNode)
        {
            _docNode = docNode;
        }

        private List<IDocumentNode> GetChildNodeList()
		{
            if (_docNode != null)
            {
                return new List<IDocumentNode>() { _docNode };
            }

			var document = new HtmlDocument();
			document.LoadHtml(_html);

			return new HtmlNodeWrapper(document.DocumentNode).ChildNodes;
		}

        public IList<IDocumentNode> Parse(string selectorChain)
		{
            List<IDocumentNode> selectedNodes = new List<IDocumentNode>();

			string[] selectors = selectorChain.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			
			// This enables us to support "," by simply treating comma-separated parts as separate selectors
			foreach (string rawSelector in selectors)
			{
				// we also need to check if a chunk contains a "." character....
				var chunks = _chunkParser.GetChunks(rawSelector.Trim());

                List<IDocumentNode> list = GetChildNodeList();

				for (int chunkCounter = 0; chunkCounter < chunks.Count; chunkCounter++)
				{

					list = list.Flatten();

					list.RemoveAll(node => !_nodeMatcher.IsDownwardMatch( node, chunks, chunkCounter));
				}

				selectedNodes.AddRange(list);
			}

			return selectedNodes;
		}
	}
}