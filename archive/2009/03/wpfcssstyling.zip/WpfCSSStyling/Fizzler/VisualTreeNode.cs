﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fizzler.Parser;
using System.Windows;
using System.Windows.Media;
using System.Reflection;

namespace WpfCSSStyling.Fizzler
{
    /// <summary>
    /// Wraps a DependencyObject to implement the IDcoumentNode interface, exposing the VisualTree
    /// to the CSS SelectorEngine.
    /// </summary>
    public class VisualTreeNode : DependencyObjectNode
    {
        public VisualTreeNode(DependencyObject dependencyObject) :
            base(dependencyObject)
        {            
        }

        #region IDocumentNode Members

        public override List<IDocumentNode> ChildNodes
        {
            get
            {
                int childCount = VisualTreeHelper.GetChildrenCount(_dependencyObject);

                List<IDocumentNode> childNodes = new List<IDocumentNode>();
                for (int i = 0; i < childCount; i++)
                {
                    childNodes.Add(new VisualTreeNode(VisualTreeHelper.GetChild(_dependencyObject, i)));
                }

                return childNodes;
            }
        }

        public override IDocumentNode ParentNode
        {
            get
            {
                DependencyObject parent = VisualTreeHelper.GetParent(_dependencyObject);            
                return parent != null ? new VisualTreeNode(parent) : null;
            }
        }

        public override IDocumentNode PreviousSibling
        {
            get
            {
                DependencyObject parent = VisualTreeHelper.GetParent(_dependencyObject);
                if (parent == null)
                {
                    return null;
                }

                // find the index of this element in its parent's child collection
                int thisElementsIndex = 0;
                int childCount = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 0; i < childCount; i++)
                {
                    if (VisualTreeHelper.GetChild(parent, i).Equals(this))
                    {
                        thisElementsIndex=1;
                        break;
                    }
                }

                // find the previous sibling
                if (thisElementsIndex == 0)
                    return null;

                DependencyObject sibling = VisualTreeHelper.GetChild(parent, thisElementsIndex-1);
                return new VisualTreeNode(sibling);
            }
        }

        #endregion
                
    }
}
