﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Fizzler.Parser;

namespace WpfCSSStyling.Fizzler
{
    /// <summary>
    /// Wraps a DependencyObject to implement the IDcoumentNode interface, exposing the LogicalTree
    /// to the CSS SelectorEngine.
    /// </summary>
    public class LogicalTreeNode : DependencyObjectNode
    {
        public LogicalTreeNode(DependencyObject dependencyObject) :
            base (dependencyObject)
        {            
        }

        #region IDocumentNode Members

        public override List<IDocumentNode> ChildNodes
        {
            get
            {
                var children = LogicalTreeHelper.GetChildren(_dependencyObject);
                
                List<IDocumentNode> childNodes = new List<IDocumentNode>();
                foreach (object child in children)
                {
                    DependencyObject childDependencyObject = child as DependencyObject;
                    if (childDependencyObject != null)
                    {
                        childNodes.Add(new LogicalTreeNode(childDependencyObject));
                    }
                }

                return childNodes;
            }
        }

        public override IDocumentNode ParentNode
        {
            get
            {
                DependencyObject parent = LogicalTreeHelper.GetParent(_dependencyObject);
                return parent != null ? new LogicalTreeNode(parent) : null;
            }
        }

        public override IDocumentNode PreviousSibling
        {
            get
            {
                DependencyObject parent = LogicalTreeHelper.GetParent(_dependencyObject);
                if (parent == null)
                {
                    return null;
                }

                // find the index of this element in its parent's child collection
                var children = LogicalTreeHelper.GetChildren(parent);
                int thisElementsIndex = 0;
                List<DependencyObject> childNodes = new List<DependencyObject>();
                foreach (DependencyObject child in children)
                {
                    childNodes.Add(child);                    
                }

                thisElementsIndex = childNodes.IndexOf(_dependencyObject);

                // find the previous sibling
                if (thisElementsIndex == 0)
                    return null;

                DependencyObject sibling = childNodes[thisElementsIndex - 1];
                return new LogicalTreeNode(sibling);
            }
        }

       

        #endregion

        public override bool Equals(object obj)
        {
            LogicalTreeNode otherNode = obj as LogicalTreeNode;
            return otherNode != null ? otherNode._dependencyObject.Equals(_dependencyObject) : false;
        }

        public override int GetHashCode()
        {
            return _dependencyObject.GetHashCode();
        }


    }
}
