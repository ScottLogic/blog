﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fizzler.Parser;

namespace WpfCSSStyling.Fizzler
{
    public class DependencyPropertyAttribute : IAttribute
    {
        private string _value;

        public DependencyPropertyAttribute(string value)
        {
            _value = value;
        }

        public string Value
        {
            get { return _value; }
        }
    }
}
