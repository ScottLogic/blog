﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fizzler.Parser;
using System.Windows;

namespace WpfCSSStyling.Fizzler
{
    public abstract class DependencyObjectNode : IDocumentNode
    {
        protected DependencyObject _dependencyObject;

        public DependencyObjectNode(DependencyObject dependencyObject)
        {
            _dependencyObject = dependencyObject;
        }

        #region IDocumentNode Members

        public abstract List<IDocumentNode> ChildNodes { get; }

        public abstract IDocumentNode ParentNode { get; }

        public abstract IDocumentNode PreviousSibling { get; }

        public DependencyObject WrappedElement
        {
            get
            {
                return _dependencyObject;
            }
        }

        public IAttributeCollection Attributes
        {
            get { return new DependencyObjectAttributeCollection(_dependencyObject); }
        }

        public string Id
        {
            get
            {
                return _dependencyObject is FrameworkElement ?
                    ((FrameworkElement)_dependencyObject).Name : null;
            }
        }

        public string Class
        {
            get { return Css.GetClass(_dependencyObject); }
        }

        public string Name
        {
            get { return _dependencyObject.GetType().Name; }
        }

        public bool IsElement
        {
            get { return true; }
        }

        #endregion

        public override bool Equals(object obj)
        {
            DependencyObjectNode otherNode = obj as DependencyObjectNode;

            return otherNode != null &&
                otherNode.GetType().Equals(this.GetType()) &&
                otherNode._dependencyObject.Equals(_dependencyObject);
        }

        public override int GetHashCode()
        {
            return _dependencyObject.GetHashCode();
        }
    }
}
