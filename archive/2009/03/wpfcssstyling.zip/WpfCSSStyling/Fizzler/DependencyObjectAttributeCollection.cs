﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Fizzler.Parser;
using System.Windows;

namespace WpfCSSStyling.Fizzler
{
    /// <summary>
    /// Wraps a dependency object, exposing its dependency properties as attributes
    /// </summary>
    public class DependencyObjectAttributeCollection : IAttributeCollection
    {
        private DependencyObject _dependencyObject;

        // the flags required to obtain a list of dp's 
        private static readonly BindingFlags dpFlags =
            BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy;

        public DependencyObjectAttributeCollection(DependencyObject dependencyObject)
        {
            _dependencyObject = dependencyObject;
        }

        public IAttribute this[string name]
        {
            get
            {
                // find the source dependency property
                string dpName = name + "Property";
                FieldInfo[] dpFields = _dependencyObject.GetType().GetFields(dpFlags);
                FieldInfo dpField = dpFields.FirstOrDefault(i => i.Name == dpName);

                if (dpField == null)
                {
                    return null;
                }
                else
                {
                    DependencyProperty dependencyProperty = dpField.GetValue(null) as DependencyProperty;

                    // TODO probably better to use a type converter rather than ToString()
                    object value = _dependencyObject.GetValue(dependencyProperty);
                    return new DependencyPropertyAttribute(value.ToString());
                }
            }
        }
    }
}
