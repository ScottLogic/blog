﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfCSSStyling
{
    public class StyleSheet
    {
        private StyleRuleCollection _rules = new StyleRuleCollection();

        public StyleRuleCollection Rules
        {
            get { return _rules; }
            set { _rules = value; }
        }

    }
}
