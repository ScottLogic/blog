﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Reflection;
using System.ComponentModel;
using Fizzler.Parser;
using WpfCSSStyling.Fizzler;

namespace WpfCSSStyling
{
    public class Css
    {
        public static StyleDeclarationBlock GetStyle(DependencyObject obj)
        {
            return (StyleDeclarationBlock)obj.GetValue(StyleProperty);
        }

        public static void SetStyle(DependencyObject obj, StyleDeclarationBlock value)
        {
            obj.SetValue(StyleProperty, value);
        }

        public static readonly DependencyProperty StyleProperty =
            DependencyProperty.RegisterAttached("Style", typeof(StyleDeclarationBlock),
            typeof(Css), new UIPropertyMetadata(StylePropertyAttached));



        public static StyleSheet GetStyleSheet(DependencyObject obj)
        {
            return (StyleSheet)obj.GetValue(StyleSheetProperty);
        }

        public static void SetStyleSheet(DependencyObject obj, StyleSheet value)
        {
            obj.SetValue(StyleSheetProperty, value);
        }

        public static readonly DependencyProperty StyleSheetProperty =
            DependencyProperty.RegisterAttached("StyleSheet", typeof(StyleSheet),
            typeof(Css), new UIPropertyMetadata(StyleSheetPropertyAttached));


        

        public static string GetClass(DependencyObject obj)
        {
            return (string)obj.GetValue(ClassProperty);
        }

        public static void SetClass(DependencyObject obj, string value)
        {
            obj.SetValue(ClassProperty, value);
        }
                
        public static readonly DependencyProperty ClassProperty =
            DependencyProperty.RegisterAttached("Class", typeof(string),
            typeof(Css), new UIPropertyMetadata(null));


        #region attached behaviours

        private static void StyleSheetPropertyAttached(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            FrameworkElement frameworkElement = d as FrameworkElement;
            frameworkElement.Loaded += new RoutedEventHandler(FrameworkElementWithStyleSheet_Loaded);
        }

        /// <summary>
        /// invoked when a framework element which has a stylesheet applied is loaded.
        /// </summary>
        static void FrameworkElementWithStyleSheet_Loaded(object sender, RoutedEventArgs e)
        {
            FrameworkElement frameworkElement = sender as FrameworkElement;
            StyleSheet stylesheet = GetStyleSheet(frameworkElement);

            // create our selector engine
            SelectorEngine engine = new SelectorEngine();

            foreach (StyleRule rule in stylesheet.Rules)
            {
                // create a node which provides a veiw on either the logical of visual tree
                if (rule.SelectorType == SelectorType.VisualTree)
                {
                    engine.DocumentNode = new VisualTreeNode(frameworkElement);
                }
                else
                {
                    engine.DocumentNode = new LogicalTreeNode(frameworkElement);
                }

                // apply our selector
                IList<IDocumentNode> matchingNodes = engine.Parse(rule.Selector);

                // apply the style to all matching nodes
                foreach (DependencyObjectNode matchingNode in matchingNodes)
                {
                    FrameworkElement matchedElement = matchingNode.WrappedElement as FrameworkElement;
                    if (matchedElement != null)
                    {
                        ApplyStyle(matchedElement, rule.DeclarationBlock);
                    }
                }
            }
        }

        private static void StylePropertyAttached(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {            
            FrameworkElement frameworkElement = d as FrameworkElement;
            StyleDeclarationBlock declarationBlock = GetStyle(d);

            ApplyStyle(frameworkElement, declarationBlock);
        }

        #endregion

        #region helper methods

        // the flags required to obtain a list of dp's 
        private static readonly BindingFlags dpFlags =
            BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy;

        /// <summary>
        /// Returns a clone of the current style applied to the given framework element
        /// </summary>
        /// <param name="frameworkElement"></param>
        /// <returns></returns>
        private static Style CloneStyle(FrameworkElement frameworkElement)
        {
            Style style = new Style(frameworkElement.GetType());

            if (frameworkElement.Style != null)
            {
                foreach (Setter setterToCopy in frameworkElement.Style.Setters)
                {
                    style.Setters.Add(new Setter()
                    {
                        Property = setterToCopy.Property,
                        Value = setterToCopy.Value
                    });
                }
            }
            return style;
        }

        /// <summary>
        /// Creates a WPF style from the given declaration block and applies it to
        /// the given framework element
        /// </summary>
        /// <param name="frameworkElement"></param>
        /// <param name="declarationBlock"></param>
        private static void ApplyStyle(FrameworkElement frameworkElement,
            StyleDeclarationBlock declarationBlock)
        {
            // style become sealed when applied, so we clone the current style
            // so that we can merge the new style with the existing one.
            Style style = CloneStyle(frameworkElement);
                                    
            // iterate over each style declaration
            foreach (StyleDeclaration declaration in declarationBlock)
            {
                // find the source dependency property
                string dpName = declaration.Property + "Property";
                FieldInfo[] dpFields = frameworkElement.GetType().GetFields(dpFlags);
                FieldInfo dpField = dpFields.FirstOrDefault(i => i.Name == dpName);

                // if we have a dependency property that relates to this style, 
                // construct a style setter.
                if (dpField != null)
                {
                    DependencyProperty dependencyProperty = dpField.GetValue(null) as DependencyProperty;
                                        
                    object propertyValue = declaration.Value;

                    // if the supplied value is not of the correct type, use a type converter
                    if (!dependencyProperty.PropertyType.IsAssignableFrom(propertyValue.GetType()))
                    {
                        Type propertyType = dependencyProperty.PropertyType;
                        TypeConverter converter = TypeDescriptor.GetConverter(propertyType);
                        propertyValue = converter.ConvertFrom(declaration.Value);
                    }

                    // add a setter for this style
                    style.Setters.Add(new Setter()
                    {
                        Property = dependencyProperty,
                        Value = propertyValue
                    });
                }
            }

            frameworkElement.Style = style;

            // if the style included a new template for this element, we need to update
            // its layout in order for the framework to create an instance of this
            // template and add it to the visual tree.
            if (declarationBlock.FirstOrDefault(i => i.Property == "Template") != null)
            {
                frameworkElement.UpdateLayout();
            }
        }

        #endregion


    }
}
