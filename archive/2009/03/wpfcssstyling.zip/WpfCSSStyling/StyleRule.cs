﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfCSSStyling
{
    public class StyleRule
    {
        public string Selector { get; set; }
        public StyleDeclarationBlock DeclarationBlock { get; set; }
        public SelectorType SelectorType { get; set; }
    }

    public enum SelectorType
    {
        VisualTree,
        LogicalTree
    }

    public class StyleRuleCollection : List<StyleRule>
    {
    }
}
