﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightClipToBounds
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }

        private void GrowOnLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            fe.Margin = new Thickness()
            {
                Bottom = fe.Margin.Bottom - 2,
                Left = fe.Margin.Left - 2,
                Right = fe.Margin.Right - 2,
                Top = fe.Margin.Top - 2,
            };
            e.Handled = true;
        }

    }
}
