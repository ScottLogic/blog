﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Data;

namespace SilverlightShimmer
{
    /// <summary>
    /// A control which renders a reflection of another FrameworkElement
    /// </summary>
    public partial class ReflectionControl : UserControl
    {
        private DispatcherTimer _timer;

        private double _time = 0.0;


        #region ReflectedElement

        /// <summary>
        /// ReflectedElement Dependency Property
        /// </summary>
        public static readonly DependencyProperty ReflectedElementProperty =
            DependencyProperty.Register("ReflectedElement", typeof(object), typeof(ReflectionControl),
                new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the ReflectedElement property. 
        /// </summary>
        public object ReflectedElement
        {
            get { return (object)GetValue(ReflectedElementProperty); }
            set { SetValue(ReflectedElementProperty, value); }
        }

        #endregion

        public ReflectionControl()
        {
            InitializeComponent();

            // initialise a timer at 50ms intervals - and start
            _timer = new DispatcherTimer();
            _timer.Interval = new TimeSpan(0, 0, 0, 0, 50);
            _timer.Tick += new EventHandler(Timer_Tick);
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // increment phi and update the reflection
            _time += 0.4;
            UpdateReflection();
        }

        /// <summary>
        /// Copies an inverted image of the referenced FrameworkElement
        /// with a 'ripple' effect
        /// </summary>
        private void UpdateReflection()
        {
            FrameworkElement reflectedFE = ReflectedElement as FrameworkElement;

            if (reflectedFE == null)
                return;

            // synchronize the element width
            Width = reflectedFE.ActualWidth;

            // copy the source into a writeable bitmap
            WriteableBitmap sourceBitmap = new WriteableBitmap(reflectedFE, null);

            // create a target which is the same width / height as the reflection element
            WriteableBitmap targetBitmap = new WriteableBitmap((int)ActualWidth, (int)ActualHeight);

            // copy the reflection
            for (int y = 0; y < targetBitmap.PixelHeight; y++)
            {
                double amplitude = ComputeAmplitude(y, targetBitmap.PixelHeight);
                double sinusoid = ComputeRipple(y, targetBitmap.PixelHeight, _time);

                // the offset to the y value index caused by the ripple
                int yOffset = (int)(sinusoid * amplitude);

                // compute the Y position of the line to copy from the source image
                int sourceYLocation = sourceBitmap.PixelHeight - 1 -
                    ((y + yOffset) * sourceBitmap.PixelHeight) / targetBitmap.PixelHeight;

                // check that this value is in range
                sourceYLocation = Math.Min(sourceBitmap.PixelHeight - 1, Math.Max(0, sourceYLocation));

                // copy the required row
                int sourceIndex = sourceYLocation * sourceBitmap.PixelWidth;
                int targetIndex = y * targetBitmap.PixelWidth;
                for (int i = 0; i < targetBitmap.PixelWidth; i++)
                {
                    targetBitmap.Pixels[targetIndex++] = sourceBitmap.Pixels[sourceIndex++];
                }                
            }

            targetBitmap.Invalidate();

            LayoutRoot.Source = targetBitmap;
        }

        /// <summary>
        /// Compute the amplitude of the oscillations at a given Y position
        /// </summary>
        private double ComputeAmplitude(int y, int height)
        {
            // our amplitude range is 1 to 3
            return ((double)y * 2) / (double)height + 1.0;
        }

        /// <summary>
        /// Compute the sinusoid applied to teh image at the given location
        /// </summary>
        private double ComputeRipple(int y, int height, double time)
        {
            // provide a ripple that is the combination of two out of phase sine waves
            double phaseFactor = (double)y / (double)height;
            return Math.Sin(time + phaseFactor * 16) + Math.Sin(time + phaseFactor * 30)
                + Math.Sin(time + phaseFactor * 62);
        }

    }
}
