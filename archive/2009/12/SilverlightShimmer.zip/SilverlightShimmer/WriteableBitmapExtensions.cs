﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightShimmer
{
    public static class WriteableBitmapExtensions
    {
        /// <summary>
        /// Sets the Color value of the pixel at the given location
        /// </summary>
        public static void SetPixelColor(this WriteableBitmap bitmap,
            int x, int y, Color color)
        {
            int pixelIndex = x + y * bitmap.PixelWidth;
            bitmap.Pixels[pixelIndex] = color.B | (color.G << 8) | (color.R << 16) | (color.A << 24);
        }

        /// <summary>
        /// Gets the Color value of the pixel at the given location
        /// </summary>
        public static Color GetPixelColor(this WriteableBitmap bitmap,
            int x, int y)
        {            
            int pixelValue = bitmap.GetPixel(x,y);

            byte B = (byte)(pixelValue & 0xFF); pixelValue >>= 8;
            byte G = (byte)(pixelValue & 0xFF); pixelValue >>= 8;
            byte R = (byte)(pixelValue & 0xFF); pixelValue >>= 8;
            byte A = (byte)(pixelValue);

            return Color.FromArgb(A, R, G, B);
        }

        /// <summary>
        /// Gets the value of the pixel at the given location
        /// </summary>
        public static int GetPixel(this WriteableBitmap bitmap,
            int x, int y)
        {
            int pixelIndex = x + y * bitmap.PixelWidth;
            return bitmap.Pixels[pixelIndex];
        }

        /// <summary>
        /// Sets the value of the pixel at the given location
        /// </summary>
        public static void SetPixel(this WriteableBitmap bitmap,
            int x, int y, int value)
        {
            int pixelIndex = x + y * bitmap.PixelWidth;
            bitmap.Pixels[pixelIndex] = value;
        }
    }
}
