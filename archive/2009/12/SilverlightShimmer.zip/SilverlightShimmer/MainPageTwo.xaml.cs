﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace SilverlightShimmer
{
    public partial class MainPageTwo : UserControl
    {
        public MainPageTwo()
        {
            InitializeComponent();
        }

        private void MediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {
            VideoClip.Hide();
            PlayButton.Show();

            VideoClip.Position = new TimeSpan(0);            
        }

        private void Image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PlayButton.Hide();
            VideoClip.Show();
            VideoClip.Play();
        }
    }
}
