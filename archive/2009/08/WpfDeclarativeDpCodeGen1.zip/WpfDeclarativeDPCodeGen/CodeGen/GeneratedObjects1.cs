﻿






using System;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;




namespace WpfDeclarativeDPCodeGen
{
    public partial class RangeControl  
    {

        #region Maximum
            
            
        public double Maximum
        {
            get { return (double)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }
    
        /// <summary>
        /// Identifies the Maximum Dependency Property.
        /// <summary>
        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(double),
            typeof(RangeControl), new PropertyMetadata(0.0, OnMaximumPropertyChanged));
    
        
        private static void OnMaximumPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            RangeControl myClass = d as RangeControl;
            
            myClass.OnMaximumPropertyChanged(e);
        }
    
        partial void OnMaximumPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
    
        #region Minimum
            
            
        public double Minimum
        {
            get { return (double)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }
    
        /// <summary>
        /// Identifies the Minimum Dependency Property.
        /// <summary>
        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(double),
            typeof(RangeControl), new PropertyMetadata(0.0, OnMinimumPropertyChanged));
    
        
        private static void OnMinimumPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            RangeControl myClass = d as RangeControl;
            
            myClass.OnMinimumPropertyChanged(e);
        }
    
        partial void OnMinimumPropertyChanged(DependencyPropertyChangedEventArgs e);
        
            
        #endregion
     
    }
}


