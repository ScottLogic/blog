﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFPieChart.CodeGen;
using System.ComponentModel;

namespace WpfDeclarativeDPCodeGen
{
    /// <summary>
    /// Interaction logic for RangeControl.xaml
    /// </summary>
    [DependencyPropertyDecl("Maximum", typeof(double), 0.0)]
    [DependencyPropertyDecl("Minimum", typeof(double), 0.0)]
    [TypeConverter(typeof(string))]
    public partial class RangeControl : UserControl
    {
        public RangeControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// If max is less than min, swap their values
        /// </summary>
        private void Swap()
        {
            if (Maximum < Minimum)
            {
                double swap = Minimum;
                Minimum = Maximum;
                Maximum = swap;
            }
        }

        partial void OnMaximumPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Swap();
        }

        partial void OnMinimumPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Swap();
        }
    }
}
