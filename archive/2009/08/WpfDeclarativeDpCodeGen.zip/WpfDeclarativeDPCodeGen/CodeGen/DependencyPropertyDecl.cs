﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFPieChart.CodeGen
{
    [AttributeUsage(AttributeTargets.Class , AllowMultiple = true)]
    public class DependencyPropertyDecl : Attribute
    {
        public DependencyPropertyDecl(string name, Type type, object defaultValue)
        {
            this.name = name;
            this.type = type;
            this.defaultValue = defaultValue;
        }

        public string name;
        public Type type;
        public object defaultValue;
    }
}
