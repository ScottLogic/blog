﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SLViewModel
{
    /// <summary>
    /// The view model - wraps the model object to add UI-centric
    /// properties and behaviour
    /// </summary>
    public class ContactDetailsViewModel : INotifyPropertyChanged
    {
        private ContactDetails _model;

        private string _countryCodeText;

        private string _areaCodeText;

        private string _localNumberText;

        #region dynamically computed View Model properties

        public string CountryCodeText
        {
            get { return _countryCodeText; }
            set { _countryCodeText = value; OnPropertyChanged("CountryCodeText"); }
        }

        public string AreaCodeText
        {
            get { return _areaCodeText; }
            set { _areaCodeText = value; OnPropertyChanged("AreaCodeText"); }
        }

        public string LocalNumberText
        {
            get { return _localNumberText; }
            set { _localNumberText = value; OnPropertyChanged("LocalNumberText"); }
        }

        #endregion

        #region Wrapped model properties

        public string FullName
        {
            get { return _model.FullName; }
            set { _model.FullName = value; }
        }

        public string Email
        {
            get { return _model.Email; }
            set { _model.Email = value; }
        }

        public string Url
        {
            get { return _model.Url; }
            set { _model.Url = value; }
        }

        public string Country
        {
            get { return _model.Country; }
            set { _model.Country = value; }
        }

        public string Company
        {
            get { return _model.Company; }
            set { _model.Company = value; }
        }

        public long PhoneNumber
        {
            get { return _model.PhoneNumber; }
            set { _model.PhoneNumber = value; }
        }

        #endregion

        public ContactDetailsViewModel(ContactDetails model)
        {
            _model = model;
            _model.PropertyChanged += new PropertyChangedEventHandler(Model_PropertyChanged);

            ComputePhoneNumberProperties();
        }

        private void Model_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // forward property changed events from the model to the view
            OnPropertyChanged(e.PropertyName);
        }

        private void ComputePhoneNumberProperties()
        {
            string formattedNumber = _model.PhoneNumber.ToString();

            if (_model.Country == "UK")
            {
                CountryCodeText = "";
                AreaCodeText = formattedNumber.Substring(2, 4);
                LocalNumberText = " " + formattedNumber.Substring(6);
            }
            else
            {
                CountryCodeText = "+" + formattedNumber.Substring(0, 2);
                AreaCodeText = " (" + formattedNumber.Substring(2, 1) + ")" + formattedNumber.Substring(3, 3);
                LocalNumberText = " " + formattedNumber.Substring(6);
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
