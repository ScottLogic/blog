﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SLMiniViewModel
{
    public class PhoneNumberControlViewModel : INotifyPropertyChanged
    {
        private PhoneNumberControl _ctrl;

        private string _countryCodeText;

        private string _areaCodeText;

        private string _localNumberText;

        public string CountryCodeText
        {
            get { return _countryCodeText; }
            set { _countryCodeText = value; OnPropertyChanged("CountryCodeText");  }
        }

        public string AreaCodeText
        {
            get { return _areaCodeText; }
            set { _areaCodeText = value; OnPropertyChanged("AreaCodeText"); }
        }

        public string LocalNumberText
        {
            get { return _localNumberText; }
            set { _localNumberText = value; OnPropertyChanged("LocalNumberText"); }
        }

        public PhoneNumberControlViewModel(PhoneNumberControl ctrl)
        {
            _ctrl = ctrl;
            ComputeProperties();

            // listen to property changes in the control (we are interested
            // in just the Number property)
            _ctrl.PropertyChanged += Control_PropertyChanged;
        }

        private void Control_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Number" || e.PropertyName == "Country")
            {
                ComputeProperties();
            }
        }

        private void ComputeProperties()
        {
            if (_ctrl.Number == 0L)
                return;

            string formattedNumber = _ctrl.Number.ToString();

            if (_ctrl.Country == "UK")
            {
                CountryCodeText = "";
                AreaCodeText = formattedNumber.Substring(2, 4);
                LocalNumberText = " " + formattedNumber.Substring(6);
            }
            else
            {
                CountryCodeText = "+" + formattedNumber.Substring(0, 2);
                AreaCodeText = " (" + formattedNumber.Substring(2, 1) + ")" + formattedNumber.Substring(3, 3);
                LocalNumberText = " " + formattedNumber.Substring(6);
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
