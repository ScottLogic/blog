﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SLMiniViewModel
{
    public partial class PhoneNumberControl : UserControl, INotifyPropertyChanged
    {
        #region Number

        /// <summary>
        /// Number Dependency Property
        /// </summary>
        public static readonly DependencyProperty NumberProperty =
            DependencyProperty.Register("Number", typeof(long), typeof(PhoneNumberControl),
                new PropertyMetadata(0L, new PropertyChangedCallback(OnNumberChanged)));

        /// <summary>
        /// Gets or sets the Number property.  
        /// </summary>
        public long Number
        {
            get { return (long)GetValue(NumberProperty); }
            set { SetValue(NumberProperty, value); }
        }

        private static void OnNumberChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((PhoneNumberControl)d).OnNumberChanged(e);
        }

        protected virtual void OnNumberChanged(DependencyPropertyChangedEventArgs e)
        {
            OnPropertyChanged("Number");
        }
        
        #endregion

        #region Country

        /// <summary>
        /// Country Dependency Property
        /// </summary>
        public static readonly DependencyProperty CountryProperty =
            DependencyProperty.Register("Country", typeof(string), typeof(PhoneNumberControl),
                new PropertyMetadata(string.Empty, new PropertyChangedCallback(OnCountryChanged)));

        /// <summary>
        /// Gets or sets the Country property.  
        /// </summary>
        public string Country
        {
            get { return (string)GetValue(CountryProperty); }
            set { SetValue(CountryProperty, value); }
        }

        private static void OnCountryChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((PhoneNumberControl)d).OnCountryChanged(e);
        }

        protected virtual void OnCountryChanged(DependencyPropertyChangedEventArgs e)
        {
            OnPropertyChanged("Country");
        }

        #endregion

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
        

        public PhoneNumberControl()
        {
            InitializeComponent();

            LayoutRoot.DataContext = new PhoneNumberControlViewModel(this);
        }

        
    }
}
