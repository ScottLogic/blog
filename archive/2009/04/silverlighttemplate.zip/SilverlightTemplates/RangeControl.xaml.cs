﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.ComponentModel;

namespace SilverlightTemplates
{
    public partial class RangeControl : UserControl
    {
   
        public RangeControl()
        {
            InitializeComponent();

            // bind the text boxes to the dependency properties of this user control
            var maxBinding = new Binding("Maximum") { Source = this, Mode = BindingMode.TwoWay };
            maxTextBox.SetBinding(TextBox.TextProperty, maxBinding);

            var minBinding = new Binding("Minimum") { Source = this, Mode = BindingMode.TwoWay };
            minTextBox.SetBinding(TextBox.TextProperty, minBinding);
        }

        /// <summary>
        /// If max is less than min, swap their values
        /// </summary>
        private void Swap()
        {
            if (Maximum < Minimum)
            {
                double swap = Minimum;
                Minimum = Maximum;
                Maximum = swap;
            }
        }

        partial void OnMaximumPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Swap();
        }

        partial void OnMinimumPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            Swap();
        }
    }
}
