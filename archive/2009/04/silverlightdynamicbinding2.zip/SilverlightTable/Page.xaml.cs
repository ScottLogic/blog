﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Windows.Data;

namespace SilverlightTable
{
    public partial class Page : UserControl
    {
        SortableCollectionView _rows = new SortableCollectionView();

        private static readonly string[] s_names = new string[] { "Frank", "Bob", "Emily", "Sam", "Wilbur" };

        private static readonly string[] s_surnames = new string[] { "Smith", "Bloggs", "McArthur", "Dingle", "Scott" };

        public Page()
        {
            InitializeComponent();

            // generate some dummy data
            Random rand = new Random();
            for (int i = 0; i < 200; i++)
            {
                Row row = new Row();
                row["Forename"] = s_names[rand.Next(s_names.Length)];
                row["Surname"] = s_surnames[rand.Next(s_surnames.Length)];
                row["Age"] = rand.Next(40) + 10;
                row["Shoesize"] = rand.Next(10) + 5;               
                _rows.Add(row);
            }

            Binding binding = new Binding();

            // bind to our DataGrid
            _dataGrid.ItemsSource = _rows;            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // demonstrate the property changes from code-behind still work.
            Random rand = new Random();
            foreach (var row in _rows)
            {
                row["Age"] = rand.Next(10) + 5;
            }
        }      
    }

    /// <summary>
    /// A simple class used to communicate property value changes to a Row
    /// </summary>
    public class PropertyValueChange
    {
        private string _propertyName;

        private object _value;

        public object Value
        {
            get { return _value; }
        }

        public string PropertyName
        {
            get { return _propertyName; }
        }

        public PropertyValueChange(string propertyName, object value)
        {
            _propertyName = propertyName;
            _value = value;
        }
    }

    /// <summary>
    /// Represents a dynamic row of data
    /// </summary>
    public class Row : INotifyPropertyChanged
    {
        private Dictionary<string, object> _data = new Dictionary<string, object>();

        /// <summary>
        /// a string indexer for accessing the rows proeprties
        /// </summary>
        public object this [string index]
        {
            get
            {
                return _data[index];
            }
            set
            {
                _data[index] = value;

                // any property changes need to be signalled to UI elements bound to the Data property
                OnPropertyChanged("Data");
            }
        }

        /// <summary>
        /// A property which is used for integrating with the binding framework.
        /// </summary>
        public object Data
        {
            get
            {
                // when the binding framework reads this property, simple return the Row instance. The
                // RowIndexConverter takes care of extracting the correct property value
                return this;
            }
            set
            {
                // the RowIndexConverter will signal property changes by providing an instance of PropertyValueChange.
                PropertyValueChange setter = value as PropertyValueChange;
                _data[setter.PropertyName] = setter.Value;
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string property)
        {
            if (PropertyChanged!=null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        #endregion
    }
}
