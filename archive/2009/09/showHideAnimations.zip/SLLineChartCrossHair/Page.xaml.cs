﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Controls.DataVisualization;
using System.Windows.Controls.DataVisualization.Charting.Primitives;
using System.Windows.Controls.Primitives;

namespace SLLineChartCrossHair
{
    public partial class Page : UserControl
    {
        
        #region properties which provide convenient access to visual tree elements

        protected DataPointSeries LineSeries
        {
            get
            {
                return ((DataPointSeries)Chart.Series[0]);
            }
        }

        protected Border LocationIndicator
        {
            get
            {
                return ChartRoot.FindName("LocationIndicator") as Border;
            }
        }

        protected EdgePanel ChartArea
        {
            get
            {
                return ChartRoot.FindName("ChartArea") as EdgePanel;
            }
        }

        protected Grid PlotArea
        {
            get
            {
                return ChartRoot.FindName("PlotArea") as Grid;
            }
        }

        protected Grid Crosshair
        {
            get
            {
                return ChartRoot.FindName("Crosshair") as Grid;
            }
        }

        protected Grid ChartRoot
        {
            get
            {
                // chart area is within a different namescope to this page, therefore
                // we must navigate the visual tree to locate it
                return VisualTreeHelper.GetChild(Chart, 0) as Grid;
            }
        }

        protected LinearAxis YAxis
        {
            get
            {
                return (LinearAxis)Chart.Axes[0];
            }
        }

        protected DateTimeAxis XAxis
        {
            get
            {
                return (DateTimeAxis)Chart.Axes[1];
            }
        }
        
        #endregion

        #region constructor
        
        public Page()
        {
            InitializeComponent();

            XDocument doc = XDocument.Load("chartData.xml");
            var elements = from dataPoint in doc.Descendants("dataPoint")                           
                           select new KeyValuePair<DateTime, double>
                           (
                               DateTime.Parse(dataPoint.Attribute("date").Value.Substring(0, 19)),
                               Double.Parse(dataPoint.Attribute("value").Value)
                           );

            LineSeries.ItemsSource = elements;
        }
        
        #endregion

        #region utility methods

        /// <summary>
        /// Transforms the supplied position on the plot area grid into a point within
        /// the plot area coordinate system
        /// </summary>
        private KeyValuePair<DateTime, double> GetPlotAreaCoordinates(Point position)
        {
            IComparable yAxisHit = ((IRangeAxis)YAxis).GetValueAtPosition(
                new UnitValue(PlotArea.ActualHeight - position.Y, Unit.Pixels));

            IComparable xAxisHit = ((IRangeAxis)XAxis).GetValueAtPosition(
                new UnitValue(position.X, Unit.Pixels));

            return new KeyValuePair<DateTime, double>((DateTime)xAxisHit, (double)yAxisHit);
        }

        #endregion

        #region event handlers

        private void CrosshairContainer_MouseMove(object sender, MouseEventArgs e)
        {
            if (LineSeries.ItemsSource == null)
                return;

            Point mousePos = e.GetPosition(PlotArea);
            KeyValuePair<DateTime, double> crosshairLocation = GetPlotAreaCoordinates(mousePos);

            LocationIndicator.DataContext = crosshairLocation;
            Crosshair.DataContext = mousePos;           
        }


        private void CrosshairContainer_MouseEnter(object sender, MouseEventArgs e)
        {
            LocationIndicator.Show();
            Crosshair.Show();
            ChartRoot.Cursor = Cursors.None;
        }

        private void CrosshairContainer_MouseLeave(object sender, MouseEventArgs e)
        {
            LocationIndicator.Hide();
            Crosshair.Hide();
            ChartRoot.Cursor = Cursors.Arrow;
        }

        #endregion

        
    }
}
