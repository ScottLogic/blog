﻿using System;
using System.Linq;
using System.Windows.Data;
using Microsoft.Xna.Framework.Media;
using System.Windows.Media.Imaging;
using System.Collections;
using System.Collections.Generic;

namespace PhotoBrowser
{
  public class PictureThumbnailConverter : IValueConverter
  {

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      Picture picture = value as Picture;
      BitmapImage src = new BitmapImage();
      src.SetSource(picture.GetThumbnail());
      return src;
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      return null;
    }
  }


  public class LastConverter : IValueConverter
  {

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      IList enumerable = value as IList;
      return enumerable.Cast<object>().Last();
    }
    
    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      return null;
    }
  }
}
