﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Phone.Controls;
using ExifLib;
using System.ComponentModel;
using Microsoft.Xna.Framework.Media;
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System;
using System.Windows;
using System.IO;
using System.Windows.Input;

namespace PhotoBrowser
{
  public partial class MainPage : PhoneApplicationPage
  {
    // a collection of images
    private List<LocatedImage> _images = new List<LocatedImage>();

    // Constructor
    public MainPage()
    {
      InitializeComponent();

      BackgroundWorker bw = new BackgroundWorker();
      bw.WorkerReportsProgress = true;

      // analyse the pictures that reside in the Media Library in a background thread
      bw.DoWork += (s, e) =>
      {
        var ml = new MediaLibrary();

        using (var pics = ml.Pictures)
        {
          int total = pics.Count;
          int index = 0;
          foreach (Picture picture in pics)
          {
            // read the EXIF data for this image
            JpegInfo info = ExifReader.ReadJpeg(picture.GetImage(), picture.Name);

            // check if we have co-ordinates
            if (info.GpsLatitude.First() != 0.0)
            {
              _images.Add(new LocatedImage()
              {
                Picture = picture,
                Lat = DecodeLatitude(info),
                Long = DecodeLongitude(info)
              });
            }

            // report progress back to the UI thread
            string progress = string.Format("{0} / {1}", index, total);
            bw.ReportProgress((index * 100 / total), progress);

            index++;
          }
        }
      };

      // update progress on the UI thread
      bw.ProgressChanged += (s, e) =>
        {
          string title = (string)e.UserState;
          ApplicationTitle.Text = title;
        };

      bw.RunWorkerAsync();

      // when analysis is complete, add the pushpins
      bw.RunWorkerCompleted += (s, e) =>
        {
          ApplicationTitle.Text = "";
          AddPushpins();
        };
    }

    private void AddPushpins()
    {
      List<Pushpin> pushPins = new List<Pushpin>();

      // create a pushpin for each picture
      foreach (var image in _images)
      {
        Location location = new Location()
        {
          Latitude = image.Lat,
          Longitude = image.Long
        };

        Pushpin myPushpin = new Pushpin()
        {
          Location = location,
          DataContext = image,
          Content = image,
          ContentTemplate = this.Resources["MarkerTemplate"] as DataTemplate
        };

        pushPins.Add(myPushpin);
      }

      // add them to the map via a clusterer
      var clusterer = new PushpinClusterer(map, pushPins, this.Resources["ClusterTemplate"] as DataTemplate);
    }

    public static double ToDegrees(double[] data)
    {
      return data[0] + data[1] / 60.0 + data[2] / (60.0 * 60.0);
    }

    private static double DecodeLatitude(JpegInfo info)
    {
      double degrees = ToDegrees(info.GpsLatitude);
      return info.GpsLatitudeRef == ExifGpsLatitudeRef.North ? degrees : -degrees;
    }

    private static double DecodeLongitude(JpegInfo info)
    {
      double degrees = ToDegrees(info.GpsLongitude);
      return info.GpsLongitudeRef == ExifGpsLongitudeRef.East ? degrees : -degrees;
    }

    /// <summary>
    /// Saves a screenshot, thanks to Laurent Bugnion:
    /// http://geekswithblogs.net/lbugnion/archive/2010/12/28/taking-a-screenshot-from-within-a-silverlight-wp7-application.aspx
    /// </summary>
    public static void SaveToMediaLibrary(FrameworkElement element, string title)
    {
      try
      {
        var bmp = new WriteableBitmap(element, null);

        var ms = new MemoryStream();
        bmp.SaveJpeg(
            ms,
            (int)element.ActualWidth,
            (int)element.ActualHeight,
            0,
            100);
        ms.Seek(0, SeekOrigin.Begin);

        var lib = new MediaLibrary();
        var filePath = string.Format(title + ".jpg");
        lib.SavePicture(filePath, ms);

        MessageBox.Show(
            "Saved in your media library!",
            "Done",
            MessageBoxButton.OK);
      }
      catch
      {
        MessageBox.Show(
            "There was an error. Please disconnect your phone from the computer before saving.",
            "Cannot save",
            MessageBoxButton.OK);
      }
    }

    private void TitlePanel_DoubleTap(object sender, GestureEventArgs e)
    {
      SaveToMediaLibrary(this, "screenshot");
    }

  }

  /// <summary>
  /// A picture with associated lat / long
  /// </summary>
  public class LocatedImage
  {
    public Picture Picture { get; set; }
    public double Lat { get; set; }
    public double Long { get; set; }
  }
}