﻿
function ApplicationViewModel() {

  var that = this;

  this.viewModelBackStack = ko.observableArray();

  this.backButtonRequired = ko.dependentObservable(function () {    
    return this.viewModelBackStack().length > 1;
  }, this);

  this.currentViewModel = ko.dependentObservable(function () {
    return this.viewModelBackStack()[this.viewModelBackStack().length-1];
  }, this);

  this.navigateTo = function (viewModel) {
    this.viewModelBackStack.push(viewModel);
  }

  this.back = function () {
    this.viewModelBackStack.pop();
  }
}