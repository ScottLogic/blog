﻿
/// <summary>
/// A view model for searching twitter for a given term
/// </summary>
function TwitterSearchViewModel() {

  var that = this;

  // --- properties

  this.isSearching = ko.observable(false);
  this.searchTerm = ko.observable("wpug");  
  this.tweets = ko.observableArray();
  this.template = "twitterSearchView";

  // --- functions
    
  // search twitter for the given string
  this.search = function () {
    if (this.searchTerm() != "") {

      this.isSearching(true);
      var url = "http://search.twitter.com/search.json?q=" +
            encodeURIComponent(that.searchTerm());

       $.ajax({
        dataType: "jsonp",
        url: url,
        success: function (response) {
          // clear the results
          that.tweets.removeAll();
          // add the new items
          $.each(response.results, function () {
            var tweet = new TweetViewModel();
            tweet.initialize(this);
            that.tweets.push(tweet);
          });

          that.isSearching(false);
        }
      });
    }
  }
};