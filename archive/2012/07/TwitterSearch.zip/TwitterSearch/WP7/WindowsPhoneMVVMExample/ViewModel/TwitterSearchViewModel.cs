﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;
using System.ComponentModel;
using System.Collections.Generic;

namespace WindowsPhoneMVVMExample.ViewModel
{
  public static class AtomConst
  {
    private static string AtomNamespace = "http://www.w3.org/2005/Atom";

    public static XName Entry = XName.Get("entry", AtomNamespace);

    public static XName ID = XName.Get("id", AtomNamespace);

    public static XName Link = XName.Get("link", AtomNamespace);

    public static XName Published = XName.Get("published", AtomNamespace);

    public static XName Name = XName.Get("name", AtomNamespace);

    public static XName Title = XName.Get("title", AtomNamespace);
  }

  public class TwitterSearchViewModel : INotifyPropertyChanged
  {
    private readonly string _twitterUrl = "http://search.twitter.com/search.atom?rpp=100&&q=";

    private WebClient _webClient = new WebClient();

    private String _searchText = "";

    private bool _isSearching = false;


    private readonly ObservableCollection<TweetViewModel> _feedItems = new ObservableCollection<TweetViewModel>();

    public TwitterSearchViewModel()
    {
      _webClient.DownloadStringCompleted += WebClient_DownloadStringCompleted;
    }

    /// <summary>
    /// Parses the response from our twitter request, creating a list of FeedItemViewModelinstances
    /// </summary>
    private void WebClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      var items = ParseXMLResponse(e.Result);

      _feedItems.Clear();
      foreach (var item in items)
      {
        _feedItems.Add(item);
      }

      IsSearching = false;
    }

    public string SearchText
    {
      get
      {
        return _searchText;
      }
      set
      {
        _searchText = value;
        OnPropertyChanged("SearchText");
      }
    }

    public bool IsSearching
    {
      get
      {
        return _isSearching;
      }
      set
      {
        _isSearching = value;
        OnPropertyChanged("IsSearching");
      }
    }

    /// <summary>
    /// Gets the feed items
    /// </summary>
    public ObservableCollection<TweetViewModel> FeedItems
    {
      get { return _feedItems; }
    }

    /// <summary>
    /// Gets a feed item by its Id
    /// </summary>
    public TweetViewModel GetFeedItem(long id)
    {
      return _feedItems.SingleOrDefault(item => item.Id == id);
    }
    
    /// <summary>
    /// Update the feed items
    /// </summary>
    public void ExecuteSearch()
    {
      IsSearching = true;
      _webClient.DownloadStringAsync(new Uri(_twitterUrl + SearchText));
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }

    /// <summary>
    /// Parses the response from our twitter request, creating a list of TweetViewModel instances
    /// </summary>
    private List<TweetViewModel> ParseXMLResponse(string xml)
    {

      var doc = XDocument.Parse(xml);
      var items = doc.Descendants(AtomConst.Entry)
                        .Select(entryElement => new TweetViewModel()
                        {
                          Title = entryElement.Descendants(AtomConst.Title).Single().Value,
                          Id = long.Parse(entryElement.Descendants(AtomConst.ID).Single().Value.Split(':')[2]),
                          ProfileImageUrl = entryElement.Descendants(AtomConst.Link).Skip(1).First().Attribute("href").Value,
                          Timestamp = DateTime.Parse(entryElement.Descendants(AtomConst.Published).Single().Value),
                          AuthorId = ExtractTwitterAuthorId(entryElement.Descendants(AtomConst.Name).Single().Value),
                          AuthorName = ExtractTwitterAuthorName(entryElement.Descendants(AtomConst.Name).Single().Value)
                        }
      );

      return items.ToList();
    }

    private static string ExtractTwitterAuthorId(string name)
    {
      return name.Substring(0, name.IndexOf(" "));
    }

    private static string ExtractTwitterAuthorName(string name)
    {
      int bracketIndex = name.IndexOf("(") + 1;
      return name.Substring(bracketIndex, name.Length - bracketIndex - 1);
    }
  }
}
