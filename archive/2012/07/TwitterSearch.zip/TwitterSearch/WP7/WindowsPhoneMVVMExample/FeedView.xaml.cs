﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using NavigationListControl;
using WindowsPhoneMVVMExample.ViewModel;
using System.ComponentModel;
using LinqToVisualTree;
using System.Windows.Controls.Primitives;
using System.Diagnostics;

namespace WindowsPhoneMVVMExample
{
  public partial class FeedView : PhoneApplicationPage
  {
    private static readonly string ScrollOffsetKey = "ScrollOffsetKey";
    
    public FeedView()
    {
      InitializeComponent();
    }

    private void NavigationList_Navigation(object sender, NavigationEventArgs e)
    {
      var selectedItem = e.Item as TweetViewModel;

      // navigate to the feed items page
      NavigationService.Navigate(new Uri("/FeedItemView.xaml?id=" + selectedItem.Id, UriKind.Relative));
    }
        
    private void Button_Click(object sender, RoutedEventArgs e)
    {
      App.Current.ViewModel.ExecuteSearch();
    }

   
  }
}