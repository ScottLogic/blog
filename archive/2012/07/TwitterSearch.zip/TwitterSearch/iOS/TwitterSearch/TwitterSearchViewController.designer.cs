// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace TwitterSearch
{
	[Register ("TwitterSearchViewController")]
	partial class TwitterSearchViewController
	{
		[Outlet]
		MonoTouch.UIKit.UITextField txtSearch { get; set; }

		[Outlet]
		MonoTouch.UIKit.UITableView tweetList { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIActivityIndicatorView activityIndicator { get; set; }

		[Action ("searchButtonPressed:")]
		partial void searchButtonPressed (MonoTouch.Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (txtSearch != null) {
				txtSearch.Dispose ();
				txtSearch = null;
			}

			if (tweetList != null) {
				tweetList.Dispose ();
				tweetList = null;
			}

			if (activityIndicator != null) {
				activityIndicator.Dispose ();
				activityIndicator = null;
			}
		}
	}
}
