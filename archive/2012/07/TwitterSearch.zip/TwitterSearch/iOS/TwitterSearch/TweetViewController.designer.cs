// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace TwitterSearch
{
	[Register ("TweetViewController")]
	partial class TweetViewController
	{
		[Outlet]
		MonoTouch.UIKit.UITextView txtTweet { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView imgProfile { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lblAuthorName { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lblAuthorId { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lblTweetTime { get; set; }
		
		void ReleaseDesignerOutlets ()
		{
			if (txtTweet != null) {
				txtTweet.Dispose ();
				txtTweet = null;
			}

			if (imgProfile != null) {
				imgProfile.Dispose ();
				imgProfile = null;
			}

			if (lblAuthorName != null) {
				lblAuthorName.Dispose ();
				lblAuthorName = null;
			}

			if (lblAuthorId != null) {
				lblAuthorId.Dispose ();
				lblAuthorId = null;
			}

			if (lblTweetTime != null) {
				lblTweetTime.Dispose ();
				lblTweetTime = null;
			}
		}
	}
}
