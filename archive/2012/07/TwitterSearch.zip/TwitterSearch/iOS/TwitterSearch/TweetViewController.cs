using System;
using System.Drawing;

using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace TwitterSearch
{
  public partial class TweetViewController : UIViewController
  {
    public TweetViewController (TweetModel tweet) : base ("TweetViewController", null)
    {
      Tweet = tweet;
      Title = "Tweet";
    }
		
    public override void DidReceiveMemoryWarning ()
    {
      // Releases the view if it doesn't have a superview.
      base.DidReceiveMemoryWarning ();
			
      // Release any cached data, images, etc that aren't in use.
    }
		
    public override void ViewDidLoad ()
    {
      base.ViewDidLoad ();
			
      // Perform any additional setup after loading the view, typically from a nib.
      txtTweet.Text = Tweet.Title;
      imgProfile.Image = UIImage.LoadFromData (NSData.FromUrl (new NSUrl (Tweet.ProfileImageUrl)));
      lblAuthorId.Text = "@" + Tweet.AuthorId;
      lblAuthorName.Text = Tweet.AuthorName;
      lblTweetTime.Text = Tweet.FormattedTime;
    }
		
    public override void ViewDidUnload ()
    {
      base.ViewDidUnload ();
			
      // Clear any references to subviews of the main view in order to
      // allow the Garbage Collector to collect them sooner.
      //
      // e.g. myOutlet.Dispose (); myOutlet = null;
			
      ReleaseDesignerOutlets ();
    }
		
    public override bool ShouldAutorotateToInterfaceOrientation (UIInterfaceOrientation toInterfaceOrientation)
    {
      // Return true for supported orientations
      return (toInterfaceOrientation != UIInterfaceOrientation.PortraitUpsideDown);
    }
		
    public TweetModel Tweet {
      get;
      private set;
    }
  }
}


