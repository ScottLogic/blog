using System;
using System.Drawing;

using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Collections.Generic;

namespace TwitterSearch
{
  public partial class TwitterSearchViewController : UIViewController, TwitterSearchPresenter.View
  {
    public TwitterSearchViewController () : base ("TwitterSearchViewController", null)
    {
      this.Title = "Twitter Search";
    }
		
    public override void DidReceiveMemoryWarning ()
    {
      // Releases the view if it doesn't have a superview.
      base.DidReceiveMemoryWarning ();
			
      // Release any cached data, images, etc that aren't in use.
    }
		
    public override void ViewDidLoad ()
    {
      base.ViewDidLoad ();
			
      // Perform any additional setup after loading the view, typically from a nib.
      txtSearch.Delegate = new CatchEnterDelegate ();
    }
		
    public override void ViewDidUnload ()
    {
      base.ViewDidUnload ();
			
      // Clear any references to subviews of the main view in order to
      // allow the Garbage Collector to collect them sooner.
      //
      // e.g. myOutlet.Dispose (); myOutlet = null;
					
			
      ReleaseDesignerOutlets ();
    }
		
    public override bool ShouldAutorotateToInterfaceOrientation (UIInterfaceOrientation toInterfaceOrientation)
    {
      // Return true for supported orientations
      return (toInterfaceOrientation != UIInterfaceOrientation.PortraitUpsideDown);
    }
		
    public string SearchText {
      get {
        return txtSearch.Text;
      }
    }
						
    public void SetSearchResults (List<TweetModel> results)
    {
      tweetList.Source = new TableSource (
        NavigationController,
        results.ToArray ()
      );
      tweetList.ReloadData ();
    }
		
    public void SetIsSearching (bool isSearching)
    {
      if (isSearching) {
        activityIndicator.StartAnimating ();
        tweetList.Hidden = true;
      } else {
        activityIndicator.StopAnimating ();
        tweetList.Hidden = false;
      }
    }
		
    partial void searchButtonPressed (NSObject sender)
    {
      // hide the keyboard
      txtSearch.ResignFirstResponder ();
			
      // start the search
      OnStartSearch ();
    }
						
    public event EventHandler StartSearch;
		
    protected void OnStartSearch ()
    {
      if (StartSearch != null) {
        StartSearch (this, EventArgs.Empty);
      }
    }
		
    public class CatchEnterDelegate : UITextFieldDelegate
    {
      public override bool ShouldReturn (UITextField textField)
      {
        textField.ResignFirstResponder ();
        return true;
      }
    }
		
    public class TableSource : UITableViewSource
    {
      private TweetModel[] _tableItems;
      private static readonly string _cellIdentifier = "TableCell";
      private UINavigationController _navigationController;

      public TableSource (UINavigationController navigationController, TweetModel[] items)
      {
        _tableItems = items;
        _navigationController = navigationController;
      }

      public override int RowsInSection (UITableView tableview, int section)
      {
        return _tableItems.Length;
      }

      public override UITableViewCell GetCell (UITableView tableView, MonoTouch.Foundation.NSIndexPath indexPath)
      {
        UITableViewCell cell = tableView.DequeueReusableCell (_cellIdentifier);
        // if there are no cells to reuse, create a new one
        if (cell == null) {
          cell = new UITableViewCell (
            UITableViewCellStyle.Subtitle,
            _cellIdentifier
          );
        }
        var tweet = _tableItems [indexPath.Row];
        cell.TextLabel.Text = tweet.AuthorName;
        cell.DetailTextLabel.Text = tweet.Title;
        cell.Accessory = UITableViewCellAccessory.DisclosureIndicator;
        cell.ImageView.Image = UIImage.LoadFromData (NSData.FromUrl (new NSUrl (tweet.ProfileImageUrl)));
        return cell;
      }

      public override void RowSelected (UITableView tableView, NSIndexPath indexPath)
      {
        var tweet = _tableItems [indexPath.Row];
				
        var controller = new TweetViewController (tweet);
				
        _navigationController.PushViewController (controller, true);
      }
    }
  }
}






	