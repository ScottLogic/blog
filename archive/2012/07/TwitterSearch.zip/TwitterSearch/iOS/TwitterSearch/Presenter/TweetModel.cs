using System;
namespace TwitterSearch
{
  public class TweetModel
  {
    public TweetModel ()
    {
    }

    public long Id { get; set; }

    public string Title { get; set; }

    public string AuthorId { get; set; }
		
    public string AuthorName { get; set; }

    public string ProfileImageUrl { get; set; }

    public DateTime Timestamp { get; set; }
		
    public string FormattedTime {
      get {
        var diffInSeconds = (DateTime.Now - Timestamp).TotalSeconds;
        var diffInMinutes = (DateTime.Now - Timestamp).TotalMinutes;
        var diffInHours = (DateTime.Now - Timestamp).TotalHours;
			
        if (diffInSeconds < 60) {
          return string.Format ("{0:N0} seconds ago", diffInSeconds);
        }
			
        if (diffInMinutes < 60) {
          return string.Format ("{0:N0} minutes ago", diffInMinutes);
        }
			
        if (diffInHours < 8) {
          return string.Format ("{0:N0} hours ago", diffInHours);
        }
			
        return Timestamp.ToString ("M");
      }
    }
  }
}


