using System;
using System.Collections.Generic;
using System.Net;
using System.Xml.Linq;
using System.Linq;

namespace TwitterSearch
{
  public class TwitterSearchPresenter
  {
    public interface View
    {
      string SearchText { get; }
      
      void SetIsSearching (bool isSearching);
            
      void SetSearchResults (List<TweetModel> results);
            
      event EventHandler StartSearch;
    }
    
    private readonly string _twitterUrl = "http://search.twitter.com/search.atom?rpp=100&&q=";
    private View _view;
    
    public TwitterSearchPresenter ()
    {
      
    }
    
    public void SetView (View view)
    {
      this._view = view;
      view.StartSearch += View_StartSearch;
    }
    
    private void View_StartSearch (object sender, EventArgs e)
    {
      string uri = _twitterUrl + _view.SearchText;
      
      _view.SetIsSearching (true);
      
      WebClient client = new WebClient ();
      client.DownloadStringCompleted += Client_SearchComplete;
      client.DownloadStringAsync (new Uri (uri), null);
    }
    
    private void Client_SearchComplete (object sender, DownloadStringCompletedEventArgs e)
    {
      var tweets = ParseXMLResponse (e.Result);
      _view.SetSearchResults (tweets);
      _view.SetIsSearching (false);
    }
    
    /// <summary>
    /// Parses the response from our twitter request, creating a list of TweetViewModel instances
    /// </summary>
    private List<TweetModel> ParseXMLResponse (string xml)
    {
      
      var doc = XDocument.Parse (xml);
      var items = doc.Descendants (AtomConst.Entry)
                        .Select (entryElement => new TweetModel ()
                        {
                          Title = entryElement.Descendants(AtomConst.Title).Single().Value,
                          Id = long.Parse(entryElement.Descendants(AtomConst.ID).Single().Value.Split(':')[2]),
                          ProfileImageUrl =  entryElement.Descendants(AtomConst.Link).Skip(1).First().Attribute("href").Value,
                          Timestamp = DateTime.Parse(entryElement.Descendants(AtomConst.Published).Single().Value),
                          AuthorId = ExtractTwitterAuthorId(entryElement.Descendants(AtomConst.Name).Single().Value),
                          AuthorName = ExtractTwitterAuthorName(entryElement.Descendants(AtomConst.Name).Single().Value)
                        }
      );
  
      return items.ToList ();
    }
    
    private static string ExtractTwitterAuthorId (string name)
    {
      return name.Substring (0, name.IndexOf (" "));
    }
    
    private static string ExtractTwitterAuthorName (string name)
    {
      int bracketIndex = name.IndexOf ("(") + 1;
      return name.Substring (bracketIndex, name.Length - bracketIndex - 1);
    }

  }
}






                            
