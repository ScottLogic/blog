﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Collections.Generic;

namespace ClearStyle
{
  public class RangeObservableCollection<T> : ObservableCollection<T>
  {
    private bool _suppressNotification = false;

    protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
    {
      if (!_suppressNotification)
        base.OnCollectionChanged(e);
    }

    public void AddRange(IEnumerable<T> list)
    {
      if (list == null)
        throw new ArgumentNullException("list");

      _suppressNotification = true;

      foreach (T item in list)
      {
        Add(item);
      }
      _suppressNotification = false;
      OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }
  }

}
