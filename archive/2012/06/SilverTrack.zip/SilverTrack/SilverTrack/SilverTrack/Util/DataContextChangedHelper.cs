/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Windows;
using System.Windows.Data;

namespace SilverTrack.Util
{
    /// <summary>
    /// Jeremy Likeness' DataContextChangedHelper class. See:
    /// http://www.codeproject.com/Articles/38559/Silverlight-DataContext-Changed-Event.aspx
    /// NOTE: This code will be redundant when Silverlight 5 is released.
    /// </summary>
    
    public interface IDataContextChangedHandler<T> where T : FrameworkElement
    {
        void DataContextChanged(T sender, DependencyPropertyChangedEventArgs e);
    }

    public static class DataContextChangedHelper<T> where T : FrameworkElement, IDataContextChangedHandler<T>
    {
        private const string INTERNAL_CONTEXT = "InternalDataContext";

        public static readonly DependencyProperty InternalDataContextProperty = DependencyProperty.Register(INTERNAL_CONTEXT,
                                        typeof(Object), typeof(T), new PropertyMetadata(_DataContextChanged));

        private static void _DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            T control = (T)sender;
            control.DataContextChanged(control, e);
        }

        public static void Bind(T control)
        {
            control.SetBinding(InternalDataContextProperty, new Binding());
        }
    }
}