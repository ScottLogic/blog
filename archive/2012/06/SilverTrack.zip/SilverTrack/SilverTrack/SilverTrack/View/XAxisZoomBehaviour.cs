/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using Visiblox.Charts;

namespace SilverTrack.View
{
    public partial class XAxisZoomBehaviour : BehaviourBase, INotifyPropertyChanged
    {
        #region Fields

        #region Constants

        private const double PATH_MAX_SIZE = 32000;

        #endregion

        #region Private Fields

        private ZoomRectangle _zoomRect = new ZoomRectangle();
        private Zoom _initialZoom;
        private bool _zooming;
        private bool _leftMouseDown;
        private Point _leftMouseDownPosition;

        #endregion

        #endregion

        #region Properties

        #region Public properties

        public double Offset
        {
            get;
            set;
        }

        public double Scale
        {
            get;
            set;
        }

        #endregion

        #endregion

        #region Methods

        #region Constructors

        public XAxisZoomBehaviour() : base("Zoom") { }

        #endregion

        #region Public

        public event EventHandler ZoomStarted;

        public override void DeInit()
        {
            if (BehaviourContainer != null && BehaviourContainer.Children.Contains(_zoomRect))
            {
                BehaviourContainer.Children.Remove(_zoomRect);
            }
        }

        public override void MouseLeftButtonDoubleClick(Point position)
        {
            ZoomToScaleWithOffset(1.0, 0.0);
        }

        public override void MouseLeftButtonDown(Point position)
        {
            if (BehaviourContainer.CaptureMouse() && !_zooming)
            {
                _leftMouseDown = true;
                _leftMouseDownPosition = position;
                _zoomRect.SetValue(Canvas.LeftProperty, position.X);
                _zoomRect.SetValue(Canvas.TopProperty, 0.0);
                _zoomRect.Width = 0;
                _zoomRect.Height = Double.IsNaN(Chart.ActualHeight) ? 400 : Chart.ActualHeight;
                _zoomRect.Visibility = Visibility.Visible;
            }
        }

        public override void MouseMove(Point position)
        {
            position = EnsurePointIsOnChart(position);
            if (_leftMouseDown)
            {
                ChangeZoomRectangle(position);
                double xPosOne = (position.X);
                double xPosTwo = (_leftMouseDownPosition.X);

                if (CheckZoomIsPossible(xPosOne, xPosTwo))
                {
                    if (_zoomRect.Border != null)
                    {
                        _zoomRect.Border.Background = _zoomRect.Background;
                        _zoomRect.Border.BorderBrush = _zoomRect.Foreground;
                    }
                }
                else
                {
                    if (_zoomRect.Border != null)
                    {
                        _zoomRect.Border.Background = _zoomRect.NotZoomableBackground;
                        _zoomRect.Border.BorderBrush = _zoomRect.NotZoomableForeground;
                    }
                }
            }
        }

        public override void MouseLeftButtonUp(Point position)
        {
            position = EnsurePointIsOnChart(position);
            if (!_leftMouseDown)
                return;

            _leftMouseDown = false;
            BehaviourContainer.ReleaseMouseCapture();
            _zoomRect.Visibility = Visibility.Collapsed;

            if (Math.Abs(position.X - _leftMouseDownPosition.X) < 2)
                return;

            if (_initialZoom == null)
                _initialZoom = new Zoom(Chart.XAxis.Zoom);

            double xPosOne = (position.X);
            double xPosTwo = (_leftMouseDownPosition.X);

            if (CheckZoomIsPossible(xPosOne, xPosTwo))
            {
                Zoom xZoom = Chart.XAxis.GetZoom(xPosTwo, xPosOne);
                ZoomToScaleWithOffset(xZoom.Scale, xZoom.Offset);
            }
        }

        public override void LostMouseCapture()
        {
            _leftMouseDown = false;
            _zoomRect.Width = 0;
            _zoomRect.Height = 0;
            _zoomRect.Visibility = Visibility.Collapsed;
        }

        public bool ZoomToScaleWithOffset(double xScale, double xOffset)
        {
            Zoom zoom = new Zoom() { Scale = xScale, Offset = xOffset };
            int milliseconds = 300;

            Offset = xOffset;
            Scale = xScale;

            if (!_zooming)
            {
                _zooming = true;

                if (ZoomStarted != null)
                {
                    ZoomStarted(this, new EventArgs());
                }

                Storyboard sb = new Storyboard();

                DoubleAnimation b = new DoubleAnimation() { From = Chart.XAxis.Zoom.Scale, To = zoom.Scale };
                b.Duration = new Duration(new TimeSpan(0, 0, 0, 0, milliseconds));
                sb.Children.Add(b);
                Storyboard.SetTarget(b, Chart.XAxis.Zoom);
                Storyboard.SetTargetProperty(b, new PropertyPath("(Scale)"));

                DoubleAnimation b2 = new DoubleAnimation() { From = Chart.XAxis.Zoom.Offset, To = zoom.Offset };
                b2.Duration = new Duration(new TimeSpan(0, 0, 0, 0, milliseconds));
                sb.Children.Add(b2);
                Storyboard.SetTarget(b2, Chart.XAxis.Zoom);
                Storyboard.SetTargetProperty(b2, new PropertyPath("(Offset)"));

                sb.Completed += new EventHandler(ZoomHasFinished);
                sb.Begin();

                return true;
            }
            return false;
        }

        #endregion

        #region Private/Internal

        private void ZoomHasFinished(object sender, EventArgs e)
        {
            _zooming = false;
        }

        protected override void Init()
        {
            _zoomRect.Visibility = Visibility.Collapsed;
            _zoomRect = new ZoomRectangle();
            BehaviourContainer.Children.Add(_zoomRect);
        }

        private Point EnsurePointIsOnChart(Point point)
        {
            double xPos = Math.Max(0, Math.Min(point.X, BehaviourContainer.ActualWidth));
            double yPos = Math.Max(0, Math.Min(point.Y, BehaviourContainer.ActualHeight));
            return new Point(xPos, yPos);
        }

        private void ChangeZoomRectangle(Point position)
        {
            if (position.X > _leftMouseDownPosition.X)
            {
                _zoomRect.Width = position.X - _leftMouseDownPosition.X;
                _zoomRect.SetValue(Canvas.LeftProperty, _leftMouseDownPosition.X);
            }
            else
            {
                _zoomRect.Width = _leftMouseDownPosition.X - position.X;
                _zoomRect.SetValue(Canvas.LeftProperty, position.X);
            }
        }

        private bool CheckZoomIsPossible(double xPosOne, double xPosTwo)
        {
            if (xPosOne == xPosTwo)
            {
                xPosTwo = xPosTwo + 0.1;
            }

            Zoom zoom = Chart.XAxis.GetZoom(xPosTwo, xPosOne);
            if (1 / zoom.Scale < FindMaximumScaleForZoom())
            {
                return true;
            }
            return false;
        }

        private double FindMaximumScaleForZoom()
        {
            double chartWidth = Double.IsNaN(Chart.ActualWidth) ? 400 : Chart.ActualWidth;
            double maximumWidthScale = PATH_MAX_SIZE / chartWidth;
            return maximumWidthScale;
        }

        #endregion

        #endregion
    }
}