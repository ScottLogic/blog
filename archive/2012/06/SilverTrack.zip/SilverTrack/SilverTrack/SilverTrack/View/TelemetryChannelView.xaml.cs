/*
 * Copyright Scott Logic Limited 2011
 */

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SilverTrack.ViewModel;
using Visiblox.Charts;

namespace SilverTrack.View
{
    public partial class TelemetryChannelView : UserControl
    {
        public TelemetryChannelView()
        {
            InitializeComponent();
            (ChannelChart.Series[1] as LineSeries).YAxis = ChannelChart.SecondaryYAxis;
            ChannelChart.MouseMove += new MouseEventHandler(ChannelChart_MouseMove);
        }

        /// <summary>
        /// Synchronises the vertical crosshair across all of the charts displayed by sending the mouse
        /// position to the current TelemetryViewModel.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The MouseEventArgs containing the data from the event.</param>
        private void ChannelChart_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePosition = e.GetPosition(ChannelChart);
            (DataContext as TelemetryChannelViewModel).ParentTelemetryViewModel.MouseMove(mousePosition);
        }
    }
}