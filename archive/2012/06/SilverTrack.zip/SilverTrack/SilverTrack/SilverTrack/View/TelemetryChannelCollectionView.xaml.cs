/*
 * Copyright Scott Logic Limited 2011
 */

using System.Collections.Generic;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SilverTrack.Util;
using SilverTrack.ViewModel;

namespace SilverTrack.View
{
    public partial class TelemetryChannelCollectionView : UserControl, IDataContextChangedHandler<TelemetryChannelCollectionView>
    {
        private int rowIndex = 0;
        private int channelViewCount = 0;
        private List<TelemetryChannelViewModel> cache = new List<TelemetryChannelViewModel>();

        /// <summary>
        /// Constructor that attaches a DataContextChangedHelper to the view. This allows the View to update
        /// when a property from it's data context changes, and can redraw the view.
        /// </summary>
        public TelemetryChannelCollectionView()
        {
            InitializeComponent();
            DataContextChangedHelper<TelemetryChannelCollectionView>.Bind(this);
        }

        /// <summary>
        /// Updates the View by calculating whether a ChannelView has been added or removed.
        /// </summary>
        private void RebuildChannelViews()
        {
            TelemetryChannelCollectionViewModel viewModel = DataContext as TelemetryChannelCollectionViewModel;

            if (viewModel.ChannelViewModels.Count > channelViewCount)
            {
                List<TelemetryChannelViewModel> modelList = new List<TelemetryChannelViewModel>();
                modelList.Add(viewModel.ChannelViewModels[viewModel.ChannelViewModels.Count - 1]);
                AddChannelViews(viewModel, modelList);
            }
            else if (viewModel.ChannelViewModels.Count < channelViewCount)
            {
                LayoutRoot.Children.Clear();
                LayoutRoot.RowDefinitions.Clear();
                rowIndex = 0;

                List<TelemetryChannelViewModel> modelList = new List<TelemetryChannelViewModel>();
                foreach (TelemetryChannelViewModel model in viewModel.ChannelViewModels)
                {
                    modelList.Add(model);
                }

                AddChannelViews(viewModel, modelList);
            }
        }

        /// <summary>
        /// Recreates the LayoutRoot grid based on the current view model and the list of ChannelViewModels.
        /// </summary>
        /// <param name="viewModel">The current viewModel.</param>
        /// <param name="modelList">The TelemetryChannelViewModels that are to be displayed.</param>
        private void AddChannelViews(TelemetryChannelCollectionViewModel viewModel, List<TelemetryChannelViewModel> modelList)
        {
            foreach (TelemetryChannelViewModel channelViewModel in modelList)
            {
                if (rowIndex != 0)
                {
                    RowDefinition r = new RowDefinition();
                    r.Height = GridLength.Auto;
                    LayoutRoot.RowDefinitions.Add(r);

                    GridSplitter splitter = new GridSplitter();
                    splitter.HorizontalAlignment = HorizontalAlignment.Stretch;
                    splitter.Height = 8.0;
                    splitter.Width = 960.0;
                    splitter.Background = Resources["YellowBackgroundImageBrush"] as ImageBrush;
                    splitter.Background = new SolidColorBrush(Colors.Black);
                    splitter.ShowsPreview = true;

                    Grid.SetRow(splitter, rowIndex);
                    LayoutRoot.Children.Add(splitter);

                    rowIndex++;
                }

                //Add a chart.
                cache.Add(channelViewModel);

                RowDefinition chartRow = new RowDefinition();
                chartRow.SetValue(RowDefinition.MinHeightProperty, 75.0);
                LayoutRoot.RowDefinitions.Add(chartRow);

                TelemetryChannelView channelView = new TelemetryChannelView();
                channelView.DataContext = channelViewModel;

                Grid.SetRow(channelView, rowIndex);
                LayoutRoot.Children.Add(channelView);

                channelViewCount = viewModel.ChannelViewModels.Count;
                rowIndex++;
            }
        }

        /// <summary>
        /// Removes the row definition and the child of LayoutRoot at the given index.
        /// </summary>
        /// <param name="index">The index of the component to remove.</param>
        private void RemoveIndexFromGrid(int index)
        {
            LayoutRoot.RowDefinitions.RemoveAt(index);
            LayoutRoot.Children.RemoveAt(index);
        }

        /// <summary>
        /// Called when the ChannelViewModels collection in the ViewModel changes, and tells the View to
        /// rebuild the LayoutRoot to display the current TelemetryChannelViews
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The NotifyCollectionChangedEventArgs containing the event data.</param>
        private void ChannelViewModels_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            RebuildChannelViews();
        }

        /// <summary>
        /// Called whenever a property on the View's TelemetryChannelCollectionViewModel changes.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The DependencyPropertyChangedEventArgs containing the event data.</param>
        public void DataContextChanged(TelemetryChannelCollectionView sender, DependencyPropertyChangedEventArgs e)
        {
            //This if statement allows the TelemetryView designer to display correctly, as the DataContext is different in design mode.
            if (DataContext.GetType() == typeof(TelemetryChannelCollectionViewModel))
            { 
                TelemetryChannelCollectionViewModel viewModel = DataContext as TelemetryChannelCollectionViewModel;
                viewModel.ChannelViewModels.CollectionChanged += new NotifyCollectionChangedEventHandler(ChannelViewModels_CollectionChanged);
                RebuildChannelViews();
            }
        } 

    }
}