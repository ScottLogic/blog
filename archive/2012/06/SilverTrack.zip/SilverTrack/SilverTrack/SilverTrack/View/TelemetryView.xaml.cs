/*
 * Copyright Scott Logic Limited 2011
 */

using System.Windows;
using System.Windows.Controls;

namespace SilverTrack.View
{
    public partial class TelemetryView : UserControl
    {
        public TelemetryView()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hides and displays the widget panel at the bottom of the view.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The RoutedEventArgs containing the data from the event.</param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (WidgetBorder.Height == 0.0)
            {
                WidgetBorder.Height = 160.0;
            }
            else
            {
                WidgetBorder.Height = 0.0;
            }
        }

    }
}