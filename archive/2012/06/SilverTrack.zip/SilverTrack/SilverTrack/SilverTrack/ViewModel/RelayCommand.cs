/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Windows.Input;

namespace SilverTrack.ViewModel
{
    /// <summary>
    /// Relay Command executes some delegate. Based on Josh Smith's Relay Command from
    /// "WPF Apps With The Model-View-ViewModel Design Pattern"
    /// http://msdn.microsoft.com/en-us/magazine/dd419663.aspx#id0090030
    /// </summary>
    /// <typeparam name="T">The action the command is to execute.</typeparam>
    public class RelayCommand<T> : ICommand
    {
        private Action<T> _viewModelAction;

        /// <summary>
        /// Default Constructor. Creates new relay command with an action.
        /// </summary>
        /// <param name="viewModelAction"></param>
        public RelayCommand(Action<T> viewModelAction)
        {
            _viewModelAction = viewModelAction;
        }

        /// <summary>
        /// Returns whether the command can execute.
        /// </summary>
        public bool CanExecute(object parameter)
        {
            return true;
        }

        // Not used warning. Required by the ICommand interface, but CanExecute never changes in this class
        #pragma warning disable 0067    

        /// <summary>
        /// Called when can execute is modified or changes.
        /// </summary>
        public event EventHandler CanExecuteChanged;

        #pragma warning restore

        /// <summary>
        /// Executes the action.
        /// </summary>
        /// <param name="parameter">The Action to execute.</param>
        public void Execute(object parameter)
        {
            _viewModelAction((T)parameter);
        }
    }
}