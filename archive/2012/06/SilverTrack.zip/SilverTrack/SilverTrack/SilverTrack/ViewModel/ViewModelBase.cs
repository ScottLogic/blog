/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.ComponentModel;

namespace SilverTrack.ViewModel
{
    /// <summary>
    /// Base class for the View Models which includes setField to check new values are different,
    /// and OnPropertyChanged which causes updates throughout the application.
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        /// <summary>
        /// Called whenever a property is changed to update bindings.
        /// </summary>
        /// <param name="propertyName">The name of the property that has changed.</param>
        public void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Provides a method of checking whether the value supplied in the setter is different 
        /// from the current value. 
        /// </summary>
        /// <typeparam name="T">The Field/Value type.</typeparam>
        /// <param name="field">The field that has been set.</param>
        /// <param name="value">The new value.</param>
        /// <param name="propertyName">The name of the property for OnPropertyChanged.</param>
        /// <param name="onSet">Any validation/additional operations as an action.</param>
        protected void SetField<T>(ref T field, T value, string propertyName, Action onSet = null)
        {
            if (Object.Equals(field, value))
                return;

            if (onSet != null)
            {
                onSet();
            }

            field = value;

            OnPropertyChanged(propertyName);
        }

    }
}