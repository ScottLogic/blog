/*
 * Copyright Scott Logic Limited 2011
 */

using System.Collections.ObjectModel;

namespace SilverTrack.ViewModel
{
    /// <summary>
    /// Channel Collection View Model contains a ChannelCollection of channel view models.
    /// The class is used as the data context of the TelemetryChannelCollectionViewModel.xaml
    /// </summary>
    public class TelemetryChannelCollectionViewModel
    {
        private ChannelCollection _channelViewModels = new ChannelCollection();

        /// <summary>
        /// Channel View Models property contains a ChannelCollection of channelViewModels.
        /// </summary>
        public ChannelCollection ChannelViewModels
        {
            get { return _channelViewModels; }
        }

        /// <summary>
        /// Empty Constructor.
        /// </summary>
        public TelemetryChannelCollectionViewModel() { }
    }

    /// <summary>
    /// ChannelCollection is an ObservableCollection of type TelemetryChannelViewModel.
    /// </summary>
    public class ChannelCollection : ObservableCollection<TelemetryChannelViewModel> { }
}