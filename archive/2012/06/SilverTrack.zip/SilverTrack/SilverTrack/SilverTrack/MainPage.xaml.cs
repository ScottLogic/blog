/*
 * Copyright Scott Logic Limited 2011
 */

using System.Windows.Controls;
using SilverTrack.Telemetry;
using SilverTrack.ViewModel;

namespace SilverTrack
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            //Limits the frame rate to 20fps to lower CPU usage.
            App.Current.Host.Settings.MaxFrameRate = 20;

            //Create a TelemetryDataProvider, and create a new TelemetryViewModel based on this.
            TelemetryDataProvider provider = new TelemetryDataProvider("data.csv");
            TelemetryViewModel vm = new TelemetryViewModel(provider);

            //Set the DataContext to the TelemetryViewModel.
            DataContext = vm;

            //Add a default chart to the TelemetryViewModel.
            vm.AddChartCommand.Execute("");
        }
    }
}