/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Windows;
using System.Windows.Controls;
using Visiblox.Charts;

namespace SilverTrack.controls
{
    /// <summary>
    /// G-Force control displays a Visiblox chart with a single data point which represents the
    /// Lateral and Longitudinal G-Force being applied to the vehicle at a given moment in time.
    /// The template/layout of the control is defined in the Generic.xaml file. In this control,
    /// nothing is set using bindings, and the property changed events set the values of the data
    /// point manually.
    /// </summary>
    public partial class GForceControl : Control
    {
        #region Fields

        #region Constants

        private const String name = "GForceChart";

        #endregion

        #region Private Fields

        private Chart _gForceChart;
        private DataSeries<double, double> _gForceSeries;
        private DataPoint<double, double> gPoint;

        #endregion

        #endregion

        #region Properties

        #region Public properties

        /// <summary>
        /// Lateral G-Force
        /// </summary>
        public double Lateral
        {
            get { return (double)GetValue(LateralProperty); }
            set { SetValue(LateralProperty, value); }
        }

        /// <summary>
        /// Longitudinal G-Force
        /// </summary>
        public double Long
        {
            get { return (double)GetValue(LongProperty); }
            set { SetValue(LongProperty, value); }
        }

        #endregion

        #region Dependency Properties

        /// <summary>
        /// Lateral Dependency Property. Attached to the LateralPropertyChanged handler.
        /// </summary>
        public static readonly DependencyProperty LateralProperty =
            DependencyProperty.Register("Lateral", typeof(double), typeof(GForceControl),
                new PropertyMetadata(0.0, new PropertyChangedCallback(LateralPropertyChanged)));

        /// <summary>
        /// Long Dependency Property. Attached to the LongPropertyChanged handler.
        /// </summary>
        public static readonly DependencyProperty LongProperty =
            DependencyProperty.Register("Long", typeof(double), typeof(GForceControl),
                new PropertyMetadata(0.0, new PropertyChangedCallback(LongPropertyChanged)));

        #endregion

        #endregion

        #region Methods

        #region Constructors

        public GForceControl()
        {
            DefaultStyleKey = typeof(GForceControl);
        }

        #endregion

        #region Public

        /// <summary>
        /// When the template is applied, create a data point attached to a line series and add
        /// the line series to the chart.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _gForceChart = GetTemplateChild(name) as Chart;

            gPoint = new DataPoint<double, double>(0.0, 0.0);
            _gForceSeries = new DataSeries<double, double>();
            _gForceSeries.Add(gPoint);

            LineSeries GForceLineSeries = _gForceChart.Series[0] as LineSeries;
            GForceLineSeries.DataSeries = _gForceSeries;
            _gForceChart.Series.Add(GForceLineSeries);
        }

        #endregion

        #region Private/Internal

        /// <summary>
        /// Sets the gPoint's X Value to the Lateral Value, if gPoint is not null.
        /// </summary>
        private void OnLateralPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            if (gPoint != null)
                gPoint.X = Lateral;
        }

        private static void LateralPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            GForceControl control = d as GForceControl;
            control.OnLateralPropertyChanged(e);
        }

        /// <summary>
        /// Sets the gPoint's Y Value to the Long Value, if gPoint is not null.
        /// </summary>
        private void OnLongPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            if (gPoint != null)
                gPoint.Y = Long;
        }

        private static void LongPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            GForceControl control = d as GForceControl;
            control.OnLongPropertyChanged(e);
        }

        #endregion

        #endregion

    }
}