/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Windows.Data;
using System.Windows.Media;

/// <summary>
/// Colin Eberhardt's lookless radial gauge control. See:
/// http://www.codeproject.com/Articles/103035/Developing-a-very-Lookless-Silverlight-Radial-Gaug.aspx
/// </summary>
/// 
namespace SilverTrack.controls.gaugeControl
{
  public class ColorToBrushConverter : IValueConverter
  {

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      return new SolidColorBrush((Color)value);
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
