/*
 * Copyright Scott Logic Limited 2011
 */

using System.Windows;
using System.Windows.Controls;
using Microsoft.Expression.Controls;

namespace SilverTrack.controls
{
    /// <summary>
    /// Car location control displays a Path representing the circuit layout. A path list box is attached to
    /// the path, and its start value is bound to the position dependency property. The template/layout of the
    /// control is defined in the Generic.xaml file.
    /// </summary>
    public partial class CarLocationControl : Control
    {
        #region Fields

        private LayoutPath _layoutPath;

        #endregion

        #region Properties

        #region Public properties

        /// <summary>
        /// Property is bound to the Start property of the LayoutPath in the generic.xaml file.
        /// Represents the percentage of the lap the vehicle has currently completed.
        /// </summary>
        public double Position
        {
            get { return (double)GetValue(PositionProperty); }
            set { SetValue(PositionProperty, value); }
        }

        #endregion

        #region Dependency Properties

        /// <summary>
        /// Position Dependency Property. Attached to PositionPropertyChanged.
        /// </summary>
        public static readonly DependencyProperty PositionProperty = DependencyProperty.Register("Position", typeof(double), typeof(CarLocationControl),
                   new PropertyMetadata(0.5, new PropertyChangedCallback(PositionPropertyChanged)));

        #endregion

        #endregion

        #region Methods

        #region Constructors

        public CarLocationControl()
        {
            DefaultStyleKey = typeof(CarLocationControl);
        }

        #endregion

        #region Public

        /// <summary>
        /// Sets the local field _layoutPath to the PositionLayoutPath from the template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _layoutPath = GetTemplateChild("PositionLayoutPath") as LayoutPath;
        }

        #endregion

        #region Private/Internal

        /// <summary>
        /// Causes the CarLocationControl's _layoutPath.Start property to update.
        /// </summary>
        private static void PositionPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CarLocationControl control = d as CarLocationControl;
            control.updateLayoutPathStart();
        }

        private void updateLayoutPathStart()
        {
            if (_layoutPath != null)
                _layoutPath.Start = Position;
        }

        #endregion

        #endregion
    }
}