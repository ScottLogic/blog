/*
 * Copyright Scott Logic Limited 2011
 */

using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

/// <summary>
/// Colin Eberhardt's lookless radial gauge control. See:
/// http://www.codeproject.com/Articles/103035/Developing-a-very-Lookless-Silverlight-Radial-Gaug.aspx
/// </summary>
/// 
namespace SilverTrack.controls.gaugeControl
{
  public class RadialGaugeControlViewModel : FrameworkElement, INotifyPropertyChanged
  {
    #region Attach attached property

    public static readonly DependencyProperty AttachProperty =
        DependencyProperty.RegisterAttached("Attach", typeof(object), typeof(RadialGaugeControlViewModel),
            new PropertyMetadata(null, new PropertyChangedCallback(OnAttachChanged)));

    public static RadialGaugeControlViewModel GetAttach(DependencyObject d)
    {
      return (RadialGaugeControlViewModel)d.GetValue(AttachProperty);
    }

    public static void SetAttach(DependencyObject d, RadialGaugeControlViewModel value)
    {
      d.SetValue(AttachProperty, value);
    }

    /// <summary>
    /// Change handler for the Attach property
    /// </summary>
    private static void OnAttachChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      Grid targetElement = d as Grid;
      RadialGaugeControlViewModel viewModel = e.NewValue as RadialGaugeControlViewModel;
      viewModel.Grid = targetElement;



      // handle the loaded event
      targetElement.Loaded += new RoutedEventHandler(Grid_Loaded);

    }

    /// <summary>
    /// Handle the Loaded event of the Grid to enable the attached
    /// view model to bind to properties of the Grid Parent element
    /// </summary>
    static void Grid_Loaded(object sender, RoutedEventArgs e)
    {
      FrameworkElement targetElement = sender as FrameworkElement;
      FrameworkElement parent = targetElement.Parent as FrameworkElement;

      // use the attached view model as the DataContext of the element it is attached to
      RadialGaugeControlViewModel attachedModel = GetAttach(targetElement);
      targetElement.DataContext = attachedModel;

      // bind the DataContext of the view model to the DataContext of the parent.
      attachedModel.SetBinding(RadialGaugeControlViewModel.DataContextProperty,
        new Binding("DataContext")
        {
          Source = parent
        });

      // bind the piggyback to give DataContext change notification
      attachedModel.SetBinding(RadialGaugeControlViewModel.DataContextPiggyBackProperty,
        new Binding("DataContext")
         {
           Source = parent
         });
    }

    #endregion

    #region DataContextPiggyBack attached property

    /// <summary>
    /// DataContextPiggyBack Attached Dependency Property, used as a mechanism for exposing
    /// DataContext changed events
    /// </summary>
    public static readonly DependencyProperty DataContextPiggyBackProperty =
        DependencyProperty.RegisterAttached("DataContextPiggyBack", typeof(object), typeof(RadialGaugeControlViewModel),
            new PropertyMetadata(null, new PropertyChangedCallback(OnDataContextPiggyBackChanged)));

    public static object GetDataContextPiggyBack(DependencyObject d)
    {
      return (object)d.GetValue(DataContextPiggyBackProperty);
    }

    public static void SetDataContextPiggyBack(DependencyObject d, object value)
    {
      d.SetValue(DataContextPiggyBackProperty, value);
    }

    /// <summary>
    /// Handles changes to the DataContextPiggyBack property.
    /// </summary>
    private static void OnDataContextPiggyBackChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      RadialGaugeControlViewModel targetElement = d as RadialGaugeControlViewModel;
      targetElement.OnDataContextChanged();
    }

    private void OnDataContextChanged()
    {
      if (Gauge != null)
      {
        Gauge.PropertyChanged += new PropertyChangedEventHandler(Gauge_PropertyChanged);
      }
      OnPropertyChanged("");
    }

    /// <summary>
    /// Handle Gauge property changes
    /// </summary>
    private void Gauge_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "Value")
      {
        // ValueAngle depends on value
        OnPropertyChanged("ValueAngle");
      }
      else
      {
        // orther wise fire a generic property changed
        OnPropertyChanged("");
      }
    }


    #endregion

    public RadialGaugeControlViewModel()
    {
    }

    private GaugeControl Gauge
    {
      get { return DataContext != null ? (GaugeControl)DataContext : null; }
    }

    public double ValueAngle
    {
      get
      {
        if (Gauge == null)
          return 0.0;

        return ValueToAngle(Gauge.Value);
      }
    }

    private double ValueToAngle(double value)
    {
      double minAngle = -150;
      double maxAngle = 150;
      double angularRange = maxAngle - minAngle;

      return (value - Gauge.Minimum) / (Gauge.Maximum - Gauge.Minimum) *
         angularRange + minAngle;
    }

    public IEnumerable<Tick> MinorTicks
    {
      get
      {
        if (Gauge == null)
          yield break;

        double tickSpacing = (Gauge.Maximum - Gauge.Minimum) / 50;
        for (double tick = Gauge.Minimum; tick <= Gauge.Maximum; tick += tickSpacing)
        {
          yield return new Tick()
          {
            Angle = ValueToAngle(tick),
            Value = tick.ToString("N0"),
            Parent = this
          };
        }
      }
    }

    public IEnumerable<ArcDescriptor> Ranges
    {
      get
      {
        if (Gauge == null)
          yield break;

        for (int i = 0; i < Gauge.QualitativeRange.Count; i++)
        {
          var range = Gauge.QualitativeRange[i];
          if (i == 0)
          {
            yield return new ArcDescriptor()
            {
              Color = range.Color,
              StartAngle = ValueToAngle(Gauge.Minimum),
              EndAngle = ValueToAngle(range.Maximum)
            };
          }
          else
          {
            var previousRange = Gauge.QualitativeRange[i - 1];
            yield return new ArcDescriptor()
            {
              Color = range.Color,
              StartAngle = ValueToAngle(previousRange.Maximum),
              EndAngle = ValueToAngle(range.Maximum)
            };
          }
        }
      }
    }

    public IEnumerable<Tick> MajorTicks
    {
      get
      {
        if (Gauge == null)
          yield break;

        double tickSpacing = (Gauge.Maximum - Gauge.Minimum) / 10;
        for (double tick = Gauge.Minimum; tick <= Gauge.Maximum; tick += tickSpacing)
        {
          yield return new Tick()
          {
            Angle = ValueToAngle(tick),
            Value = tick.ToString("N0"),
            Parent = this
          };
        }
      }
    }


    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }

    private Grid _grid;

    public Grid Grid
    {
      get { return _grid; }
      set
      {
        _grid = value;
        _grid.SizeChanged += new SizeChangedEventHandler(Grid_SizeChanged);
      }
    }

    /// <summary>
    /// Handle SizeChanged events from the grid so that we can inform elements
    /// of changes in the ActualHeight / ActualWidth
    /// </summary>
    private void Grid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      OnPropertyChanged("GridHeight");
      OnPropertyChanged("GridWidth");

      Grid.Clip = new EllipseGeometry()
      {
        RadiusX = _grid.ActualWidth / 2,
        RadiusY = _grid.ActualHeight / 2,
        Center = new Point(_grid.ActualWidth / 2, _grid.ActualHeight / 2)
      };
    }

    public double GridWidth
    {
      get { return _grid.ActualWidth; }
    }

    public double GridHeight
    {
      get { return _grid.ActualHeight; }
    }
  }

  public class Tick
  {
    public double Angle { get; set; }
    public string Value { get; set; }
    public RadialGaugeControlViewModel Parent { get; set; }
  }

  public class ArcDescriptor
  {
    public double StartAngle { get; set; }
    public double EndAngle { get; set; }
    public Color Color { get; set; }
  }
}
