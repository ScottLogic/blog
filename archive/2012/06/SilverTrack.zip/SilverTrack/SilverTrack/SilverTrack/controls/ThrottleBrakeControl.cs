/*
 * Copyright Scott Logic Limited 2011
 */

using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace SilverTrack.controls
{
    /// <summary>
    /// Throttle Brake Control displays two rectangles, whose height represents the current throttle
    /// percentage, and the current brake pressure. The template/layout of the control is defined in
    /// Generic.xaml.
    /// </summary>
    public partial class ThrottleBrakeControl : Control
    {
        #region Fields

        private Rectangle _throttleRectange;
        private Rectangle _brakeRectange;

        private TextBlock _throttleLabel;
        private TextBlock _brakeLabel;

        private Border _throttleBorder;
        private Border _brakeBorder;

        #endregion

        #region Properties

        #region Public properties

        /// <summary>
        /// The Throttle Value
        /// </summary>
        public double Throttle
        {
            get { return (double)GetValue(ThrottleProperty); }
            set { SetValue(ThrottleProperty, value); }
        }

        /// <summary>
        /// The Brake Value
        /// </summary>
        public double Brake
        {
            get { return (double)GetValue(BrakeProperty); }
            set { SetValue(BrakeProperty, value); }
        }

        #endregion

        #region Dependency Properties

        /// <summary>
        /// Throttle Dependency Property. Attached to ThrottlePropertyChanged, default value 
        /// </summary>
        public static readonly DependencyProperty ThrottleProperty =
            DependencyProperty.Register("Throttle", typeof(double), typeof(ThrottleBrakeControl),
                new PropertyMetadata(0.0, new PropertyChangedCallback(ThrottlePropertyChanged)));

        /// <summary>
        /// Brake Dependency Property. Attached to BrakePropertyChanged, default value 0.0;
        /// </summary>
        public static readonly DependencyProperty BrakeProperty =
            DependencyProperty.Register("Brake", typeof(double), typeof(ThrottleBrakeControl),
                new PropertyMetadata(0.0, new PropertyChangedCallback(BrakePropertyChanged)));

        #endregion

        #endregion

        #region Methods

        #region Constructors

        public ThrottleBrakeControl()
        {
            DefaultStyleKey = typeof(ThrottleBrakeControl);
        }

        #endregion

        #region Public

        /// <summary>
        /// Sets _throttleRectangle to ThrottleRectangle and _brakeRectangle to BrakeRectange from 
        /// the template.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _throttleRectange = GetTemplateChild("ThrottleRectangle") as Rectangle;
            _throttleBorder = GetTemplateChild("ThrottleContainerBorder") as Border;

            _brakeRectange = GetTemplateChild("BrakeRectangle") as Rectangle;
            _brakeBorder = GetTemplateChild("BrakeContainerBorder") as Border;

            _brakeLabel = GetTemplateChild("BrakeLabel") as TextBlock;
            _throttleLabel = GetTemplateChild("ThrottleLabel") as TextBlock;
        }

        #endregion

        #region Private/Internal

        /// <summary>
        /// Causes the throttle rectangle height to update.
        /// </summary>
        private static void ThrottlePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ThrottleBrakeControl control = d as ThrottleBrakeControl;
            control.OnThrottlePropertyChanged(e);
        }

        private void OnThrottlePropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            _throttleLabel.Text = Throttle.ToString("0.0");
            _throttleRectange.Height = (_throttleBorder.ActualHeight / 100) * Throttle;
        }

        /// <summary>
        /// Causes the brake rectangle height to update.
        /// </summary>
        private static void BrakePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ThrottleBrakeControl control = d as ThrottleBrakeControl;
            control.OnBrakePropertyChanged(e);
        }
        private void OnBrakePropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            _brakeLabel.Text = Brake.ToString("0.0");
            _brakeRectange.Height = (_brakeBorder.ActualHeight / 100) * Brake;
        }

        #endregion

        #endregion
    }
}