/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Windows.Data;
using System.Globalization;

/// <summary>
/// Colin Eberhardt's lookless radial gauge control. See:
/// http://www.codeproject.com/Articles/103035/Developing-a-very-Lookless-Silverlight-Radial-Gaug.aspx
/// </summary>

namespace SilverTrack.controls.gaugeControl
{
    public class ScaleFactorConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null)
                return null;

            double dblValue = (double)value;
            double factor = double.Parse((string)parameter, new CultureInfo("en-US"));
            return dblValue * factor;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}