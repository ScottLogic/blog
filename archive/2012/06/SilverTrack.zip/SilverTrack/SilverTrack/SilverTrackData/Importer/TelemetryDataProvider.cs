/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using TelemetryData.Telemetry;

namespace SilverTrack.Telemetry
{
    /// <summary>
    /// Implements the ITelemetryDataProvider Interface. Creates and populates a Series Dictionary and contains public methods 
    /// to read new files, find extreme values, and get the data from a channel. Also has list of channels as a property.
    /// </summary>
    public class TelemetryDataProvider : ITelemetryDataProvider
    {
        #region Fields

        private TelemetrySeriesDictionaryPopulator _populator;
        private List<TelemetrySeries> _allSeries = new List<TelemetrySeries>();

        #endregion

        #region Properties

        /// <summary>
        /// List containing all TelemetrySeries. 
        /// </summary>
        public List<TelemetrySeries> AllSeries
        {
            get { return _allSeries; }
        }

        /// <summary>
        /// String values of the available channels/series data that can be plotted onto a chart.
        /// </summary>
        public List<string> SeriesList
        {
            get { return _allSeries.Select(series => series.Name).ToList(); }
        }

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Constructor which populates the series dictionary with series names and the index of this column in the .csv file.
        /// </summary>
        /// <param name="defaultFileLocation">The location of the default .csv file in the project.</param>
        public TelemetryDataProvider(string defaultFileLocation)
        {
            _allSeries.Add(new TelemetrySeries("NONE", -1));
            _allSeries.Add(new TelemetrySeries("RPM", 60));
            _allSeries.Add(new TelemetrySeries("BRAKE", 23));
            _allSeries.Add(new TelemetrySeries("SPEED", 52));
            _allSeries.Add(new TelemetrySeries("GEAR", 37));
            _allSeries.Add(new TelemetrySeries("THROTTLE", 50));
            _allSeries.Add(new TelemetrySeries("STEERED ANGLE", 85));
            _allSeries.Add(new TelemetrySeries("OVERSTEER", 2));
            _allSeries.Add(new TelemetrySeries("DISTANCE", 1));
            _allSeries.Add(new TelemetrySeries("GLAT", 62));
            _allSeries.Add(new TelemetrySeries("GLONG", 65));

            ReadFile(new StreamReader(Application.GetResourceStream(new Uri(defaultFileLocation, UriKind.RelativeOrAbsolute)).Stream));
        }
        
        #endregion

        #region Public

        /// <summary>
        /// Populates the _allSeries list.
        /// </summary>
        /// <param name="streamReader">StreamReader containing location of the .csv file.</param>
        public void ReadFile(StreamReader streamReader) 
        { 
            _populator = new TelemetrySeriesDictionaryPopulator(streamReader, _allSeries); 
        }

        /// <summary>
        /// Retrieves the Telemetry Series from the series dictionary when given a key value.
        /// </summary>
        /// <param name="channel">The Key Value of the series the caller wishes to obtain.</param>
        /// <returns>The Telemetry Series object from the key value specified.</returns>
        public TelemetrySeries FindSeriesFromName(string nameToFind) 
        {
            return _allSeries.Single(series => series.Name == nameToFind);
        }

        #endregion

        #endregion
    }
}