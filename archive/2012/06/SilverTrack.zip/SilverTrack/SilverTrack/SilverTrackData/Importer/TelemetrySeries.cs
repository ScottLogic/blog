/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Collections.Generic;

namespace TelemetryData.Telemetry
{
    /// <summary>
    /// Represents a series of TimestampedDataPoints along with a Name and the Index of the
    /// column the series is in the .csv file.
    /// </summary>
    public class TelemetrySeries
    {
        #region Fields

        private double _maximumValue;
        private double _minimumValue;

        #endregion

        #region Properties

        /// <summary>
        /// The Name of the Series.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The column index of the series in the csv file.
        /// </summary>
        public int IndexInCSV { get; set; }

        /// <summary>
        /// The List of TimestampedDataPoints that the series contains.
        /// </summary>
        public List<TimestampedDataPoint> DataList { get; set; }

        /// <summary>
        /// Returns the Maximum Value in the DataList.
        /// </summary>
        public double Maximum
        {
            get
            {
                FindExtremeValues();
                return _maximumValue;
            }
        }

        /// <summary>
        /// Returns the Minimum Value in the DataList.
        /// </summary>
        public double Minimum
        {
            get
            {
                FindExtremeValues();
                return _minimumValue;
            }
        }

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Creates a TelemetrySeries when given a name and IndexInCSV value.
        /// </summary>
        /// <param name="name">The name of the series.</param>
        /// <param name="indexInCSV">The index of the series in the .csv file.</param>
        public TelemetrySeries(string name, int indexInCSV)
        {
            Name = name;
            IndexInCSV = indexInCSV;
            DataList = new List<TimestampedDataPoint>();
        }

        #endregion

        /// <summary>
        /// Finds the maximum and the minimum values in the DataList.
        /// </summary>
        private void FindExtremeValues()
        {
            _maximumValue = 0;
            _minimumValue = 0;
            foreach (TimestampedDataPoint point in DataList)
            {
                if (point.Value > _maximumValue)
                    _maximumValue = point.Value;
                if (point.Value < _minimumValue)
                    _minimumValue = point.Value;
            }
        }

        #endregion
    }

    /// <summary>
    /// Represents a point in time and a value for a series.
    /// </summary>
    public class TimestampedDataPoint
    {
        #region Properties

        /// <summary>
        /// The time of the Data Point
        /// </summary>
        public DateTime Time { get; set; }

        /// <summary>
        /// The value of the Data Point
        /// </summary>
        public double Value { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a TimestampedDataPoint with a time and value.
        /// </summary>
        /// <param name="time">The time of the Data Point.</param>
        /// <param name="v">The value of the Data Point.</param>
        public TimestampedDataPoint(DateTime time, double v)
        {
            Time = time;
            Value = v;
        }

        #endregion
    }
}