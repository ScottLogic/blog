/*
 * Copyright Scott Logic Limited 2011
 */

using System.Collections.Generic;
using System.IO;
using TelemetryData.Telemetry;

namespace SilverTrack.Telemetry
{
    /// <summary>
    /// Interface for Telemetry Data Provider, which should populate a dictionary with names as 
    /// keys, and TelemetrySeries as values, and also return a List of the channels available.
    /// </summary>
    public interface ITelemetryDataProvider
    {
        /// <summary>
        /// The List containing all of the Telemetry Series contained in the Data Provider.
        /// </summary>
        List<string> SeriesList { get; }

        /// <summary>
        /// Retrieves a Telemetry Series when given the series name.
        /// </summary>
        /// <param name="channel">The name of the series.</param>
        /// <returns>The series with the specified name.</returns>
        TelemetrySeries FindSeriesFromName(string channel);

        /// <summary>
        /// Parses a MoTeC .csv file into the Data Provider.
        /// </summary>
        /// <param name="sr">A stream reader pointing to a MoTeC .csv file.</param>
        void ReadFile(StreamReader sr);
    }
}