﻿/*
 * Copyright Scott Logic Limited 2011
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Globalization;

namespace TelemetryData.Telemetry
{
    /// <summary>
    /// Populates a series dictionary with TimestampedDataPoints from a .csv file read by a StreamReader.
    /// </summary>
    public class TelemetrySeriesDictionaryPopulator
    {
        #region Methods

        #region Constructors

        /// <summary>
        /// Creates a populator which will parse the .csv file given and fill the series dictionary with the values.
        /// </summary>
        /// <param name="sr">StreamReader which contains a MoTeC .csv file.</param>
        /// <param name="seriesDictionary">Reference to the series dictionary which is to be populated.</param>
        public TelemetrySeriesDictionaryPopulator(StreamReader sr, List<TelemetrySeries> allSeries)
        {
            try
            {
                using (sr)
                {
                    string line;
                    bool begun = false;
                    int blankLineCounter = 0;
                    int lineIndex = 0;

                    //While the next line is not null, parse the data.
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (begun)
                        {
                            FillFromCSV(line, allSeries);
                        }
                        //If the line is blank or contains no values, then increment the line counter. Once this reaches 4, the csv 
                        ///values we are interested in are on the next line.
                        if (line.Equals(",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,") ^ line.Equals(""))
                        {
                            blankLineCounter++;
                        }
                        if (blankLineCounter > 3)
                        {
                            begun = true;
                        }
                    }
                    lineIndex++;
                }
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.Message);
            }
        }

        /// <summary>
        /// Takes a single line from a CSV file and adds a new TimestampedDataPoint to every entry in the series dictionary based on this line.
        /// </summary>
        /// <param name="line">A line from a CSV file.</param>
        public static void FillFromCSV(string line, List<TelemetrySeries> allSeries)
        {
            //Splits the CSV line into parts. \" must be used as the values are surrounded by " and \" strings.
            string[] parts = Regex.Split(line, "\",\"");

            //Create a new time based on the seconds, and milliseconds of the line.
            string[] timeFromParts = parts[0].Substring(1).Split('.');
            int seconds = Int32.Parse(timeFromParts[0]);
            int milliseconds = Int32.Parse(timeFromParts[1]);
            int minutes = 0;
            if (seconds > 59)
            {
                minutes = seconds / 60;
                seconds = seconds - (minutes * 60);
            }
            DateTime _time = new DateTime(1, 1, 1, 0, minutes, seconds, milliseconds);

            foreach (TelemetrySeries series in allSeries)
            {
                if (series.IndexInCSV > 0)
                {
                    series.DataList.Add(new TimestampedDataPoint(_time, Double.Parse(parts[series.IndexInCSV], new CultureInfo("en-US"))));
                }
                else
                {
                    //If the series is "NONE"
                    series.DataList.Add(new TimestampedDataPoint(_time, 0.0));
                }
            }
        }

        #endregion

        #endregion
    }
}