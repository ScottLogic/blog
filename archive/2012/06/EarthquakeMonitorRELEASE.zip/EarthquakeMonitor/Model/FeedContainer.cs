using System.Collections.Generic;

namespace EarthquakeMonitor.Model
{
    /// <summary>
    /// Contains a List of Feeds for a certain category.
    /// </summary>
    public class FeedCategory
    {
        public string Title { get; set; }
        public List<Feed> Feeds { get; set; }
    }

    /// <summary>
    /// Contains a URL and Title of a Feed.
    /// </summary>
    public class Feed
    {
        public string URL { get; set; }
        public string Title { get; set; }
    }
}