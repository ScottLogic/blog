using System.Collections.Generic;

namespace EarthquakeMonitor.Model
{
    public class FeedCategory
    {
        public string Title { get; set; }
        public List<Feed> Feeds { get; set; }
    }
}