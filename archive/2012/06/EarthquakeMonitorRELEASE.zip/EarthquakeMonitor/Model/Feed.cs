namespace EarthquakeMonitor.Model
{
    public class Feed
    {
        public string URL { get; set; }
        public string Title { get; set; }
    }
}