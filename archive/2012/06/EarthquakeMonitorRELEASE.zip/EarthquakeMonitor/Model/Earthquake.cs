using System;
using System.ComponentModel;

namespace EarthquakeMonitor.Model
{
    public class Earthquake : INotifyPropertyChanged
    {
        public static readonly string DisplayedProperty = "Displayed";

        /// <summary>
        /// The ID of the earthquake
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The Title of the earthquake
        /// </summary>
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        private string _title;

        /// <summary>
        /// The DateTime of the earthquake
        /// </summary>
        public DateTime Updated { get; set; }

        /// <summary>
        /// A Summary of the earthquake
        /// </summary>
        public string Summary { get; set; }

        /// <summary>
        /// The Latitude of the loc of the earthquake
        /// </summary>
        public double Lat { get; set; }

        /// <summary>
        /// The Longitude of the loc of the earthquake
        /// </summary>
        public double Long { get; set; }

        /// <summary>
        /// The Magnitude of the earthquake
        /// </summary>
        public double Magnitude { get; set; }

        /// <summary>
        /// The Depth where the earthquake occurred 
        /// </summary>
        public double Depth { get; set; }

        /// <summary>
        /// The Link to the USGS page about the earthquake
        /// </summary>
        public string Link { get; set; }

        /// <summary>
        /// If the earthquake is historical or if it is recent (for the data grid grouping)
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Metadata. Index of the earthquake in the list.
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// If the earthquake 'display' has been selected in the data grid
        /// </summary>
        private bool _displayed;
        public bool Displayed
        {
            get
            {
                return _displayed;
            }
            set
            {
                if ( _displayed != value)
                {
                    _displayed = value;
                    NotifyPropertyChanged(DisplayedProperty);
                }
            }
        }

        /// <summary>
        /// If the earthquake has its compare box selected
        /// </summary>
        public bool Compare { get; set; }

        /// <summary>
        /// Default Constructor.
        /// </summary>
        public Earthquake()
        {
            Displayed = true;
        }

        public delegate void SelectedStateChanged(Earthquake quake, Boolean selected);

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
    }
}