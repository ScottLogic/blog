using System;
using Microsoft.Maps.MapControl;

namespace EarthquakeMonitor.View
{
    public enum DistanceMeasure
    {
        Miles,
        Kilometers
    }

    /// <summary>
    /// Code adapted from:
    /// http://pietschsoft.com/post/2010/06/28/Silverlight-Bing-Maps-Draw-Circle-Around-Latitude-Longitude-Location.aspx
    /// </summary>
    public class GeoCodeCalc
    {
        public const double EarthRadiusInMiles = 3956.0;
        public const double EarthRadiusInKilometers = 6367.0;

        public static double ToRadian(double degrees)
        {
            return degrees * (Math.PI / 180);
        }

        public static double ToDegrees(double radians)
        {
            return radians * (180 / Math.PI);
        }

        public static LocationCollection CreateCircle(Location center, double radius, DistanceMeasure units, int resoultion)
        {
            var earthRadius = (units == DistanceMeasure.Miles ? GeoCodeCalc.EarthRadiusInMiles : GeoCodeCalc.EarthRadiusInKilometers);
            var lat = ToRadian(center.Latitude); // Radians
            var lng = ToRadian(center.Longitude); // Radians
            var d = radius / earthRadius; // d = angular distance covered on earth's surface
            d = d * Math.Cos(lat); // this stops circles increasing in size as they move away from the equator
            var locations = new LocationCollection();

            for (var x = 0; x <= 360; x++)
            {
                // This is added to improve performance by not drawing so many points in the circle.
                if (x % resoultion == 0)
                {
                    var brng = ToRadian(x);
                    var latRadians = Math.Asin(Math.Sin(lat) * Math.Cos(d) + Math.Cos(lat) * Math.Sin(d) * Math.Cos(brng));
                    var lngRadians = lng + Math.Atan2(Math.Sin(brng) * Math.Sin(d) * Math.Cos(lat), Math.Cos(d) - Math.Sin(lat) * Math.Sin(latRadians));

                    locations.Add(new Location(ToDegrees(latRadians), ToDegrees(lngRadians)));
                }
            }
            return locations;
        }
    }
}