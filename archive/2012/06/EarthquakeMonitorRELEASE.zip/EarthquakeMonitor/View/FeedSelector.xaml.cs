using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using EarthquakeMonitor.Model;
using EarthquakeMonitor.ViewModel;

namespace EarthquakeMonitor.View
{
    public partial class FeedSelector : ChildWindow
    {
        private FeedSelectorViewModel _feedViewModel;
        public Feed SelectedFeed { get; set; }

        public FeedSelector(MonitorViewModel monitorViewModel)
        {
            InitializeComponent(); 

            _feedViewModel = new FeedSelectorViewModel(monitorViewModel);
            _feedViewModel.PropertyChanged += ViewModelPropertyChanged;
            _feedViewModel.FeedLoadedEvent += feedViewModel_FeedLoadedEvent;
            this.DataContext = _feedViewModel;

            DisplayCategories();
        }

        private void ViewModelPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == FeedSelectorViewModel.CategoriesProperty)
            {
                DisplayCategories();
            }
        }

        // Display the categories and their contents on the selector.
        private void DisplayCategories()
        {
            int i = 0;

            foreach (FeedCategory category in _feedViewModel.Categories)
            {
                RowDefinition r = new RowDefinition();
                r.Height = new GridLength(45);
                FeedRows.RowDefinitions.Add(r);

                TextBlock categoryTextBlock = new TextBlock() 
                { 
                    Text = category.Title, FontSize = 22, 
                    VerticalAlignment = VerticalAlignment.Bottom, 
                    FontFamily = new FontFamily("Segoe UI") 
                };
                categoryTextBlock.SetValue(Grid.RowProperty, i);
                categoryTextBlock.SetValue(Grid.ColumnProperty, 0);
                FeedRows.Children.Add(categoryTextBlock);

                i++;
                foreach (Feed feed in category.Feeds)
                {
                    RowDefinition feedRow = new RowDefinition();
                    feedRow.Height = new GridLength(25);
                    FeedRows.RowDefinitions.Add(feedRow);

                    TextBlock feedNameTextBlock = new TextBlock() { Text = feed.Title, FontSize = 14, FontFamily = new FontFamily("Segoe UI") };
                    feedNameTextBlock.SetValue(Grid.RowProperty, i);
                    feedNameTextBlock.SetValue(Grid.ColumnProperty, 0);
                    FeedRows.Children.Add(feedNameTextBlock);

                    StackPanel buttonContent = new StackPanel() { Orientation = Orientation.Horizontal };
                    var uriSource = new Uri("EarthquakeMonitor;Images/showfeed_icon.png", UriKind.Relative);
                    buttonContent.Children.Add(new Image() { Source = new BitmapImage(uriSource), Width = 16, Height = 16 });
                    buttonContent.Children.Add(new TextBlock() { Text = "Show Quakes" });

                    Button addButton = new Button() { Content = buttonContent };
                    addButton.SetValue(Grid.RowProperty, i);
                    addButton.SetValue(Grid.ColumnProperty, 2);
                    addButton.Tag = feed;
                    addButton.Click += new RoutedEventHandler(addButton_Click);
                    FeedRows.Children.Add(addButton);

                    i++;
                }
            }
        }

        /// <summary>
        /// Event Handler for when an add button is clicked. Call the ViewModel's LoadFeed method for the selected feed
        /// </summary>
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Feed f = ((sender as Button).Tag as Feed);
            if(f != null)
                _feedViewModel.LoadFeed(f);
        }

        private void feedViewModel_FeedLoadedEvent(object sender, System.EventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}