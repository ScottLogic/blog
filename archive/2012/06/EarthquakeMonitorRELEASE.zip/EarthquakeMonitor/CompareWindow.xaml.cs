using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using EarthquakeMonitor.Model;
using EarthquakeMonitor.View;
using Microsoft.Maps.MapControl;
using Visiblox.Charts;

namespace EarthquakeMonitor
{
    /// <summary>
    /// A ChildWindow that displays up to four earthquakes alongside each other so that they can be compared.
    /// Creates a UI in code behind based on the _compareList entries.
    /// </summary>
    public partial class CompareWindow : ChildWindow
    {
        private List<Earthquake> _compareList;

        public CompareWindow(List<Earthquake> compareList)
        {
            InitializeComponent();
            _compareList = compareList;
            Title = "Earthquake Comparison";

            // Work out the max values for the charts.
            double maxMag = 0.0;
            double maxDepth = 0.0;
            foreach (Earthquake q in _compareList)
            {
                maxMag = Math.Max(maxMag, q.Magnitude);
                maxDepth = Math.Max(maxDepth, q.Depth);
            }

            ComparisonChart.Series[0].YAxis = MainAxis;
            ComparisonChart.Series[1].YAxis = SecondaryAxis;

            foreach (ColumnSeries series in ComparisonChart.Series) 
            {
                BindableDataSeries dataSeries = (BindableDataSeries)series.DataSeries;
                dataSeries.ItemsSource = compareList;
            }

            int i = 0;
            int width = (int) Math.Round(Maps.ActualWidth / _compareList.Count);
            Thickness borderThickness = new Thickness(1, 0, 0, 0);

            // Add some UI for each Earthquake in the _compareList
            foreach (Earthquake q in _compareList)
            {
                // Add a border for this earthquake, set its column and surround it in a border.
                Border border = new Border()
                {
                    BorderBrush = new SolidColorBrush(Colors.Gray),
                    Width = double.NaN,
                    Height = double.NaN,
                };
                Maps.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                border.SetValue(Grid.ColumnProperty, i);
                if (i > 0) border.BorderThickness = borderThickness;
                Maps.Children.Add(border);

                // Create a new small map to show the Earthquake.
                Map m = new Map();
                m.Width = double.NaN;
                m.Height = double.NaN;
                m.CredentialsProvider = new ApplicationIdCredentialsProvider("AiNdhflvsXsNpEt_wJg-nFRdj_veGxqpKUOvKo3MoBRmS91Orr8FCA94goq7Z6N-");
                m.NavigationVisibility = Visibility.Collapsed;
                m.LogoVisibility = Visibility.Collapsed;
                m.CopyrightVisibility = Visibility.Collapsed;
                m.ScaleVisibility = Visibility.Collapsed;
                m.Center = new Location(q.Lat, q.Long);
                m.ZoomLevel = 5;
                border.Child = m;

                SolidColorBrush fillColour = new SolidColorBrush(Colors.Red) { Opacity = 0.5 };
                SolidColorBrush stroke = new SolidColorBrush(Colors.White);
                DrawCircleOnComparisonMap(m, q, fillColour, stroke);

                i++;
            }
        }

        /// <summary>
        /// Draws a circle on the comparison map with the given parameters.
        /// </summary>
        /// <param name="loc">The loc of the circle</param>
        /// <param name="radius">The radius of the circle</param>
        /// <param name="color">The colour of the circle</param>
        private void DrawCircleOnComparisonMap(Map m, Earthquake quake, SolidColorBrush fillColour, SolidColorBrush stroke)
        {
            Location loc = new Location(quake.Lat, quake.Long);
            double radius = quake.Magnitude * 50;

            // Add the circle to the Map
            MapPolyline poly = new MapPolyline();
            poly.Locations = GeoCodeCalc.CreateCircle(loc, radius, DistanceMeasure.Miles, 8);
            poly.Stroke = stroke;
            poly.Fill = fillColour;
            poly.StrokeThickness = 2;
            m.Children.Add(poly);
        }
    }
}