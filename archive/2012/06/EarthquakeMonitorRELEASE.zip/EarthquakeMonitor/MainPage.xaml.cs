using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using EarthquakeMonitor.Model;
using EarthquakeMonitor.View;
using EarthquakeMonitor.ViewModel;
using Microsoft.Maps.MapControl;
using Visiblox.Charts;

namespace EarthquakeMonitor
{
    /// <summary>
    /// Code Behind for the Main View of the Earthquake Application. Contains operations to bind to the ViewModel and display, 
    /// draw to and alter the display of the maps.
    /// </summary>
    public partial class MainPage : UserControl
    {
        #region HighlightedDataPoint Dependency Property

        public static readonly DependencyProperty HighlightedDataPointProperty =
            DependencyProperty.Register("HighlightedDataPoint", typeof(BindableDataPoint), typeof(MainPage), new PropertyMetadata(null, TrackBallMoved));

        public BindableDataPoint HighlightedDataPoint
        {
            get { return (BindableDataPoint)GetValue(HighlightedDataPointProperty); }
            set { SetValue(HighlightedDataPointProperty, value); }
        }

        private static void TrackBallMoved(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var mainPage = d as MainPage;
            if (mainPage.HighlightedDataPoint == null)
                return;
            if (mainPage.MainTab.IsSelected)
            {
                mainPage.QuakeHovered(mainPage.EarthquakeLocationMap, mainPage.HighlightedDataPoint.DataContext as Earthquake);
            }
            else if (mainPage.AnalysisTab.IsSelected)
            {
                mainPage.QuakeHovered(mainPage.CompareMap, mainPage.HighlightedDataPoint.DataContext as Earthquake);
            }
        }

        #endregion

        #region Fields

        private MonitorViewModel _viewModel;
        private MapPolyline _highlightedCircle = null;

        // Brush Colours
        private static SolidColorBrush fillBrush = new SolidColorBrush(Colors.Red) { Opacity = 0.5 };
        private static SolidColorBrush strokeBrush = new SolidColorBrush(Colors.White);
        private static SolidColorBrush hoveredStrokeBrush = new SolidColorBrush(Colors.Black);
        private static SolidColorBrush hoveredFillBrush = new SolidColorBrush(Colors.Red) { Opacity = 0.5 };

        #endregion

        /// <summary>
        /// Constructor that sets defaults and sets up bindings.
        /// </summary>
        public MainPage()
        {
            InitializeComponent();

            _viewModel = new MonitorViewModel(this);
            this.DataContext = _viewModel;

            // Register for property changed events so we know when to update the view.
            _viewModel.PropertyChanged += ViewModelPropertyChanged;
        }

        #region Map Operations

        /// <summary>
        /// Draws a circle on the map with the given parameters.
        /// Adapted code from:
        /// http://pietschsoft.com/post/2010/06/28/Silverlight-Bing-Maps-Draw-Circle-Around-Latitude-Longitude-Location.aspx
        /// </summary>
        /// <param name="map">The map to draw on</param>
        /// <param name="loc">The loc of the circle</param>
        /// <param name="radius">The radius of the circle</param>
        /// <param name="color">The colour of the circle</param>
        /// <param name="quake">The earthquake to draw</param>
        private void DrawCircleOnMap(Map map, Earthquake quake, Visibility visibility)
        {
            Location loc = new Location(quake.Lat, quake.Long);
            double radius = quake.Magnitude * 50;

            // Creates a poly of a circle using the GeoCodeCalc and the loc and radius
            LocationCollection locations = GeoCodeCalc.CreateCircle(loc, radius, DistanceMeasure.Miles, 8);

            // Make a tooltip
            StackPanel toolTip = new StackPanel();
            TextBlock title = new TextBlock();
            title.FontWeight = FontWeights.Bold;
            title.Text = quake.Title;
            TextBlock text = new TextBlock();
            text.Text = "Magnitude: " + quake.Magnitude + ", Depth: " + quake.Depth;
            toolTip.Children.Add(title);
            toolTip.Children.Add(text);

            // Add the circle to the Map
            MapPolyline poly = new MapPolyline();
            ToolTipService.SetToolTip(poly, toolTip);
            poly.Locations = locations;
            poly.Visibility = visibility;
            poly.Tag = quake;
            poly.MouseLeftButtonUp += new MouseButtonEventHandler(Poly_MouseLeftButtonUp);
            UseDefaultStyle(poly);
            map.Children.Add(poly);
        }

        /// <summary>
        /// An earthquake circle on the map has mouse over.
        /// </summary>
        private void QuakeHovered(Map map, Earthquake quake)
        {
            MapPolyline circle = null;
            foreach (MapPolyline currentCircle in map.Children)
            {
                if (currentCircle.Tag.Equals(quake))
                    circle = currentCircle;
            }

            if (_highlightedCircle != null)
                UseDefaultStyle(_highlightedCircle);

            if (circle == null)
                return;

            _highlightedCircle = circle;
            UseHoveredStyle(circle);
        }

        /// <summary>
        /// Sets a default style on the given MapPolyline
        /// </summary>
        private void UseDefaultStyle(MapPolyline poly)
        {
            poly.Stroke = strokeBrush;
            poly.Fill = fillBrush;
            poly.StrokeThickness = 2;
        }

        /// <summary>
        /// Sets a hovered style on the given MapPolyline
        /// </summary>
        private void UseHoveredStyle(MapPolyline poly)
        {
            poly.Stroke = hoveredStrokeBrush;
            poly.Fill = hoveredFillBrush;
            poly.StrokeThickness = 2;
        }

        /// <summary>
        /// Sets the clicked earthquake to be the selected quake.
        /// </summary>
        private void Poly_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            MapPolyline s = sender as MapPolyline;
            Earthquake q = s.Tag as Earthquake;
            _viewModel.SelectedQuake = q;
        }

        /// <summary>
        /// Clears the map of it's child objects (Polygons in this case).
        /// </summary>
        public void ClearMaps()
        {
            EarthquakeLocationMap.Children.Clear();
            CompareMap.Children.Clear();
        }

        /// <summary>
        /// Draws a Circle from an Earthquake on the Analysis and Main maps.
        /// </summary>
        /// <param name="q">The earthquake to draw.</param>
        public void DrawCircleOnMapsFromEarthQuake(Earthquake q)
        {
            Visibility visibility = q.Displayed ? Visibility.Visible : Visibility.Collapsed;
            DrawCircleOnMap(EarthquakeLocationMap, q, visibility);
            DrawCircleOnMap(CompareMap, q, visibility);
        }

        /// <summary>
        /// Moves the focus of the map to the loc and zoom level specified.
        /// </summary>
        /// <param name="loc">The loc to move to.</param>
        /// <param name="zoomLevel">The zoom level to apply at the loc.</param>
        private void MoveMapToLocation(Location loc, double zoomLevel)
        {
            if (EarthquakeLocationMap.ZoomLevel > 4)
                zoomLevel = EarthquakeLocationMap.ZoomLevel;

            // Only move visible map for performance reasons.
            if (MainTab.IsSelected)
            {
                EarthquakeLocationMap.SetView(loc, zoomLevel);
            }
            else if (AnalysisTab.IsSelected)
            {
                CompareMap.SetView(loc, zoomLevel);
            }
        }

        #endregion

        #region Button Clicks

        /// <summary>
        /// Toggles full screen for the application.
        /// </summary>
        /// <param name="sender">The object that generated this event</param>
        /// <param name="e">The RoutedEventArgs generated by this event</param>
        private void Application_Fullscreen(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Host.Content.IsFullScreen)
            {
                Fullscreen_Button_TextBlock.Text = "Full Screen";
                Application.Current.Host.Content.IsFullScreen = false;
            }
            else
            {
                Fullscreen_Button_TextBlock.Text = "Exit Full Screen";
                Application.Current.Host.Content.IsFullScreen = true;
            }
        }

        private void RefreshData_Button_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.Refresh();
        }

        private void SelectFeed_Button_Click(object sender, RoutedEventArgs e)
        {
            FeedSelector f = new FeedSelector(_viewModel);
            f.Show();
        }
        
        private void CompareButtonClick(object sender, RoutedEventArgs e)
        {
            List<Earthquake> compareList = new List<Earthquake>();
            foreach (Earthquake quake in _viewModel.QuakeList)
            {
                if (quake.Compare)
                    compareList.Add(quake);
            }
            if (compareList.Count > 4)
            {
                MessageBox.Show("Please select a maximum of four earthquakes to compare.");
            }
            else if (compareList.Count < 1)
            {
                MessageBox.Show("Please select at least one earthquake to compare.");
            }
            else
            {
                CompareWindow cw = new CompareWindow(compareList);
                cw.Show();
            }
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// Responds to PropertyChanged events in the ViewModel. Takes action based on the PropertyName.
        /// </summary>
        private void ViewModelPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == MonitorViewModel.SelectedQuakeProperty)
            {
                if (_viewModel.SelectedQuake == null)
                    return;

                Location loc = new Location(_viewModel.SelectedQuake.Lat, _viewModel.SelectedQuake.Long);
                MoveMapToLocation(loc, 3);
            }
            else if (e.PropertyName == MonitorViewModel.QuakeListProperty)
            {
                // If the quake list changes, clear the maps and redraw the quakes.
                ClearMaps();
                foreach (Earthquake q in _viewModel.QuakeList)
                {
                    DrawCircleOnMapsFromEarthQuake(q);
                    q.PropertyChanged += new PropertyChangedEventHandler(QuakePropertyChanged);
                }

                // Recalculate the trends.
                CalculateTrends();
            }
        }

        /// <summary>
        /// Responds to Property Changed events on earthquakes.
        /// </summary>
        private void QuakePropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // If the property "displayed" is changed, we want to hide the quake on the map, and also 
            // recalculate the trends, as this earthquake should no longer be included.
            if (e.PropertyName == Earthquake.DisplayedProperty)
            {
                Earthquake quake = sender as Earthquake;
                foreach (Map map in new Map[] { CompareMap, EarthquakeLocationMap })
                {
                    foreach (MapPolyline circle in map.Children)
                    {
                        if (circle.Tag.Equals(quake))
                        {
                            circle.Visibility = quake.Displayed ? Visibility.Visible : Visibility.Collapsed;
                            break;
                        }
                    }
                }
                CalculateTrends();
            }
        }

        #endregion

        #region Trend Calculation

        /// <summary>
        /// This method calculates data/trends for each chart in the 'analysis' tab.
        /// </summary>
        private void CalculateTrends()
        {
            if (_viewModel.FilteredQuakeList == null || _viewModel.FilteredQuakeList.Count == 0)
                return;

            if (_viewModel.FilteredQuakeList.Count < 1)
            {
                Frequency.Series[0].DataSeries = new DataSeries<DateTime, int>();
                MagnitudeBreakdown.DataSeries = new DataSeries<string, int>();
                return;
            }

            CalculateRadialTrends();

            CalculatePieChartTrends();

            CalculateFrequencyTrends();
        }

        /// <summary>
        /// Calculate trend data for the pie chart
        /// </summary>
        private void CalculatePieChartTrends()
        {
            double maxMagDouble = _viewModel.FilteredQuakeList[0].Magnitude;
            double minMagDouble = _viewModel.FilteredQuakeList[0].Magnitude;
            foreach (Earthquake quake in _viewModel.QuakeList)
            {
                maxMagDouble = Math.Max(quake.Magnitude, maxMagDouble);
                minMagDouble = Math.Min(quake.Magnitude, minMagDouble);
            }

            int minMag = (int)Math.Floor(minMagDouble);
            /*if maxMag is an integer it should be incremented.
             * e.g 3.1->4.7 should be 3->5
             *    3.1->5 should be 3->6
             */
            int maxMag = (int)Math.Ceiling(maxMagDouble + 0.0001);

            int bins = maxMag - minMag;
            List<DataPoint<double, int>> magPoints = DataBinner.BinData(_viewModel.FilteredQuakeList, (double)minMag, (double)maxMag, bins, q => q.Magnitude);
            List<DataPoint<string, int>> formattedMagPoints = new List<DataPoint<string, int>>();
            foreach (DataPoint<double, int> magPoint in magPoints)
            {
                DataPoint<string, int> point = new DataPoint<string, int>() { Y = magPoint.Y };
                int min = (int)Math.Round(magPoint.X);
                point.X = min + "\u2264" + "m<" + (min + 1);
                if (point.Y > 0)
                {
                    formattedMagPoints.Add(point);
                }
            }

            MagnitudeBreakdown.DataSeries = new DataSeries<string, int>(formattedMagPoints);
        }

        /// <summary>
        /// Calculate trend data for frequency chart
        /// </summary>
        private void CalculateFrequencyTrends()
        {
            if (_viewModel.QuakeList == null || _viewModel.QuakeList.Count == 0)
                return;

            long maxTicks = _viewModel.QuakeList[0].Updated.Ticks;
            long minTicks = _viewModel.QuakeList[0].Updated.Ticks;
            foreach (Earthquake quake in _viewModel.FilteredQuakeList)
            {
                maxTicks = Math.Max(maxTicks, quake.Updated.Ticks);
                minTicks = Math.Min(minTicks, quake.Updated.Ticks);
            }

            long difference = maxTicks - minTicks;
            int frequencyBins;
            if (difference <= TimeSpan.FromHours(1).Ticks)
            {
                frequencyBins = 30;
                maxTicks = minTicks + TimeSpan.FromHours(1).Ticks;
            }
            else if (difference <= TimeSpan.FromDays(1).Ticks)
            {
                frequencyBins = 24;
                maxTicks = minTicks + TimeSpan.FromDays(1).Ticks;
            }
            else if (difference <= TimeSpan.FromDays(7).Ticks)
            {
                frequencyBins = 28;
                maxTicks = minTicks + TimeSpan.FromDays(7).Ticks;
            }
            else
            {
                frequencyBins = 28;
            }

            List<DataPoint<DateTime, int>> frequencyPoints = DataBinner.BinData(_viewModel.FilteredQuakeList, minTicks, maxTicks, frequencyBins, q => q.Updated);
            IRange range = Frequency.XAxis.CreateRange();
            range.Minimum = new DateTime(minTicks);
            range.Maximum = new DateTime(maxTicks);
            Frequency.XAxis.Range = range;
            Frequency.Series[0].DataSeries = new DataSeries<DateTime, int>(frequencyPoints);
        }

        /// <summary>
        ///  Calculate trend data for the radial charts
        /// </summary>
        private void CalculateRadialTrends()
        {
            EarthquakeDistribution.Series = new RadialSeriesCollection();

            List<DataPoint<double, int>> longPoints = DataBinner.BinData(_viewModel.FilteredQuakeList, -180.0, 180.0, 10, q => q.Long);
            IRadialChartSeries longitudeSeries = new RadialLineSeries();
            longitudeSeries.DataSeries = new DataSeries<double, int>(longPoints);
            longitudeSeries.DataSeries.Title = "Longitude";
            EarthquakeDistribution.Series.Add(longitudeSeries);

            List<DataPoint<double, int>> latPoints = DataBinner.BinData(_viewModel.FilteredQuakeList, -90.0, 90.0, 20, q => q.Lat);
            IRadialChartSeries latitudeSeries = new RadialLineSeries();
            latitudeSeries.DataSeries = new DataSeries<double, int>(latPoints);
            latitudeSeries.DataSeries.Title = "Latitude";
            EarthquakeDistribution.Series.Add(latitudeSeries);
        }

        #endregion
    }
}