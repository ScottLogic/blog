﻿using System;
using System.Collections.Generic;
using EarthquakeMonitor.Model;

namespace EarthquakeMonitor
{
    public class HistoricalEarthquakeProvider
    {
        private List<Earthquake> _earthquakes = new List<Earthquake>();
        public List<Earthquake> Earthquakes
        {
            get
            {
                if (_earthquakes.Count < 1)
                {
                    CreateHistoricalList();
                }
                return _earthquakes;
            }
        }

        private void CreateHistoricalList()
        {
            string histroic = "Historic";
            Earthquake Chile = new Earthquake()
            {
                Id = "historical1chile",
                Displayed = false,
                Type = histroic,
                Magnitude = 9.5,
                Lat = -38.29,
                Long = -73.05,
                Depth = 33,
                Updated = new DateTime(1960, 5, 22),
                Title = "Great Chilean Earthquake",
                Link = "http://earthquake.usgs.gov/earthquakes/world/events/1960_05_22.php",
                Summary = "To date the most powerful earthquake ever recorded on Earth. Approximately 1,655 killed, 3,000 injured, 2,000,000 homeless, and $550 million damage in southern Chile; tsunami caused 61 deaths."
            };
            _earthquakes.Add(Chile);

            Earthquake princeWilliamSound = new Earthquake()
            {
                Id = "historical2alaska",
                Displayed = false,
                Type = histroic,
                Magnitude = 9.2,
                Lat = 61.02,
                Long = -147.65,
                Depth = 15.5,
                Updated = new DateTime(1964, 3, 28),
                Title = "Prince William Sound, Alaska",
                Link = "http://earthquake.usgs.gov/earthquakes/states/events/1964_03_28.php",
                Summary = "This great earthquake and ensuing tsunami took 128 lives (tsunami 113, earthquake 15), and caused about $311 million in property loss."
            };
            _earthquakes.Add(princeWilliamSound);

            Earthquake Sumatra = new Earthquake()
            {
                Id = "historical3sumatra",
                Displayed = false,
                Type = histroic,
                Magnitude = 9.1,
                Lat = 3.316,
                Long = 95.854,
                Depth = 30,
                Updated = new DateTime(2004, 12, 26),
                Title = "Indian Ocean Earthquake",
                Link = "http://earthquake.usgs.gov/earthquakes/eqinthenews/2004/us2004slav/",
                Summary = "The earthquake was caused by subduction and triggered a series of devastating tsunamis along the coasts of most landmasses bordering the Indian Ocean, killing over 230,000 people in fourteen countries, and inundating coastal communities with waves up to 30 meters (100 feet) high."
            };
            _earthquakes.Add(Sumatra);

            Earthquake Japan = new Earthquake()
            {
                Id = "historical4japan",
                Displayed = false,
                Type = histroic,
                Magnitude = 9.0,
                Lat = 38.322,
                Long = 142.369,
                Depth = 32,
                Updated = new DateTime(2011, 3, 11),
                Title = "Kamchatka",
                Link = "http://earthquake.usgs.gov/earthquakes/eqinthenews/2011/usc0001xgp/",
                Summary = "The 2011 Tōhoku earthquake, also known as the Great East Japan Earthquake, was a magnitude 9.0 (Mw) undersea megathrust earthquake off the coast of Japan."
            };
            _earthquakes.Add(Japan);

            Earthquake SanFrancisco = new Earthquake()
            {
                Id = "historical5sanfrancisco",
                Displayed = false,
                Type = histroic,
                Magnitude = 7.8,
                Lat = 33.75,
                Long = -122.55,
                Depth = 8,
                Updated = new DateTime(1906, 4, 18),
                Title = "San Francisco, California",
                Link = "http://earthquake.usgs.gov/earthquakes/states/events/1906_04_18.php",
                Summary = "This earthquake is one of the most devastating in the history of California. The earthquake and resulting fires caused an estimated $524 million in property loss."
            };
            _earthquakes.Add(SanFrancisco);
        }
    }
}