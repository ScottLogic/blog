﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using EarthquakeMonitor.Model;
using Visiblox.Charts;

namespace EarthquakeMonitor
{
    /// <summary>
    /// This class contains static methods to put earthquakes in data bins (buckets). For example we can pass in a collection
    /// of earthquakes, specify a range, and function to get the 'Magnitude' of an earthquake. This will return a list of data 
    /// points which have magnitude on the x axis, and the number of earthquakes which have that magnitude on the y axis.
    /// </summary>
    public class DataBinner
    {
        /// <summary>
        /// Bins data comprised of doubles
        /// </summary>
        /// <param name="quakes">A list of earthquakes</param>
        /// <param name="min">Minimum bin value</param>
        /// <param name="max">Maximum bind value</param>
        /// <param name="bins">Number of bins</param>
        /// <param name="valueFunction">A function to get the request value from an earthquake</param>
        /// <returns>A list of binned data points</returns>
        public static List<DataPoint<double, int>> BinData(
            Collection<Earthquake> quakes,
            double min,
            double max,
            int bins,
            Func<Earthquake, double> valueFunction)
        {
            double binSize = (max - min) / bins;
            List<DataPoint<double, int>> points = new List<DataPoint<double, int>>();

            for (int i = 0; i < bins; i++)
            {
                DataPoint<double, int> point = new DataPoint<double, int>() { X = min + i * binSize, Y = 0 };
                points.Add(point);
            }

            foreach (Earthquake quake in quakes)
            {
                double value = valueFunction(quake);
                int bin = (int) Math.Floor((value-min) / binSize);
                //due to rounding errors, sometimes maximum value can be out of bounds
                if (bin >= bins)
                {
                    bin--;
                }
                points[bin].Y++;
                points[bin].Y++;
            }

            return points;
        }

        /// <summary>
        /// Bins data comprised of dates
        /// </summary>
        /// <param name="quakes">A list of earthquakes</param>
        /// <param name="minTicks">Minimum bin value</param>
        /// <param name="maxTicks">Maximum bin value</param>
        /// <param name="bins">Number of bins</param>
        /// <param name="valueFunction">A function to get the request value from an earthquake</param>
        /// <returns>A list of binned data points</returns>
        public static List<DataPoint<DateTime, int>> BinData(
            Collection<Earthquake> quakes,
            long minTicks,
            long maxTicks,
            int bins,
            Func<Earthquake, DateTime> valueFunction)
        {
            long binSize = (maxTicks - minTicks) / bins;
            List<DataPoint<DateTime, int>> points = new List<DataPoint<DateTime, int>>(bins);

            for (long i = 0; i < bins; i++)
            {
                DateTime newDateTime = new DateTime(minTicks + i * binSize);
                DataPoint<DateTime, int> point = new DataPoint<DateTime, int>() { X = newDateTime, Y = 0 };
                points.Add(point);
            }

            foreach (Earthquake quake in quakes)
            {
                long ticks = (valueFunction(quake)).Ticks;
                int bin = (int)Math.Floor((double)(ticks - minTicks) / binSize);
                //due to rounding errors, sometimes maximum value can be out of bounds
                if (bin >= bins)
                {
                    bin--;
                }
                points[bin].Y++;
            }
            return points;
        }
    }
}
