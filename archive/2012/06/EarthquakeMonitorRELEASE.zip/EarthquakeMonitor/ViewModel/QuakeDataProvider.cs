using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using EarthquakeMonitor.Model;

namespace EarthquakeMonitor.ViewModel
{
    public class QuakeDataProvider
    {
        private MonitorViewModel _viewModel;
        private List<Earthquake> _quakeList;
        private Uri _uri;
        private string _downloadString;

        private const string atomString = "{http://www.w3.org/2005/Atom}";
        private const string geoString = "{http://www.georss.org/georss}";

        public QuakeDataProvider(MonitorViewModel viewModel)
        {
            if (viewModel == null)
                throw new NullReferenceException();

            _viewModel = viewModel;
        }

        public void ReadQuakeData(Uri feedUri)
        {
            _uri = feedUri;
            
            // Read the Data Feed
            WebClient rssQuakeService = new WebClient();
            rssQuakeService.DownloadStringCompleted += new DownloadStringCompletedEventHandler(RssQuakeService_DownloadStringCompleted);
            rssQuakeService.DownloadStringAsync(_uri, UriKind.RelativeOrAbsolute);
        }

        private void RssQuakeService_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            _downloadString = e.Result;

            // Parse the results on a background thread
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(ParseRSS);
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(FinishedParsing);
            bw.RunWorkerAsync();
        }

        /// <summary>
        /// Parse the whole RSS document
        /// </summary>
        private void ParseRSS(object sender, DoWorkEventArgs e)
        {
            // Create a new quake list, potentially replacing the old one.
            _quakeList = new List<Earthquake>();

            // Parse the RSS feed as an XDocument
            XDocument channel = XDocument.Parse(_downloadString);

            // Generate Earthquakes from the RSS channel.
            _quakeList = channel.Descendants()
                .Where(item => item.Name == "item")
                .Select((item, index) => CreateEarthquakeFromXElementAndIndex(item, index))
                .ToList();

            // Sort the List. Lowest Magnitude to Highest Magnitude.
            _quakeList.Sort(SortComparators.CompareQuakesByMagnitude);
        }

        /// <summary>
        /// Creates an earthquake object when given an XElement representing it.
        /// </summary>
        private static Earthquake CreateEarthquakeFromXElementAndIndex(XElement xElement, int i)
        {
            Earthquake quake = new Earthquake();
            quake.Type = "Feed";
            quake.Index = i;

            int subjectCounter = 0;
            foreach (XElement item in xElement.Descendants())
            {
                if (item.Name == "title")
                {
                    string itemValue = item.Value;
                    string[] itemValues = itemValue.Split(',');
                    
                    quake.Title = Capitalise(itemValues[1].Trim());
                    quake.Magnitude = Convert.ToDouble(itemValues[0].Split(' ')[1].Trim());
                }
                else if (item.Name == "pubDate")
                {
                    DateTime parsedUpdated;
                    DateTime.TryParse(item.Value, out parsedUpdated);

                    if (parsedUpdated != null)
                        quake.Updated = parsedUpdated;
                }
                else if (item.Name == "link")
                {
                    quake.Link = item.Value;
                }
                else if (item.Name == atomString + "description")
                {
                    quake.Summary = item.Value;
                }
                else if (item.Name == "{http://www.w3.org/2003/01/geo/wgs84_pos#}lat")
                {
                    quake.Lat = Convert.ToDouble(item.Value);
                }
                else if (item.Name == "{http://www.w3.org/2003/01/geo/wgs84_pos#}long")
                {
                    quake.Long = Convert.ToDouble(item.Value);
                }
                else if (item.Name == "{http://purl.org/dc/elements/1.1/}subject")
                {
                    subjectCounter++;
                    if (subjectCounter == 3)
                        quake.Depth = Convert.ToDouble(item.Value.Split(' ')[0]);
                }
                else if (item.Name == "guid")
                {
                    quake.Id = item.Value;
                }
            }
            return quake;
        }

        /// <summary>
        /// Parsing is complete. Clear the download string and update the view model with the new list.
        /// </summary>
        private void FinishedParsing(object sender, RunWorkerCompletedEventArgs e)
        {
            _downloadString = null;
            _viewModel.UpdateQuakeList(_quakeList);
        }

        /// <summary>
        /// Re-download the data located at the last used URI.
        /// </summary>
        internal void RefreshProvider()
        {
            ReadQuakeData(_uri);
        }

        /// <summary>
        /// Helper method to capitalise a string
        /// </summary>
        /// <param name="toCapitalise">String the capitalise</param>
        /// <returns>A capitalised version of the toCapitalise string </returns>
        private static string Capitalise(string toCapitalise)
        {
            try
            {
                if (toCapitalise.Length > 1)
                    toCapitalise = toCapitalise.Substring(0, 1).ToUpper() + toCapitalise.Substring(1);
            }
            catch (Exception) { return string.Empty; }

            return toCapitalise;
        }
    }
}