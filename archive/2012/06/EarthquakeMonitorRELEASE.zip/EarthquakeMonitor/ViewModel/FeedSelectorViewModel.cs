using System;
using System.Collections.Generic;
using EarthquakeMonitor.Model;

namespace EarthquakeMonitor.ViewModel
{
    public class FeedSelectorViewModel : ViewModelBase
    {
        #region Properties

        public static readonly string IsLoadingProperty = "IsLoading";
        private bool _isLoading;
        public bool IsLoading 
        { 
            get { return _isLoading; }
            set { SetField(ref _isLoading, value, IsLoadingProperty); }
        }

        public static readonly string CategoriesProperty = "Categories";
        private List<FeedCategory> _categories;
        public List<FeedCategory> Categories
        {
            get { return _categories; }
            set { SetField(ref _categories, value, CategoriesProperty); }
        }
        
        #endregion

        private MonitorViewModel _viewModel;
        public event EventHandler FeedLoadedEvent;

        public FeedSelectorViewModel(MonitorViewModel viewModel)
        {
            _viewModel = viewModel;
            Categories = SetupCategories();
        }

        public void FeedLoaded()
        {
            OnFeedLoadedEvent(null);
            IsLoading = false;
        }

        protected virtual void OnFeedLoadedEvent(EventArgs e)
        {
            if (FeedLoadedEvent != null)
                FeedLoadedEvent(this, e);
        }

        public void LoadFeed(Feed f)
        {
            IsLoading = true;
            _viewModel.FeedLoadedListener = new MonitorViewModel.FeedLoaded(FeedLoaded);
            _viewModel.UpdateData(f.URL);
        }

        private List<FeedCategory> SetupCategories()
        {
            List<FeedCategory> categories = new List<FeedCategory>();

            // Past Hour Category
            FeedCategory pastHour = new FeedCategory() { Title = "Past Hour" };
            List<Feed> pastHourFeeds = new List<Feed>();
            pastHourFeeds.Add(new Feed() { Title = "M +1 Earthquakes", URL = "http://feeds.feedburner.com/usgs/PnTV"});
            pastHourFeeds.Add(new Feed() { Title = "M 0+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/ecQb"});
            pastHour.Feeds = pastHourFeeds;
            categories.Add(pastHour);

            // Past Day Category
            FeedCategory pastDay = new FeedCategory() { Title = "Past Day" };
            List<Feed> pastDayFeeds = new List<Feed>();
            pastDayFeeds.Add(new Feed() { Title = "M 2.5+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/CgFL"});
            pastDayFeeds.Add(new Feed() { Title = "M +1 Earthquakes", URL = "http://feeds.feedburner.com/usgs/sZLm"});
            pastDayFeeds.Add(new Feed() { Title = "M 0+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/WdrW"});
            pastDay.Feeds = pastDayFeeds;
            categories.Add(pastDay);

            // Past Week Category
            FeedCategory pastWeek = new FeedCategory() { Title = "Past Week" };
            List<Feed> pastWeekFeeds = new List<Feed>();
            pastWeekFeeds.Add(new Feed() { Title = "M 7+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/WCjh"});
            pastWeekFeeds.Add(new Feed() { Title = "M 5+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/HnGL"});
            pastWeekFeeds.Add(new Feed() { Title = "M 2.5+ Earthquakes", URL = "http://feeds.feedburner.com/usgs/FXQI"});
            pastWeek.Feeds = pastWeekFeeds;
            categories.Add(pastWeek);

            return categories;
        }
    }
}