using EarthquakeMonitor.Model;

namespace EarthquakeMonitor.ViewModel
{
    public class SortComparators
    {
        public static int CompareQuakesByMagnitude(Earthquake x, Earthquake y)
        {
            if (x == null)
            {
                // If x is null and y is null, they're equal. 
                if (y == null)
                    return 0;
                // If x is null and y is not null, y is greater. 
                else
                    return -1;
            }
            else
            {
                // If x is not null...
                if (y == null)
                    return 1;
                else
                {
                    // ...and y is not null, compare the 
                    // lengths of the two strings.
                    //
                    int retval = x.Magnitude.CompareTo(y.Magnitude);

                    if (retval != 0)
                    {
                        // If the strings are not of equal length,
                        // the longer string is greater.
                        return retval;
                    }
                    else
                    {
                        // If the strings are of equal length,
                        // sort them with ordinary string comparison.
                        return x.Title.CompareTo(y.Title);
                    }
                }
            }
        }
    }
}