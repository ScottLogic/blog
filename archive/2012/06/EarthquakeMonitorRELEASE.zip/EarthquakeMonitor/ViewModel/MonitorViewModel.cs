using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using EarthquakeMonitor.Model;

namespace EarthquakeMonitor.ViewModel
{
    /// <summary>
    /// View Model that stores and updates the quake information
    /// </summary>
    public class MonitorViewModel : ViewModelBase
    {
        public delegate void FeedLoaded();
        public FeedLoaded FeedLoadedListener { get; set; }

        QuakeDataProvider _dataProvider;
        private HistoricalEarthquakeProvider historicalEarthquakeProvider = new HistoricalEarthquakeProvider();

        public MonitorViewModel(MainPage view)
        {
            // Load the default feed.
            UpdateData("http://feeds.feedburner.com/usgs/sZLm");
        }

        public void UpdateData(String url)
        {
            QuakeList = new ObservableCollection<Earthquake>();
            FilteredQuakeList = new ObservableCollection<Earthquake>();
            _dataProvider = new QuakeDataProvider(this);
            _dataProvider.ReadQuakeData(new Uri(url));
        }

        public static readonly string SelectedQuakeProperty = "SelectedQuake";
        
        private Earthquake _selectedQuake;
        public Earthquake SelectedQuake 
        {
            get { return _selectedQuake;} 
            set { SetField(ref _selectedQuake, value, "SelectedQuake"); }
        }

        public static readonly string QuakeListProperty = "QuakeList";
        private ObservableCollection<Earthquake> _quakeList;
        public ObservableCollection<Earthquake> QuakeList
        {
            get { return _quakeList;}
            set { SetField<ObservableCollection<Earthquake>>(ref _quakeList, value, QuakeListProperty); }
        }

        public static readonly string PagedFilteredQuakeListProperty = "PagedFilteredQuakeList";
        private PagedCollectionView _pagedFilteredQuakeList;
        public PagedCollectionView PagedFilteredQuakeList
        {
            get { return _pagedFilteredQuakeList; }
            set { SetField<PagedCollectionView>(ref _pagedFilteredQuakeList, value, PagedFilteredQuakeListProperty); }
        }

        public static readonly string FilteredQuakeListProperty = "FilteredQuakeList";
        private ObservableCollection<Earthquake> _filteredQuakeList;
        public ObservableCollection<Earthquake> FilteredQuakeList
        {
            get { return _filteredQuakeList;}
            set { SetField<ObservableCollection<Earthquake>>(ref _filteredQuakeList, value, FilteredQuakeListProperty); }
        }

        internal void UpdateQuakeList(List<Earthquake> quakeList)
        {
            // Add the historical quakes to the quake list passed in.
            foreach (Earthquake q in historicalEarthquakeProvider.Earthquakes)
            {
                quakeList.Add(q);
            }

            // Sort the List. Lowest Magnitude to Highest Magnitude.
            quakeList.Sort(SortComparators.CompareQuakesByMagnitude);
            if (FeedLoadedListener != null)
            {
                FeedLoadedListener();
            }

            // Clear the existing quakes.
            QuakeList.Clear();

            int i = 0;
            foreach (Earthquake q in quakeList)
            {
                // Set the index of the quake and add it to the list.
                i++;
                q.Index = i;
                QuakeList.Add(q);
                
                // Add a property changed handler, and draw each earthquake on the map
                q.PropertyChanged += new PropertyChangedEventHandler(EarthquakePropertyChanged);
            }
            
            // Update the paged quake list, and throw on property changed so the view knows to update.
            _pagedFilteredQuakeList = new PagedCollectionView(QuakeList);
            _pagedFilteredQuakeList.GroupDescriptions.Add(new PropertyGroupDescription("Type"));
            
            // Add all of the displayed quakes to the Filtered Quake List.
            foreach (Earthquake quake in quakeList)
            {
                if (quake.Displayed)
                    FilteredQuakeList.Add(quake);
            }
            
            // Throw property changed events for the lists that will have changed as a result of the update.
            OnPropertyChanged(FilteredQuakeListProperty);
            OnPropertyChanged(PagedFilteredQuakeListProperty);
            OnPropertyChanged(QuakeListProperty);
        }

        // Earthquake Property Changes - so update the filtered list with whether it is displayed or not.
        private void EarthquakePropertyChanged(Object sender, PropertyChangedEventArgs e)
        {
            Earthquake quake = sender as Earthquake;
            if (quake == null)
                return;
            if (e.PropertyName.Equals("Displayed"))
            {
                if (quake.Displayed)
                {
                    FilteredQuakeList.Add(quake);
                }
                else
                {
                    FilteredQuakeList.Remove(quake);
                }
            }
        }

        // Refresh the Data Provider.
        internal void Refresh()
        {
            _dataProvider.RefreshProvider();
        }
    }
}