﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;
using LinqToVisualTree;
using System.Windows.Controls.Primitives;
using Microsoft.Xna.Framework;
using System.IO;
using Microsoft.Xna.Framework.Audio;
using SystemColor = System.Windows.Media.Color;
using System.Diagnostics;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace ClearStyle
{
  public partial class MainPage : PhoneApplicationPage
  {
    // the model objects
    private RangeObservableCollection<ToDoItem> _todoItems = new RangeObservableCollection<ToDoItem>();

    // constants
    private static readonly int AutoScrollHitRegionSize = 80;
    private static readonly double FlickVelocity = 2000.0;

    // flags that indicate certain states
    private bool _horizontalDrag;
    private bool _dragReOrder;

    // transient state variables
    private Canvas _tickAndCrossContainer;
    private int _initialDragIndex;
    private ScrollViewer _scrollViewer;
     
    // timer for auto-scroll behaviour
    private DispatcherTimer _autoScrollTimer;

    // sound effects
    SoundEffect _completeSound;
    SoundEffect _deleteSound;
    SoundEffect _moveSound;
    

    // gets the scrollviewer from the ItemsControl template
    private ScrollViewer VerticalScrollViewer
    {
      get
      {
        if (_scrollViewer == null)
        {
          _scrollViewer = todoList.Descendants<ScrollViewer>()
                                  .Cast<ScrollViewer>()
                                  .Single();
        }
        return _scrollViewer;
      }
    }

    // Constructor
    public MainPage()
    {
      InitializeComponent();

      _completeSound = SoundEffect.FromStream(TitleContainer.OpenStream("Sounds/Windows XP Exclamation.wav"));
      _deleteSound = SoundEffect.FromStream(TitleContainer.OpenStream("Sounds/Windows XP Notify.wav"));
      _moveSound = SoundEffect.FromStream(TitleContainer.OpenStream("Sounds/Windows XP Menu Command.wav"));
      FrameworkDispatcher.Update();

      _todoItems.Add(new ToDoItem("Feed the cat"));
      _todoItems.Add(new ToDoItem("Buy eggs"));
      _todoItems.Add(new ToDoItem("Pack bags for WWDC conference"));
      _todoItems.Add(new ToDoItem("Rule the web"));
      _todoItems.Add(new ToDoItem("Order business cards"));
      _todoItems.Add(new ToDoItem("Fix laptop"));
      _todoItems.Add(new ToDoItem("Get some dollars for trip"));
      _todoItems.Add(new ToDoItem("Shirts"));
      _todoItems.Add(new ToDoItem("Shopping"));
      _todoItems.Add(new ToDoItem("Contact PR company"));
      _todoItems.Add(new ToDoItem("Extension plans"));
      _todoItems.Add(new ToDoItem("Choose colour scheme"));
      _todoItems.Add(new ToDoItem("Create new website"));
      _todoItems.Add(new ToDoItem("Write-up blog post"));
      _todoItems.Add(new ToDoItem("Choose life"));
      _todoItems.Add(new ToDoItem("Simplify my life"));

      UpdateToDoColors();
      this.DataContext = _todoItems;

      _autoScrollTimer = new DispatcherTimer();
      _autoScrollTimer.Interval = TimeSpan.FromMilliseconds(50);
      _autoScrollTimer.Tick += (s, e) =>
        {
          AutoScrollList();
          ShuffleItemsOnDrag();
        };
         
    }

    private void UpdateToDoColors()
    {
      double itemCount = _todoItems.Count;
      double index = 0;
      foreach (var todoItem in _todoItems)
      {
        double val = (index / itemCount) * 155.0;
        index++;

        if (!todoItem.Completed)
        {
          todoItem.Color = SystemColor.FromArgb(255, 255, (byte)val, 0);
        }
      };         
    }

    private double TickAndCrossOpacity(double offset)
    {
      offset = Math.Abs(offset);
      if (offset < 50)
        return 0;

      offset -= 50;
      double opacity = offset / 100;

      opacity = Math.Max(Math.Min(opacity, 1), 0);
      return opacity;
    }

    private void GestureListener_DragStarted(object sender, DragStartedGestureEventArgs e)
    {
      Debug.WriteLine("DragStarted");

      if (_dragReOrder)
        return;

      _horizontalDrag = true;

      // initialize the drag
      FrameworkElement fe = sender as FrameworkElement;
      fe.SetHorizontalOffset(0);

      // find the container for the tick and cross graphics
      _tickAndCrossContainer = fe.Descendants()
                                 .OfType<Canvas>()
                                 .Single(i => i.Name == "tickAndCross");
    }

    private void GestureListener_DragDelta(object sender, DragDeltaGestureEventArgs e)
    {
      Debug.WriteLine("DragDelta");

      if (!_horizontalDrag)
        return;

      // handle the drag to offset the element
      FrameworkElement fe = sender as FrameworkElement;
      double offset = fe.GetHorizontalOffset().Value + e.HorizontalChange;
      fe.SetHorizontalOffset(offset);

      _tickAndCrossContainer.Opacity = TickAndCrossOpacity(offset);


    }

    private void GestureListener_DragCompleted(object sender, DragCompletedGestureEventArgs e)
    {
      Debug.WriteLine("DragCompleted");

      if (!_horizontalDrag)
        return;

      FrameworkElement fe = sender as FrameworkElement;
      if (Math.Abs(e.HorizontalChange) > fe.ActualWidth / 2)
      {
        if (e.HorizontalChange < 0.0)
        {
          ToDoItemDeletedAction(fe);  
        }
        else
        {
          ToDoItemCompletedAction(fe);
        }
      }
      else
      {
        ToDoItemBounceBack(fe);
      }

      _horizontalDrag = false;
    }

    private void ToDoItemBounceBack(FrameworkElement fe)
    {
      var trans = fe.GetHorizontalOffset().Transform;

      trans.Animate(trans.X, 0, TranslateTransform.XProperty, 300, 0, new BounceEase()
      {
        Bounciness = 5,
        Bounces = 2
      });
    }

    private void ToDoItemDeletedAction(FrameworkElement deletedElement)
    {
      _deleteSound.Play();

      var trans = deletedElement.GetHorizontalOffset().Transform;
      trans.Animate(trans.X, -(deletedElement.ActualWidth + 50),
                    TranslateTransform.XProperty, 300, 0, new SineEase()
      {
        EasingMode = EasingMode.EaseOut
      },
      () =>
      {
        // find the model object that was deleted
        ToDoItem deletedItem = deletedElement.DataContext as ToDoItem;
        
        // determine how much we have to 'shuffle' up by
        double elementOffset = -deletedElement.ActualHeight;

        // find the items in view, and the location of the deleted item in this list
        var itemsInView = todoList.GetItemsInView().ToList();
        var lastItem = itemsInView.Last();
        int startTime = 0;
        int deletedItemIndex = itemsInView.Select(i => i.DataContext)
                                          .ToList().IndexOf(deletedItem);

        // iterate over each item
        foreach (FrameworkElement element in itemsInView.Skip(deletedItemIndex))
        {
          // for the last item, create an action that deletes the model object
          // and re-renders the list
          Action action = null;
          if (element == lastItem)
          {
            action = () =>
            {
              // clone the list
              var items = _todoItems.ToList();
              items.Remove(deletedItem);

              // re-populate our ObservableCollection
              _todoItems.Clear();
              _todoItems.AddRange(items);
              UpdateToDoColors();
            };
          }

          // shuffle this item up
          TranslateTransform elementTrans = new TranslateTransform();
          element.RenderTransform = elementTrans;
          elementTrans.Animate(0, elementOffset, TranslateTransform.YProperty, 200, startTime, null, action);
          startTime += 10;
        }
      });
    }

    private void ToDoItemCompletedAction(FrameworkElement fe)
    {
      // set the mode object to complete
      ToDoItem completedItem = fe.DataContext as ToDoItem;
      completedItem.Completed = true;
      completedItem.Color = Colors.Green;

      // bounce back into place
      ToDoItemBounceBack(fe);

      _completeSound.Play();
    }

    private void GestureListener_Flick(object sender, FlickGestureEventArgs e)
    {
      Debug.WriteLine("Flick");

      FrameworkElement fe = sender as FrameworkElement;
      if (e.HorizontalVelocity < -FlickVelocity)
      {
        ToDoItemDeletedAction(fe);
      }
      else if (e.HorizontalVelocity > FlickVelocity)
      {
        ToDoItemCompletedAction(fe);        
      }
    }


    private void GestureListener_GestureCompleted(object sender, Microsoft.Phone.Controls.GestureEventArgs e)
    {
      Debug.WriteLine("Completed");

      _dragReOrder = false;
    }

    private void Border_ManipulationDelta(object sender, ManipulationDeltaEventArgs e)
    {
      Debug.WriteLine("ManipulationDelta");

      if (!_dragReOrder)
        return;

      // set the event to handled in order to avoid scrolling the ScrollViewer
      e.Handled = true;

      // move our 'drag image'.
      dragImageContainer.SetVerticalOffset(dragImageContainer.GetVerticalOffset().Value + e.DeltaManipulation.Translation.Y);
    }

    private void ShuffleItemsOnDrag()
    {
      // find its current index
      int dragIndex = GetDragIndex();

      // iterate over the items in the list and offset as required
      double offset = dragImage.ActualHeight;
      for (int i = 0; i < _todoItems.Count; i++)
      {
        FrameworkElement item = todoList.ItemContainerGenerator.ContainerFromIndex(i) as FrameworkElement;

        // determine which direction to offset this item by
        if (i <= dragIndex && i > _initialDragIndex)
        {
          OffsetItem(-offset, item);
        }
        else if (i >= dragIndex && i < _initialDragIndex)
        {
          OffsetItem(offset, item);
        }
        else
        {
          OffsetItem(0, item);
        }
      }
    }

    private void OffsetItem(double offset, FrameworkElement item)
    {
      double targetLocation = item.Tag != null ? (double)item.Tag : 0;
      if (targetLocation != offset)
      {
        var trans = item.GetVerticalOffset().Transform;
        trans.Animate(null, offset, TranslateTransform.YProperty, 500, 0);
        item.Tag = offset;
        _moveSound.Play();
      }
    }

    // checks the current location of the item being dragged, and scrolls if it is
    // close to the top or the bottom
    private void AutoScrollList()
    {
      // where is the dragged item relative to the list bounds?
      double draglocation = dragImage.GetRelativePosition(todoList).Y + dragImage.ActualHeight / 2;

      if (draglocation < AutoScrollHitRegionSize)
      {
        // if close to the top, scroll up
        double velocity = (AutoScrollHitRegionSize - draglocation);
        VerticalScrollViewer.ScrollToVerticalOffset(VerticalScrollViewer.VerticalOffset - velocity);
      }
      else if (draglocation > todoList.ActualHeight - AutoScrollHitRegionSize)
      {
        // if close to the bottom, scroll down
        double velocity = (AutoScrollHitRegionSize - (todoList.ActualHeight - draglocation));
        VerticalScrollViewer.ScrollToVerticalOffset(VerticalScrollViewer.VerticalOffset + velocity);
      }
    }

    // Determines the index that the dragged item would occupy when dropped
    private int GetDragIndex()
    {
      double dragLocation = dragImageContainer.GetRelativePosition(todoList).Y +
                             VerticalScrollViewer.VerticalOffset +
                             dragImage.ActualHeight / 2;
      int dragIndex = (int)(dragLocation / dragImage.ActualHeight);
      return dragIndex;
    }


    private void Border_ManipulationCompleted(object sender, ManipulationCompletedEventArgs e)
    {
      if (!_dragReOrder)
        return;

      _dragReOrder = false;
      _autoScrollTimer.Stop();

      int dragIndex = GetDragIndex();
      
      // fade in the list
      todoList.Animate(null, 1.0, FrameworkElement.OpacityProperty, 200, 0);

      // animated the dragged item into location
      double targetLocation = dragIndex * dragImage.ActualHeight - VerticalScrollViewer.VerticalOffset;
      var trans = dragImageContainer.GetVerticalOffset().Transform;
      trans.Animate(null, targetLocation, TranslateTransform.YProperty, 200, 0, null,
        () =>
        {
          // clone the list and move the dragged item
          var items = _todoItems.ToList();
          var draggedItem = items[_initialDragIndex];
          items.Remove(draggedItem);
          items.Insert(dragIndex, draggedItem);

          // re-populate our ObservableCollection
          _todoItems.Clear();
          _todoItems.AddRange(items);
          UpdateToDoColors();

          // fade out the dragged image and collapse on completion
          dragImageContainer.Animate(null, 0.0, FrameworkElement.OpacityProperty, 1000, 0, null, ()
            => dragImageContainer.Visibility = Visibility.Collapsed);
        });

    }

    private void Border_Hold(object sender, System.Windows.Input.GestureEventArgs e)
    {
      Debug.WriteLine("Hold");
      _dragReOrder = true;

      // copy the dragged item to our 'dragImage' 
      FrameworkElement draggedItem = sender as FrameworkElement;
      var bitmap = new WriteableBitmap(draggedItem, null);
      dragImage.Source = bitmap;
      dragImageContainer.Visibility = Visibility.Visible;
      dragImageContainer.Opacity = 1.0;
      dragImageContainer.SetVerticalOffset(draggedItem.GetRelativePosition(todoList).Y);

      // hide the real item
      draggedItem.Opacity = 0.0;

      // fade out the list
      todoList.Animate(1.0, 0.7, FrameworkElement.OpacityProperty, 300, 0);

      _initialDragIndex = _todoItems.IndexOf(((ToDoItem)draggedItem.DataContext));

      _autoScrollTimer.Start();
    }
  }
}