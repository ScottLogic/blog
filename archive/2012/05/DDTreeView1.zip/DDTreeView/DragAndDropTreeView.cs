﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace DDTreeView
{
    public partial class DragAndDropTreeView : TreeView
    {

        #region Windows API

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hWnd, int wMsg, IntPtr wParam, IntPtr lParam);

        #endregion Windows API

        #region Constants
        // used by the Windows API
        private const int WM_VSCROLL = 0x115;
        private const int SB_LINEDOWN = 1;
        private const int SB_LINEUP = 0;

        #endregion Constants

  
        #region Structures and Enums

        public enum PositionByBorder
        {
            Top,
            Bottom,
            None
        };
        
        struct NodeState
        {
            public bool Moving;
            public bool Moved;
            public int Id;
        };

        #endregion

        #region Public Properties

        private int _popupWindowWidth = 400;
        public int PopupWindowWidth
        {
            get { return _popupWindowWidth; }
            set { _popupWindowWidth = value; }
        }

        private int _popupWidowHeight = 200;
        public int PopupWindowHeight
        {
            get { return _popupWidowHeight; }
            set { _popupWidowHeight = value; }
        }

        public Color SelectedNodeColourStyle { get; set; }
        public Color MovedNodeColourStyle { get; set; }
        public Color DefaultNodeColourStyle { get; set; }

        /// <summary>
        /// Start/Stop autoscrolling down the _controlUnderMouse
        /// </summary>       
        private Boolean AutoScrollDownEnabled
        {
            get { return _autoScrollDownEnabled; }
            set
            {
                _autoScrollDownEnabled = value;
                if (value) _autoScrollDownTimer.Start();
                else _autoScrollDownTimer.Stop();
            }
        }        
        private Boolean _autoScrollDownEnabled = false;

        /// <summary>
        /// Start/Stop autoscrolling up the _controlUnderMouse
        /// </summary>
        public Boolean AutoScrollUpEnabled
        {
            get { return _autoScrollUpEnabled; }
            set
            {
                _autoScrollUpEnabled = value;
                if (value) _autoScrollUpTimer.Start();
                else _autoScrollUpTimer.Stop();
            }
        }
        private Boolean _autoScrollUpEnabled = false;

        #endregion Public Properties

        #region Private Member Variables

        private Timer _autoScrollDownTimer = new Timer();
        private Timer _autoScrollUpTimer = new Timer();
        private const int _autoScrollDelay = 500; // ms
        private const int _controlBorderTollerance = 30;
        private Control _controlUnderMouse;
        private TreeNode _nodeBeingMoved;

        // controls used for the moving data popup
        private TreeView _popupTreeView = new TreeView();
        private Label _popupLabel = new Label();
        private Label _popupIcon = new Label();
        private TableLayoutPanel _popupPanel = new TableLayoutPanel();
        private Form _popupForm;
        
        #endregion Private Member Variables
                                    

        #region Constructor
        
        public DragAndDropTreeView() : base()
        {
            _autoScrollDownTimer.Interval = _autoScrollDelay;
            _autoScrollUpTimer.Interval = _autoScrollDelay;

            SubscribeToEvents();

            InitColourStyle();

            InitialisePopupWindow();
        }
        
        #endregion Constructor

        #region Initialisation
        
        /// <summary>
        /// Initialise the popup window layout
        /// </summary>
        private void InitialisePopupWindow()
        {
            _popupForm = new Form();
            _popupForm.Visible = false;
            _popupForm.StartPosition = FormStartPosition.Manual;
            _popupForm.Width = PopupWindowWidth;
            _popupForm.Height = PopupWindowHeight;            
            _popupForm.FormBorderStyle = FormBorderStyle.None;
            _popupForm.BringToFront();            
            _popupTreeView.Scrollable = false;
            _popupTreeView.BorderStyle = System.Windows.Forms.BorderStyle.None;

            _popupPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;

            TableLayoutPanel innerLabelPanel = new TableLayoutPanel();
            innerLabelPanel.ColumnCount = 2;
            innerLabelPanel.RowCount = 1;
            innerLabelPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            innerLabelPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 18));

            _popupPanel.ColumnCount = 1;
            _popupPanel.BackColor = Color.White;
            _popupPanel.RowCount = 2;
            _popupPanel.Dock = DockStyle.Fill;
            _popupForm.Controls.Add(_popupPanel);

            innerLabelPanel.Controls.Add(_popupIcon, 0, 0);
            innerLabelPanel.Controls.Add(_popupLabel, 1, 0);
            innerLabelPanel.AutoSize = true;

            _popupPanel.Controls.Add(innerLabelPanel, 0, 0);
            _popupPanel.Controls.Add(_popupTreeView, 0, 1);
            _popupTreeView.Dock = DockStyle.Fill;

            _popupLabel.Dock = DockStyle.Fill;
            _popupLabel.Width = PopupWindowWidth;

            _popupIcon.Dock = DockStyle.Top;
            _popupIcon.AutoSize = true;

            _popupLabel.AutoSize = true;
            _popupLabel.MaximumSize = new Size(PopupWindowWidth - 40, 100); // account for the icon & a bit of padding
            _popupLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
        }

        /// <summary>
        /// Initialise the default colour styles
        /// </summary>
        private void InitColourStyle()
        {
            SelectedNodeColourStyle = System.Drawing.ColorTranslator.FromHtml("#ccffff");
            MovedNodeColourStyle = System.Drawing.ColorTranslator.FromHtml("#ccffbb");
            DefaultNodeColourStyle = Color.White;
        }

        private void SubscribeToEvents()
        {
            this.ItemDrag += new ItemDragEventHandler(OnItemDrag);
            this.GiveFeedback += new GiveFeedbackEventHandler(OnGiveFeedback);
            this.QueryContinueDrag += new QueryContinueDragEventHandler(OnQueryContinueDrag);
            this.DragDrop += new DragEventHandler(OnDragDrop);
            this.DragEnter += new DragEventHandler(OnDragEnter);
            this.MouseMove += new MouseEventHandler(OnMouseMove);
            
            _autoScrollDownTimer.Tick += new EventHandler(OnScrollDownTick);
            _autoScrollUpTimer.Tick += new EventHandler(OnScrollUpTick);
        }
        
        #endregion Initialisation

        #region Event Handlers

        private void OnScrollUpTick(object sender, EventArgs e)
        {
            if (AutoScrollUpEnabled)
                SendMessage(_controlUnderMouse.Handle, WM_VSCROLL, (IntPtr)SB_LINEUP, IntPtr.Zero);                
            else
                _autoScrollUpTimer.Stop();
        }

        private void OnScrollDownTick(object sender, EventArgs e)
        {
            if (AutoScrollDownEnabled)
                SendMessage(_controlUnderMouse.Handle, WM_VSCROLL, (IntPtr)SB_LINEDOWN, IntPtr.Zero);
            else
                _autoScrollDownTimer.Stop();
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            // Check if they released the mouse button while off the control but didn't drop the data
            if (e.Button == System.Windows.Forms.MouseButtons.None && _nodeBeingMoved != null)
            {
                IndicateSubtreeNotMoving(_nodeBeingMoved, true);
                _nodeBeingMoved = null;
            }
        }

        private void OnQueryContinueDrag(object sender, QueryContinueDragEventArgs e)
        {
            if ((e.KeyState & 1) == 0)
            {
                // left mouse button has been released
                HideMovingDataWindow();
            }
        }

        private void OnGiveFeedback(object sender, System.Windows.Forms.GiveFeedbackEventArgs e)
        {
            Point globalPosition = Control.MousePosition;
            Point p = PointToClient(globalPosition);

            if (e.Effect == DragDropEffects.Move)
            {
                // Show pointer cursor while dragging
                e.UseDefaultCursors = false;
                this.Cursor = Cursors.Default;
            }
            else e.UseDefaultCursors = true;

            Point topLevelPoint = this.TopLevelControl.PointToClient(globalPosition);
            Control ctl = this.TopLevelControl.GetChildAtPoint(topLevelPoint);

            if (ctl != null && ctl.GetType().FullName.Equals(this.GetType().FullName) && ctl.AllowDrop)
            {
                _controlUnderMouse = ctl;
                _popupForm.Visible = true;
                UpdateMovingDataWindow(p.X, p.Y);           
            }
            else
            {
                _popupForm.Visible = false;
            }

            Point controlPoint = _controlUnderMouse.PointToClient(globalPosition);
            PositionByBorder nearEdge = LocationNearControlEdge(_controlUnderMouse, controlPoint.X, controlPoint.Y, _controlBorderTollerance);
            if (nearEdge == PositionByBorder.Bottom)
            {
                AutoScrollDownEnabled = true;
            }
            else AutoScrollDownEnabled = false;

            if (nearEdge == PositionByBorder.Top)
            {
                AutoScrollUpEnabled = true;
            }
            else AutoScrollUpEnabled = false;

        }
       
        private void OnDragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(TreeNode)))
            {
                e.Effect = DragDropEffects.Move;

                TreeNode tn = (TreeNode)e.Data.GetData(typeof(TreeNode).FullName, true);
                if (!CompareNodeTagState(_nodeBeingMoved, tn))
                {
                    _nodeBeingMoved = tn;
                    ReInitPopupWindowData(_nodeBeingMoved);
                }

                // We have some valid data in _previousSelectedNode, so change the curser back
                this.TopLevelControl.Cursor = Cursors.Default;
                this.Focus();
            }
            else
            {
                e.Effect = DragDropEffects.None;
                _nodeBeingMoved = null;
            }         
        }                     

        private void OnItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
        {
            _nodeBeingMoved = (TreeNode)e.Item;

            if (_nodeBeingMoved != null)
            {                
                //_nodeBeingMoved = selectedNode;                    
                ReInitPopupWindowData(_nodeBeingMoved);

                //Point p = PointToScreen(Control.MousePosition);
                Point p = PointToClient(Control.MousePosition);
                
                UpdateMovingDataWindow(p.X, p.Y);

                PositionByBorder nearEdge = LocationNearControlEdge(this, p.X, p.Y, _controlBorderTollerance);
                if (nearEdge == PositionByBorder.Bottom)
                {
                    AutoScrollDownEnabled = true;
                }
                else AutoScrollDownEnabled = false;

                if (nearEdge == PositionByBorder.Top)
                {
                    AutoScrollUpEnabled = true;
                }
                else AutoScrollUpEnabled = false;

                DoDragDrop(_nodeBeingMoved, DragDropEffects.Move);

                // Now that we've dropped the data, make sure we stop scrolling the control under the mouse.
                AutoScrollDownEnabled = false;
                AutoScrollUpEnabled = false;
            }
        }

        private void OnDragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
                HideMovingDataWindow();                

                this.Cursor = Cursors.Default;

                if (_nodeBeingMoved != null)
                {
                    Point pt = new Point(e.X, e.Y);
                    TreeNode newParentNode = this.GetNodeAt(PointToClient(pt));

                    Boolean createNewBranch = (newParentNode == null);

                    if (createNewBranch ? true : !IsNodeSameOrDescendant(newParentNode, _nodeBeingMoved))
                    {
                        //If the node is already in the tree somewhere, remove it.
                        _nodeBeingMoved.Remove();

                        if (createNewBranch)
                        {
                            this.Nodes.Add(_nodeBeingMoved);
                            newParentNode = _nodeBeingMoved;
                        }
                        else
                        {
                            newParentNode.Nodes.Add(_nodeBeingMoved);
                        }
                        
                        newParentNode.ExpandAll();

                        IndicateSubtreeMoved(_nodeBeingMoved);
                    }
                    else IndicateSubtreeNotMoving(_nodeBeingMoved, true);

                    _nodeBeingMoved = null;
                }                            
        }

        #endregion

        #region Private Methods


        /// <summary>
        /// Changes the BackColour for each node in subtreeRoot
        /// </summary>
        /// <param name="subtreeRoot"></param>
        private void IndicateSubtreeMoved(TreeNode subtreeRoot)
        {
            NodeState state = GetNodeTagState(subtreeRoot);
            state.Moved = true;
            state.Moving = false;
            subtreeRoot.Tag = state;
            subtreeRoot.BackColor = MovedNodeColourStyle;

            foreach (TreeNode n in subtreeRoot.Nodes)
            {
                IndicateSubtreeMoved(n);
            }
        }

        /// <summary>
        /// Changes the BackColour for each node in subtreeRoot and
        /// copies subtreeRoot into the moving data window.
        /// </summary>
        /// <param name="subtreeRoot">A subtree root in the treeview</param>
        private void IndicateSubtreeMoving(TreeNode subtreeRoot)
        {
            IndicateSubtreeMoving(subtreeRoot, null);
        }

        /// <summary>
        /// Changes the BackColour for each node in subtreeRoot and
        /// copies subtreeRoot into the moving data window
        /// </summary>
        /// <param name="subtreeRoot">A subtree root in the treeview</param>
        /// <param name="movingSubtreeParent">A subtree parent in the moving data window tree. Pass null for root node.</param>
        private void IndicateSubtreeMoving(TreeNode subtreeRoot, TreeNode movingSubtreeParent)
        {
            TreeNode currentNodeClone = new TreeNode(subtreeRoot.Text);
            if (movingSubtreeParent == null) _popupTreeView.Nodes.Add(currentNodeClone);
            else if (movingSubtreeParent != subtreeRoot) movingSubtreeParent.Nodes.Add(currentNodeClone);

            NodeState state = GetNodeTagState(subtreeRoot);
            state.Moving = true;
            subtreeRoot.Tag = state;
            subtreeRoot.BackColor = SelectedNodeColourStyle;

            foreach (TreeNode n in subtreeRoot.Nodes)
            {
                // note that we pass in the currentNodeClone (displayed in the moving data window) as the
                // moving subtree parent.
                IndicateSubtreeMoving(n, currentNodeClone);
            }
        }

        /// <summary>
        /// Compare the (NodeState)TreeNode.Tag for each node.
        /// Accounts for either parameter being null.
        /// </summary>
        /// <returns>(NodeState)node1.Tag.Id == (NodeState)node2.Tag.Id</returns>
        private bool CompareNodeTagState(TreeNode node1, TreeNode node2)
        {
            if (node1 == node2) return true;

            if ((node1 == null && node2 != null) || (node2 == null && node1 != null))
                return false;

            if (GetNodeTagState(node2).Id != GetNodeTagState(node1).Id)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Copies the tree with root node subtreeRoot into the moving data window.
        /// The subtreeRoot nodes may also be visually marked
        /// </summary>
        /// <param name="subtreeRoot"></param>
        private void ReInitPopupWindowData(TreeNode subtreeRoot)
        {
            _popupTreeView.Nodes.Clear();
            IndicateSubtreeMoving(subtreeRoot);

            _popupTreeView.ExpandAll();
            _popupTreeView.SelectedNode = null;
        }

        private PositionByBorder LocationNearControlEdge(Control control, int x, int y, int tollerance)
        {
            int width = control.Width;
            int height = control.Height;

            if (Math.Abs(0 - y) < tollerance) return PositionByBorder.Top;
            if (Math.Abs(height - y) < tollerance) return PositionByBorder.Bottom;

            return PositionByBorder.None;
        }

        private void UpdateMovingDataWindow(int cursorX, int cursorY)
        {
            // safety check
            if (_nodeBeingMoved != null)
            {
                Point screenCords = new Point(cursorX + 10, cursorY + 10);
                _popupForm.Location = this.PointToScreen(screenCords);

                TreeNode selectedNode = this.GetNodeAt(new Point(cursorX, cursorY));
                if (selectedNode != null)
                {
                    if (IsNodeSameOrDescendant(selectedNode, _nodeBeingMoved))
                    {
                        _popupLabel.Text = "Cannot move to " + selectedNode.Text;

                        _popupIcon.Image = Properties.Resources.cross_red_16x16;
                        _popupIcon.AutoSize = true;
                    }
                    else
                    {
                        _popupLabel.Text = "Move to " + selectedNode.Text;

                        _popupIcon.Image = Properties.Resources.tick_green_16x16;
                        _popupIcon.AutoSize = true;
                    }
                }
                else
                {
                    _popupLabel.Text = "Move to new branch";

                    _popupIcon.Image = Properties.Resources.tick_green_16x16;
                    _popupIcon.AutoSize = true;
                }

                _popupForm.BringToFront();
                _popupForm.Visible = true;
            }
        }

        /// <summary>
        /// Return true if node1 is the same as node2, or if node1 is a
        /// descendent of node2
        /// </summary>
        /// <param name="node1"></param>
        /// <param name="node2"></param>
        /// <returns></returns>
        private bool IsNodeSameOrDescendant(TreeNode node1, TreeNode node2)
        {
            if (node1 == null && node2 == null) return true;

            bool invalid = false;

            if (node1.Equals(node2))
            {
                invalid = true;
            }
            else
            {
                TreeNode parent = node1.Parent;
                while (parent != null && !invalid)
                {
                    if (parent.Equals(node2)) invalid = true;
                    else parent = parent.Parent;
                }
            }
            return invalid;
        }

        private void HideMovingDataWindow()
        {
            _popupForm.Visible = false;
        }
        
        /// <summary>
        /// Changes the BackColour for each node in subtreeRoot while preserving
        /// node state 
        /// </summary>
        /// <param name="subtreeRoot"></param>
        /// <param name="ignoreMovingState"></param>
        private void IndicateSubtreeNotMoving(TreeNode subtreeRoot, bool ignoreMovingState)
        {
            bool nodeHasNotMoved = false;
            NodeState state = GetNodeTagState(subtreeRoot);

            // Identify nodes which are not current moving, or *are* moving & ignoreMovingState=T
            if (state.Moving == false || ignoreMovingState)
            {
                if (state.Moved == false) nodeHasNotMoved = true;
                else
                {
                    subtreeRoot.BackColor = MovedNodeColourStyle;
                }
            }

            if (nodeHasNotMoved)
            {
                subtreeRoot.BackColor = DefaultNodeColourStyle;

                state.Moving = false;
                subtreeRoot.Tag = state;
            }

            foreach (TreeNode n in subtreeRoot.Nodes)
            {
                IndicateSubtreeNotMoving(n, ignoreMovingState);
            }
        }

        private NodeState GetNodeTagState(TreeNode node)
        {
            if (node == null) throw new Exception("Cannot get node tag state when node parameter is null");
            NodeState state;
            if (node.Tag != null) state = (NodeState)node.Tag;
            else
            {
                state = new NodeState();
                state.Id = node.GetHashCode();
            }
            return state;
        }
        
        #endregion Private Methods
    }
}
