﻿namespace DDTreeView
{
    partial class ExampleUsageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Node0");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Node2");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Node3");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Node1", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Node4");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Node6");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Node7");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Node9");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Node10");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Node8", new System.Windows.Forms.TreeNode[] {
            treeNode19,
            treeNode20});
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Node5", new System.Windows.Forms.TreeNode[] {
            treeNode17,
            treeNode18,
            treeNode21});
            this.ddTreeviewV22 = new DDTreeView.DragAndDropTreeView();
            this.ddTreeviewV21 = new DDTreeView.DragAndDropTreeView();
            this.btnGenerateTop = new System.Windows.Forms.Button();
            this.btnGenerateBottom = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ddTreeviewV22
            // 
            this.ddTreeviewV22.AllowDrop = true;
            this.ddTreeviewV22.AutoScrollUpEnabled = false;
            this.ddTreeviewV22.Location = new System.Drawing.Point(13, 187);
            this.ddTreeviewV22.PopupWindowHeight = 200;
            this.ddTreeviewV22.PopupWindowWidth = 400;
            this.ddTreeviewV22.Name = "ddTreeviewV22";
            this.ddTreeviewV22.MovedNodeColourStyle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(187)))));
            this.ddTreeviewV22.DefaultNodeColourStyle = System.Drawing.Color.White;
            this.ddTreeviewV22.SelectedNodeColourStyle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ddTreeviewV22.Size = new System.Drawing.Size(821, 155);
            this.ddTreeviewV22.TabIndex = 8;
            // 
            // ddTreeviewV21
            // 
            this.ddTreeviewV21.AllowDrop = true;
            this.ddTreeviewV21.AutoScrollUpEnabled = false;
            this.ddTreeviewV21.Location = new System.Drawing.Point(12, 12);
            this.ddTreeviewV21.PopupWindowHeight = 200;
            this.ddTreeviewV21.PopupWindowWidth = 400;
            this.ddTreeviewV21.Name = "ddTreeviewV21";
            this.ddTreeviewV21.MovedNodeColourStyle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(187)))));
            this.ddTreeviewV21.DefaultNodeColourStyle = System.Drawing.Color.White;
            treeNode12.Name = "Node0";
            treeNode12.Text = "Node0";
            treeNode13.Name = "Node2";
            treeNode13.Text = "Node2";
            treeNode14.Name = "Node3";
            treeNode14.Text = "Node3";
            treeNode15.Name = "Node1";
            treeNode15.Text = "Node1";
            treeNode16.Name = "Node4";
            treeNode16.Text = "Node4";
            treeNode17.Name = "Node6";
            treeNode17.Text = "Node6";
            treeNode18.Name = "Node7";
            treeNode18.Text = "Node7";
            treeNode19.Name = "Node9";
            treeNode19.Text = "Node9";
            treeNode20.Name = "Node10";
            treeNode20.Text = "Node10";
            treeNode21.Name = "Node8";
            treeNode21.Text = "Node8";
            treeNode22.Name = "Node5";
            treeNode22.Text = "Node5";
            this.ddTreeviewV21.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode15,
            treeNode16,
            treeNode22});
            this.ddTreeviewV21.SelectedNodeColourStyle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ddTreeviewV21.Size = new System.Drawing.Size(823, 156);
            this.ddTreeviewV21.TabIndex = 7;
            // 
            // btnGenerateTop
            // 
            this.btnGenerateTop.AutoSize = true;
            this.btnGenerateTop.Location = new System.Drawing.Point(841, 145);
            this.btnGenerateTop.Name = "btnGenerateTop";
            this.btnGenerateTop.Size = new System.Drawing.Size(107, 23);
            this.btnGenerateTop.TabIndex = 9;
            this.btnGenerateTop.Text = "Generate Structure";
            this.btnGenerateTop.UseVisualStyleBackColor = true;
            this.btnGenerateTop.Click += new System.EventHandler(this.btnGenerateTop_Click);
            // 
            // btnGenerateBottom
            // 
            this.btnGenerateBottom.AutoSize = true;
            this.btnGenerateBottom.Location = new System.Drawing.Point(841, 319);
            this.btnGenerateBottom.Name = "btnGenerateBottom";
            this.btnGenerateBottom.Size = new System.Drawing.Size(107, 23);
            this.btnGenerateBottom.TabIndex = 10;
            this.btnGenerateBottom.Text = "Generate Structure";
            this.btnGenerateBottom.UseVisualStyleBackColor = true;
            this.btnGenerateBottom.Click += new System.EventHandler(this.btnGenerateBottom_Click);
            // 
            // ExampleUsageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 354);
            this.Controls.Add(this.btnGenerateBottom);
            this.Controls.Add(this.btnGenerateTop);
            this.Controls.Add(this.ddTreeviewV22);
            this.Controls.Add(this.ddTreeviewV21);
            this.Name = "ExampleUsageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DragAndDropTreeView ddTreeviewV21;
        private DragAndDropTreeView ddTreeviewV22;
        private System.Windows.Forms.Button btnGenerateTop;
        private System.Windows.Forms.Button btnGenerateBottom;
    }
}

