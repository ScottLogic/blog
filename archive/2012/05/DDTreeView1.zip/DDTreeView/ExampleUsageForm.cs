﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace DDTreeView
{
    public partial class ExampleUsageForm : Form
    {
        public ExampleUsageForm()
        {
            InitializeComponent();                       
        }       

        public void InitWithRandomData(TreeView treeView)
        {
            treeView.Nodes.Clear();
            Random rnd = new Random();

            for (int i = 0; i < 3; i++)
            {
                String txt = "Branch " + i;
                TreeNode root = treeView.Nodes.Add(txt, txt, -1, -1);
                AddRandomChildren(root, 1, rnd);
                root.ExpandAll();
            }   
        }

        private void AddRandomChildren(TreeNode parent, int level, Random rnd)
        {

            if ((rnd.NextDouble() <= Convert.ToDouble(1) / level) || rnd.NextDouble() < 0.5)
            {
                String txt = parent.Text + " - Sub-branch " + level;
                TreeNode child = parent.Nodes.Add(txt, txt, -1, -1);
                AddRandomChildren(child, level + 1, rnd);
            }
        }

        private void btnGenerateTop_Click(object sender, EventArgs e)
        {
            InitWithRandomData(ddTreeviewV21);
        }

        private void btnGenerateBottom_Click(object sender, EventArgs e)
        {
            InitWithRandomData(ddTreeviewV22);
        }  
    }
}
