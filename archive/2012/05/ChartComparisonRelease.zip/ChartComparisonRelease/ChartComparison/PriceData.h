//
//  PriceData.h
//  ChartComparison
//
//  Created by Chris Grant on 16/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PriceData : NSObject

@property(nonatomic, retain) NSDate *date;
@property(nonatomic, assign) double index;
@property(nonatomic, assign) double open;
@property(nonatomic, assign) double high;
@property(nonatomic, assign) double low;
@property(nonatomic, assign) double close;
@property(nonatomic, assign) double volume;
@property(nonatomic, assign) double adjClose;

@end