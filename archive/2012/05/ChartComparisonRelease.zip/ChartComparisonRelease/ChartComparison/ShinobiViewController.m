//
//  ShinobiController.m
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.

#import "ShinobiViewController.h"

@implementation ShinobiViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString *licenseKeyString = @"<ADD YOUR SHINOBI LICENSE KEY HERE!>";
    
    _chart = [[ShinobiChart alloc] initWithFrame:self.view.bounds];
    _chart.autoresizingMask = ~UIViewAutoresizingNone;
    _chart.licenseKey = licenseKeyString;

    SChartDateTimeAxis *xAxis = [[SChartDateTimeAxis alloc] init];
    xAxis.enableGesturePanning = YES;
    xAxis.enableGestureZooming = YES;
    xAxis.enableMomentumPanning = YES;
    xAxis.enableMomentumZooming = YES;
    _chart.xAxis = xAxis;
    [xAxis release];
    
    SChartNumberAxis *yAxis = [[SChartNumberAxis alloc] init];
    yAxis.enableGesturePanning = YES;
    yAxis.enableGestureZooming = YES;
    yAxis.enableMomentumPanning = YES;
    yAxis.enableMomentumZooming = YES;
    _chart.yAxis = yAxis;
    [yAxis release];
    
    //Initialise the data source we will use for the chart
    _dataSource = [[[ShinobiDataSource alloc] init] retain];
    [_dataSource setData:[_priceContainer priceDataArray]];
    [_chart setDatasource:_dataSource];
    
    // Add the chart to the view controller
    [self.view addSubview:_chart];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{ 
    return YES;
}

-(void)dealloc
{
    [_chart release];
    [_dataSource release];
    
    [super dealloc];
}

@end