//
//  TableCell.h
//  ChartComparison
//
//  Created by Chris Grant on 26/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StockData;
@class StockSymbolCellView;

@interface StockSymbolCell : UITableViewCell
{
    StockSymbolCellView *messageCellView;
}

@property (nonatomic, retain) StockSymbolCellView *CellView;

-(void)setStockData:(StockData*)data;
-(void)redisplay;

@end