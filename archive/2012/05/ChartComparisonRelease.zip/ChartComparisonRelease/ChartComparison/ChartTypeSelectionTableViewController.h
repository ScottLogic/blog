//
//  HomeNavigationTable.h
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataManager.h"
#import "StockPriceDataContainer.h"

@interface ChartTypeSelectionTableViewController : UITableViewController
{
    NSArray *_items;
    StockPriceDataContainer *_priceContainer;
    NSDateFormatter *_dateFormatter;
    
    UILabel *_stockNameLabel;
    UILabel *_stockSectorLabel;
    UILabel *_stockSymbolLabel;
    UILabel *_countLabel;
    UILabel *_dateLabel;
    
    bool loaded;
    bool loading;
    
    UIActivityIndicatorView *_spinner;
    
    int numberOfRows;
}

-(id)initWithStockPriceContainer:(StockPriceDataContainer*)priceContainer;

-(void)refreshView;
-(void)loadData;
-(void)loadDataWithOperation:(NSString*)symbol;
-(void)loadStockPrices:(NSMutableArray*)stocks;
-(void)errorLoading;

@end
