//
//  TestViewController.m
//  ChartComparison
//
//  Created by Chris Grant on 29/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "CorePlotViewController.h"
#import "CorePlot-CocoaTouch.h"
#import "StockPriceDataContainer.h"

@implementation CorePlotViewController

-(void)loadView
{
    [super loadView];

    _graphHostingView = [[CPTGraphHostingView alloc] initWithFrame:self.view.bounds];
    [_graphHostingView setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:_graphHostingView];    
    [self loadChart:_priceContainer];
}

-(void)loadChart:(StockPriceDataContainer*)array
{
    _plot = [[[CorePlotLineChart alloc] init] initWithHostingView:_graphHostingView andData:_priceContainer];
    [_plot initialisePlot];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation { return YES; }

-(void)dealloc
{
    [_graphHostingView release];
    [_plot release];
    
    [super dealloc];
}

@end