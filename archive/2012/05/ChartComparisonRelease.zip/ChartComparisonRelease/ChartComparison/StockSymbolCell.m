//
//  TableCell.m
//  ChartComparison
//
//  Created by Chris Grant on 26/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StockSymbolCell.h"
#import "StockSymbolCellView.h"

@implementation StockSymbolCell

@synthesize CellView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
	if (self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier])
    {
		CGRect messageFrame = CGRectMake(0.0, 0.0,  768, self.frame.size.height);
		CellView = [[StockSymbolCellView alloc] initWithFrame:messageFrame];
		CellView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
		[self.contentView addSubview:CellView];
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self setBackgroundColor:[UIColor whiteColor]];
	}
	return self;
}

-(void)setStockData:(StockData*)data
{
    [CellView setData:data];
}

-(void)redisplay 
{
	[CellView setNeedsDisplay];
}

- (void)dealloc 
{
	[CellView release];
    [messageCellView release];
    
    [super dealloc];
}

@end