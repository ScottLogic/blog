//
//  LineChartDataSource.m
//  LineChart
//
//  Copyright 2011 Scott Logic Ltd. All rights reserved.
//

#import "ShinobiDataSource.h"
#import "PriceData.h"

@implementation ShinobiDataSource

@synthesize Data;

-(id<SChartData>)sChart:(ShinobiChart*)chart dataPointAtIndex:(int)dataIndex forSeriesAtIndex:(int)seriesIndex
{
    SChartDataPoint *datapoint = [[SChartDataPoint alloc] init];
    PriceData *pd = [[Data objectAtIndex:dataIndex] retain];
    datapoint.xValue = [pd date];
    datapoint.yValue = [NSNumber numberWithDouble:[pd close]];
    [pd release];
    
    return [datapoint autorelease];
}

-(SChartSeries*)sChart:(ShinobiChart *)chart seriesAtIndex:(int)index
{
    return [[[SChartLineSeries alloc] init] autorelease];
}

-(int)sChart:(ShinobiChart*)chart numberOfDataPointsForSeriesAtIndex:(int)seriesIndex
{
    return [Data count];
}

-(int)numberOfSeriesInSChart:(ShinobiChart *)chart 
{
    return 1;
}

-(void)dealloc
{
    [Data release];
    [super dealloc];
}

@end