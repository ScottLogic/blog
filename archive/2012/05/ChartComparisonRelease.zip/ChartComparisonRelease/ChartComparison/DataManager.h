//
//  DataManager.h
//  ChartComparison
//
//  Created by Chris Grant on 15/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UrlBuilder.h"

@interface DataManager : NSObject
{
    UrlBuilder *_urlBuilder;
    NSDateFormatter *dateFormatter;
}

-(NSMutableArray*)getDataForStock:(NSString*)symbol fromStartDate:(NSDate*)startDate;
-(NSMutableArray*)getStockList;

-(NSString*)getDataStringFromURL:(NSString*)url;

@end