//
//  StockSymbolCellView.m
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StockData.h"
#import "StockSymbolCellView.h"

@implementation StockSymbolCellView

@synthesize Data;
@synthesize highlighted;
@synthesize editing;

- (id)initWithFrame:(CGRect)frame 
{	
	if (self = [super initWithFrame:frame]) 
    {
		self.backgroundColor = [UIColor whiteColor];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
            _backgroundImage = [UIImage imageNamed:@"row.png_iPad"];
        else
            _backgroundImage = [UIImage imageNamed:@"row.png"];
	}
	return self;
}

- (void)setData:(StockData*)newData
{
	if (Data != newData)
    {
		[Data release];
		Data = [newData retain];
	}
	[self setNeedsDisplay];
}

- (void)setHighlighted:(BOOL)lit 
{
	if (highlighted != lit) 
    {
		highlighted = lit;	
		[self setNeedsDisplay];
	}
}

-(void)drawRect:(CGRect)rect
{
    UIFont *mainFont = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    UIFont *secondaryFont = [UIFont fontWithName:@"HelveticaNeue-Medium" size:14];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        _backgroundImage = [[UIImage imageNamed:@"row_iPad.png"] retain];
        [_backgroundImage drawAtPoint:CGPointMake(0, 0)];
    }
    else
    {
        _backgroundImage = [[UIImage imageNamed:@"row.png"] retain];
        [_backgroundImage drawAtPoint:CGPointMake(0, 0)];
    }
    
    CGPoint point;
    
    [[UIColor blackColor] set];
    point = CGPointMake(5, 9);
    [Data.name drawAtPoint:point forWidth:280 withFont:mainFont minFontSize:18 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
    
    [[UIColor whiteColor] set];
    point = CGPointMake(5, 10);
    [Data.name drawAtPoint:point forWidth:280 withFont:mainFont minFontSize:18 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];

    [[UIColor darkGrayColor] set];    
    point = CGPointMake(5, 38);
    [Data.symbol drawAtPoint:point forWidth:50 withFont:secondaryFont minFontSize:14 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
    
    [[UIColor blackColor] set];
    point = CGPointMake(5, 37);
    [Data.symbol drawAtPoint:point forWidth:50 withFont:secondaryFont minFontSize:14 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
    
    [[UIColor darkGrayColor] set];    
    point = CGPointMake(80, 38);
    [Data.sector drawAtPoint:point forWidth:200 withFont:secondaryFont minFontSize:14 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
    
    [[UIColor blackColor] set];
    point = CGPointMake(80, 37);
    [Data.sector drawAtPoint:point forWidth:200 withFont:secondaryFont minFontSize:14 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
}

- (void)dealloc 
{
    [data release];
    [_backgroundImage release];
    [Data release];
    
    [super dealloc];
}

@end