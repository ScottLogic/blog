//
//  ShinobiController.h
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ShinobiCharts/ShinobiChart.h>
#import "ShinobiDataSource.h"
#import "StockPriceDataContainer.h"
#import "ChartBaseViewController.h"

@interface ShinobiViewController : ChartBaseViewController
{
    ShinobiChart *_chart;
    ShinobiDataSource *_dataSource;
}

@end