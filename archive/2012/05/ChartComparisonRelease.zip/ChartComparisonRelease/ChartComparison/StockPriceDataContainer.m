//
//  StockPriceDataContainer.m
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StockPriceDataContainer.h"

@implementation StockPriceDataContainer

@synthesize stockData, priceDataArray, startDate;

-(void)dealloc
{
    [stockData release];
    [priceDataArray release];
    [startDate release];
    
    [super dealloc];
}

@end