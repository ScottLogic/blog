#import <UIKit/UIKit.h>
#import "tdgchart.h"

@interface IOSChartView : UIView
{
	TDGChart* chart;
}

@property(nonatomic, retain) TDGChart* chart;

-(void)setChart:(TDGChart *)c;
-(void)updateFrame;

@end