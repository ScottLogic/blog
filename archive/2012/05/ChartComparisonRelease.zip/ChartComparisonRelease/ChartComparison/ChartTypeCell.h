//
//  TableCell.h
//  ChartComparison
//
//  Created by Chris Grant on 26/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ChartTypeCellView;

@interface ChartTypeCell : UITableViewCell { }

@property (nonatomic, retain) ChartTypeCellView *CellView;

- (void)setChartTypeName:(NSString*)name andImage:(UIImage*)image;
- (void)redisplay;



@end