//
//  ChartBaseViewController.m
//  ChartComparison
//
//  Created by Chris Grant on 19/03/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "ChartBaseViewController.h"

@interface ChartBaseViewController ()

@end

@implementation ChartBaseViewController

-(id)initWithPriceContainer:(StockPriceDataContainer*)priceContainer;
{
    self = [super init];
    if (self)
    {
        _priceContainer = [priceContainer retain];
    }
    return self;
}

-(void)loadView
{
    [super loadView];
    [self setTitle:[NSString stringWithFormat:@"%@ (%@)", _priceContainer.stockData.name, _priceContainer.stockData.symbol]];
}
    
-(void)dealloc
{
    [_priceContainer release];

    [super dealloc];
}

@end