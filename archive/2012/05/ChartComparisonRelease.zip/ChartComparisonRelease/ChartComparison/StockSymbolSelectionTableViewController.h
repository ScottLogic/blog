//
//  StockSymbolSelectionTableViewController.h
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StockSymbolSelectionTableViewController : UITableViewController <UISearchBarDelegate>
{
    NSMutableArray *_stockList;
    NSMutableArray *_visibleStockList;
}

-(void)loadData;
-(void)loadDataWithOperation;
-(void)reloadTableWithStocks:(NSMutableArray*)stocks;

-(NSArray*)doSearch:(NSString*)searchText;

@end