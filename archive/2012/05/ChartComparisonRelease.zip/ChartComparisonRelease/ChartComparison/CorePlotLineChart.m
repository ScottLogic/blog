//
//  CPTTestAppScatterPlotController.m
//  CPTTestApp-iPhone
//
//  Created by Brad Larson on 5/11/2009.
//

#import "CorePlotLineChart.h"

@implementation CorePlotLineChart

@synthesize dataForPlot;

-(id)initWithHostingView:(CPTGraphHostingView *)hostingView andData:(StockPriceDataContainer*)data
{
    self = [super init];
    if ( self != nil )
    {
        dataForPlot = data;    
        _hostingView = hostingView;
    }
    return self;
}

-(void)initialisePlot
{
    // Create graph from theme
    _chart = [[CPTXYGraph alloc] initWithFrame:CGRectZero];
    _hostingView.collapsesLayers = NO; // Setting to YES reduces GPU memory usage, but can slow drawing/scrolling
    _hostingView.hostedGraph = _chart;
	
    _chart.paddingLeft = 0.0;
	_chart.paddingTop = 0.0;
	_chart.paddingRight = 0.0;
	_chart.paddingBottom = 0.0;
 
	// Create a blue plot line
	CPTScatterPlot *boundLinePlot = [[[CPTScatterPlot alloc] init] autorelease];
    CPTMutableLineStyle *lineStyle = [CPTMutableLineStyle lineStyle];
    lineStyle.miterLimit = 1.0f;
	lineStyle.lineWidth = 1.0f;
	lineStyle.lineColor = [CPTColor blueColor];
    boundLinePlot.dataLineStyle = lineStyle;
    boundLinePlot.identifier = @"Plot";
    boundLinePlot.dataSource = self;
	[_chart addPlot:boundLinePlot];
    
    // Set up the plot space and allow user interaction
    CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *)_chart.defaultPlotSpace;
    [plotSpace scaleToFitPlots:[NSArray arrayWithObject:boundLinePlot]];
    plotSpace.allowsUserInteraction = YES;

    // Setup Axis Properties
    CPTXYAxisSet *axisSet = (CPTXYAxisSet *)_chart.axisSet;
    CPTXYAxis *x = axisSet.xAxis;
    x.majorIntervalLength = CPTDecimalFromFloat(plotSpace.xRange.maxLimitDouble / 5);
    x.orthogonalCoordinateDecimal = CPTDecimalFromFloat(0);
    x.minorTicksPerInterval = 0;
    
    CPTXYAxis *y = axisSet.yAxis;
    y.majorIntervalLength = CPTDecimalFromFloat(plotSpace.yRange.maxLimitDouble / 20);
    y.orthogonalCoordinateDecimal = CPTDecimalFromFloat(0);
    y.minorTicksPerInterval = 0;
}

-(NSNumber*)numberForPlot:(CPTPlot*)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index 
{
    PriceData *value = [[dataForPlot priceDataArray] objectAtIndex:index];
    CGPoint point = CGPointMake([[dataForPlot priceDataArray] count] - [value index], [value close]);
    
    if (fieldEnum == CPTScatterPlotFieldX)
        return [NSNumber numberWithFloat:point.x];
    else
        return [NSNumber numberWithFloat:point.y];
}

-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot { return [[dataForPlot priceDataArray] count]; }

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation { return YES; }

-(void)dealloc 
{
    //[_chart release];
	//[dataForPlot release];
    
    [super dealloc];
}

@end