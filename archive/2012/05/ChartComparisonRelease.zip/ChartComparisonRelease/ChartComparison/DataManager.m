//
//  DataManager.m
//  ChartComparison
//
//  Created by Chris Grant on 15/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "DataManager.h"
#import "CHCSVParser.h"
#import "PriceData.h"
#import "StockData.h"

#import "CHCSVParser.h"
#import "CHCSVWriter.h"
#import "NSArray+CHCSVAdditions.h"
#import "NSString+CHCSVAdditions.h"

@implementation DataManager

-(id)init
{
    self = [super init];
    if(self)
    {
        _urlBuilder = [[UrlBuilder alloc] init];
        dateFormatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(NSMutableArray*)getDataForStock:(NSString*)symbol fromStartDate:(NSDate*)startDate;
{
    [_urlBuilder setFromDate:startDate];
    [_urlBuilder setSymbol:symbol];
    
    NSString *data = [self getDataStringFromURL:[_urlBuilder createUrl]];

    NSArray *pricesArray = [data CSVComponents];

    NSMutableArray *prices = [[NSMutableArray alloc] init];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];

    double i = 0;
    for (NSMutableArray *x in pricesArray)
    {
        PriceData *pd = [[PriceData alloc] init];
        
        [pd setDate:[dateFormatter dateFromString:[x objectAtIndex:0]]];
        [pd setIndex:i];
        [pd setOpen:[[x objectAtIndex:1] doubleValue]];
        [pd setHigh:[[x objectAtIndex:2] doubleValue]];
        [pd setLow:[[x objectAtIndex:3] doubleValue]];
        [pd setClose:[[x objectAtIndex:4] doubleValue]];
        [pd setVolume:[[x objectAtIndex:5] doubleValue]];
        [pd setAdjClose:[[x objectAtIndex:6] doubleValue]];
        
        i++;
        [prices addObject:pd];
        [pd release];
    }
    
    if([prices count] > 0)
    {
        // The first object is the headers row. We don't want that as it won't have any data.
        [prices removeObjectAtIndex:0];
    }
    
    return [prices autorelease];
}

-(NSString*)getDataStringFromURL:(NSString*)url;
{
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    return [[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] autorelease];
}

-(NSArray*)getStockList
{
    NSString *response = [self getDataStringFromURL:@"http://www.nasdaq.com/screening/companies-by-name.aspx?marketcap=Large-cap&render=download"];
    NSArray *stockArray = [response CSVComponents];
    
    NSMutableArray *symbolList = [[NSMutableArray alloc] init];

    for (NSMutableArray *x in stockArray)
    {
        if ([x count] > 1)
        {
            StockData *sd = [[StockData alloc] init];
            [sd setSymbol:[x objectAtIndex:0]];
            [sd setName:[x objectAtIndex:1]];
            [sd setSector:[x objectAtIndex:6]];
            [sd setUrl:[x objectAtIndex:8]];
            [symbolList addObject:sd];
            [sd release];
        }
    }
    
    if([symbolList count] > 0)
    {
        // The first object is the headers row. We don't want that as it won't have any data.
        [symbolList removeObjectAtIndex:0];
    }
    
    return [symbolList autorelease];
}

-(void)dealloc
{
    [_urlBuilder release];
    [dateFormatter release];
    
    [super dealloc];
}

@end