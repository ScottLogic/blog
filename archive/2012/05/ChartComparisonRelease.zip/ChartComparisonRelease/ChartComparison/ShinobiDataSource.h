//
//  LineChartDataSource.h
//  LineChart
//
//  Copyright 2011 Scott Logic Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShinobiCharts/ShinobiChart.h>

@interface ShinobiDataSource : NSObject <SChartDatasource>

@property(nonatomic, retain) NSMutableArray *Data;

@end