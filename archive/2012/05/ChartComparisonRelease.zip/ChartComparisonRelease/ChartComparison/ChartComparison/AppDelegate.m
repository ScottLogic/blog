//
//  AppDelegate.m
//  ChartComparison
//
//  Created by Chris Grant on 15/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "AppDelegate.h"
#import "StockSymbolSelectionTableViewController.h"

@implementation AppDelegate

@synthesize window = _window;
@synthesize tabBarController = _tabBarController;

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [self setWindow:window];
    [_window setBackgroundColor:[UIColor darkGrayColor]];
    [window release];
    
    // Override point for customization after application launch.
    StockSymbolSelectionTableViewController *homeNav = [[StockSymbolSelectionTableViewController alloc] init];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:homeNav];
    [homeNav release];

    [_window setRootViewController:navigationController];
    [navigationController release];
	
    [_window makeKeyAndVisible];
	[_window layoutSubviews];
    
    if ([UINavigationBar respondsToSelector: @selector(appearance)])
    {
        UIFont *font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:20];
        NSDictionary *attr = [[NSDictionary alloc] initWithObjectsAndKeys:font, UITextAttributeFont, nil];
        [[UINavigationBar appearance] setTitleTextAttributes:attr];
        [attr release];
        [[UINavigationBar appearance] setTintColor:[UIColor darkGrayColor]];
        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"headerBar.png"] forBarMetrics:UIBarMetricsDefault];
    }
	return YES;
}

@end