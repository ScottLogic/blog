//
//  AppDelegate.h
//  ChartComparison
//
//  Created by Chris Grant on 15/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHCSVParser.h"
#import "CHCSVWriter.h"
#import "NSArray+CHCSVAdditions.h"
#import "NSString+CHCSVAdditions.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UITabBarController *tabBarController;

@end