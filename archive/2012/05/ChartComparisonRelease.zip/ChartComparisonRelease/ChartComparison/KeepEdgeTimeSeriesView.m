#import "KeepEdgeTimeSeriesView.h"
#import "TimeSeriesChart.h"

@implementation KeepEdgeTimeSeriesView

-(id)initWithFrame:(CGRect)frame andData:(StockPriceDataContainer*)data
{
	if (self = [super initWithFrame:frame])
    {
        _data = data;
    }
	self->demoIdx = 1;
    return self;
}

-(void)drawRect:(CGRect)rect
{
    CGContextRef aContext = UIGraphicsGetCurrentContext();	
	CGRect imageArea = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
	[TimeSeriesChart processDemoWithContext: aContext area: imageArea andData:_data];
}

-(void)dealloc
{
    [super dealloc];
}

@end
