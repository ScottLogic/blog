//
//  UrlBuilder.h
//  ChartComparison
//
//  Created by Chris Grant on 22/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UrlBuilder : NSObject
{
    NSDateFormatter *_formatter;
}

@property (nonatomic, retain) NSString *symbol;
@property (nonatomic, retain) NSDate *fromDate;
@property (nonatomic, retain) NSDate *toDate;
@property (nonatomic, retain) NSString *interval;

-(NSString*)createUrlFromSymbol:(NSString*)symbol ToDate:(NSDate*)to FromDate:(NSDate*)from andInterval:(NSString*)interval;

-(NSString*)createUrl;

@end