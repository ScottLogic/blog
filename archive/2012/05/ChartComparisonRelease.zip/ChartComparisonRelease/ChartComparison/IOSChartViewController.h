#import <UIKit/UIKit.h>
#import "tdgChart.h"
#import "IOSChartView.h"
#import "StockPriceDataContainer.h"
#import "ChartBaseViewController.h"

@interface IOSChartViewController : ChartBaseViewController 
{
    TDGChart* _chart;
	IOSChartView* chartView;
    UIView* selectionView;
    CGRect windowChartFrame;
}

-(void)setData;
-(void)updateChartFrame;

@end