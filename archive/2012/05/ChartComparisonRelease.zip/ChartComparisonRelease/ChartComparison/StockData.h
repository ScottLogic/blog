//
//  StockData.h
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StockData : NSObject

@property(nonatomic, retain) NSString *symbol;
@property(nonatomic, retain) NSString *name;
@property(nonatomic, retain) NSString *sector;
@property(nonatomic, retain) NSString *url;

@end