//
//  TableCell.m
//  ChartComparison
//
//  Created by Chris Grant on 26/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "ChartTypeCell.h"
#import "ChartTypeCellView.h"

@implementation ChartTypeCell

@synthesize CellView;

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)reuseIdentifier 
{    
	if (self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier])
    {
		CGRect messageFrame = CGRectMake(0.0, 0.0,  768, self.frame.size.height);
		CellView = [[ChartTypeCellView alloc] initWithFrame:messageFrame];
		CellView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
		[self.contentView addSubview:CellView];
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self setBackgroundColor:[UIColor whiteColor]];
	}
	return self;
}

-(void)setChartTypeName:(NSString*)name andImage:(UIImage*)image;
{
    [CellView setName:name];
    [CellView setImage:image];
}

-(void)redisplay
{
	[CellView setNeedsDisplay];
}

-(void)dealloc 
{
	[CellView release];
    [super dealloc];
}

@end