//
//  KeepEdgeViewController.m
//  ChartComparison
//
//  Created by Chris Grant on 04/02/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "KeepEdgeViewController.h"
#import "KeepEdgeTimeSeriesView.h"

@implementation KeepEdgeViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
	
	KeepEdgeTimeSeriesView *cv = [[KeepEdgeTimeSeriesView alloc] initWithFrame:self.view.frame andData:_priceContainer];
	self.view = cv;
	[cv release];
}

@end