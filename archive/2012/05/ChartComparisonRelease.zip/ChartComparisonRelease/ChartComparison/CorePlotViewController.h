//
//  TestViewController.h
//  ChartComparison
//
//  Created by Chris Grant on 29/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePlotLineChart.h"
#import "StockPriceDataContainer.h"
#import "ChartBaseViewController.h"

@interface CorePlotViewController : ChartBaseViewController
{
    CPTGraphHostingView *_graphHostingView;
    CorePlotLineChart *_plot;
}

-(void)loadChart:(StockPriceDataContainer*)array;

@end