//
//  UrlBuilder.m
//  ChartComparison
//
//  Created by Chris Grant on 22/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "UrlBuilder.h"

@implementation UrlBuilder

@synthesize symbol, fromDate, toDate, interval;

-(id)init
{
    self = [super init];
    if(self)
    {
        // Set some defaults.
        toDate = [[NSDate date] retain]; 

        int daysToAdd = -10000;
        NSDateComponents *components = [[[NSDateComponents alloc] init] autorelease];
        [components setDay:daysToAdd];
        NSCalendar *gregorian = [[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar] autorelease];
        
        fromDate = [[gregorian dateByAddingComponents:components toDate:toDate options:0] retain];
        interval = @"d";
        symbol = @"GOOG";
        
        _formatter = [[NSDateFormatter alloc] init];
    }
    return self;
}

-(NSString*)createUrlFromSymbol:(NSString*)stockSymbol ToDate:(NSDate*)to FromDate:(NSDate*)from andInterval:(NSString*)intervalString
{
    self.symbol = stockSymbol;
    self.toDate = to;
    self.fromDate = from;
    self.interval = intervalString;
    
    return [self createUrl];
}

// Creates a new URL to accessing the Yahoo finance API.
// See this URL for API description: http://code.google.com/p/yahoo-finance-managed/wiki/csvHistQuotesDownload
-(NSString*)createUrl
{
    // Parse the year
    [_formatter setDateFormat:@"YYYY"];
    NSString *fromYearString = [_formatter stringFromDate:fromDate];
    NSString *toYearString = [_formatter stringFromDate:toDate];
    
    // Parse the Months. API dictates that you need to subtract 1 from the month.
    [_formatter setDateFormat:@"MM"];
    NSString *fromMonthString = [_formatter stringFromDate:fromDate];
    int fromMonthInt = [fromMonthString intValue];
    fromMonthString = [NSString stringWithFormat:@"%i", fromMonthInt - 1];
    
    NSString *toMonthString = [_formatter stringFromDate:toDate];
    int toMonthInt = [toMonthString intValue];
    toMonthString = [NSString stringWithFormat:@"%i", toMonthInt - 1];
    
    // Parse the day
    [_formatter setDateFormat:@"dd"];
    NSString *fromDayString = [_formatter stringFromDate:fromDate];
    NSString *toDayString = [_formatter stringFromDate:toDate];

    // Create a new url based on the parsed values and the symbol and interval.
    NSString *urlString = [NSString stringWithFormat:@"http://ichart.yahoo.com/table.csv?s=%@&a=%@&b=%@&c=%@&d=%@&e=%@&f=%@&g=%@&ignore=.csv", symbol, fromMonthString, fromDayString, fromYearString, toMonthString, toDayString, toYearString, interval];

    return urlString;
}

-(void)dealloc
{
    [_formatter release];
    [symbol release];
    //[fromDate release];
    [toDate release];
    [interval release];
    
    [super dealloc];
}

@end