//
//  PriceData.m
//  ChartComparison
//
//  Created by Chris Grant on 16/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "PriceData.h"

@implementation PriceData

@synthesize date, index, open, high, low, close, volume, adjClose;

-(void)dealloc
{
    [date release];
    
    [super dealloc];
}

@end