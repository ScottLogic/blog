#import "IOSChartView.h"

@implementation IOSChartView

@synthesize chart;

-(id)initWithFrame:(CGRect)f {
    self = [super initWithFrame:f];
    return self;
}

-(void)setChart:(TDGChart *)c 
{
    chart = c;
    [self updateFrame];
}

-(void)updateFrame
{
    chart.backgroundFrameSize = self.frame;
}

-(void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    if(chart != nil)
    {
        [chart draw:UIGraphicsGetCurrentContext()];
    }
}

@end