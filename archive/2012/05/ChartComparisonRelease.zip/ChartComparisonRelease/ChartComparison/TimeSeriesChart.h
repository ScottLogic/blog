#import <Foundation/Foundation.h>
#import "StockPriceDataContainer.h"

@interface TimeSeriesChart : NSObject { }

+(void)processDemoWithContext:(CGContextRef)aContext area:(CGRect)anImageArea andData:(StockPriceDataContainer*)data;

@end
