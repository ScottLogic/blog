#import "TimeSeriesChart.h"
#import "IPCGlobal.h"
#import "IPCTitle.h"
#import "IPCLegend.h"
#import "IPCTimeAxis.h"
#import "IPCValueAxis.h"
#import "IPCRenderTimeSeries.h"
#import "IPCTimeSeriesChart.h"
#import "DTCStroke.h"
#import "DTCYear.h"
#import "DTCMonth.h"
#import "DTCDay.h"
#import "DTCTimeSeries.h"
#import "DTCTimeSeriesCollection.h"

@interface TimeSeriesChart (Private)

+(void) getLegendWithLegend: (IPCLegend *) aLegend;
+(void) getDomainAxisWithAxis: (IPCTimeAxis *) anAxis;
+(void) getValueAxisWithAxis: (IPCValueAxis *) anAxis;
+(void) getRenderWithRender: (IPCRenderTimeSeries *) aRender;

@end

@implementation TimeSeriesChart

+(void)processDemoWithContext:(CGContextRef)aContext area:(CGRect)anImageArea andData:(StockPriceDataContainer*)data;
{
	IPCTimeSeriesChart *pChart = [IPCTimeSeriesChart new];
	[TimeSeriesChart getDomainAxisWithAxis: [pChart getTimeDomainAxis]];
	[TimeSeriesChart getValueAxisWithAxis: [pChart getRangeAxis]];
	[TimeSeriesChart getRenderWithRender: (IPCRenderTimeSeries *)[pChart getRender]];
    
    // Create Dataset;
    DTCTimeSeries *t1 = [[DTCTimeSeries alloc] initWithName: (id <DTCIComparable>) @"Date"
													 domain: @"Day"
													  range: @"Value"];
    NSDate *theDate;
	
    for (PriceData *pd in [data priceDataArray])
    {
        @try
        {
            theDate = [pd date];
            DTCDay *pDay = [[DTCDay alloc] initWithDate:theDate];
            [t1 addWithPeriod:pDay doubleValue:[pd close]];
        }
        @catch (NSException *e)
        {
            NSLog(@"This date: %@, could not be added. Skipped.", theDate);
        }
	}
	
	DTCTimeSeriesCollection *pDataset = [[DTCTimeSeriesCollection alloc] initWithSeries: t1];
	[t1 release];    
    
	[pChart drawChartWithContext: aContext area: anImageArea dataset: pDataset];
	[pDataset release];
}

@end

@implementation TimeSeriesChart (Private)

+ (void) getLegendWithLegend: (IPCLegend *) aLegend
{
	[aLegend setTextColor: ([UIColor darkGrayColor])];
	[aLegend setTextFont: ([UIFont fontWithName: @"ArialMT" size: 8])];
	[aLegend setPlacement: kIPCPlacementBottom];
	
	[aLegend setDisplayBorder: FALSE];
	[aLegend setBorderColor: ([UIColor lightGrayColor])];
	[aLegend setBorderSize: (3)];
	[aLegend setBackgroundColor: ([UIColor whiteColor])];
}

+ (void) getDomainAxisWithAxis: (IPCTimeAxis *) anAxis
{
	[anAxis setTitle: @"Time"];
	[anAxis setTitleColor: ([UIColor darkGrayColor])];
	[anAxis setTitleFont: ([UIFont fontWithName: @"ArialMT" size: 8])];
	
	[anAxis setShowAxisLine: TRUE];
	[anAxis setShowMajorGridLines: FALSE];
	[anAxis setShowTickLabels: TRUE];
	[anAxis setShowMajorTickMark: FALSE];
    [anAxis setTimeFormat:@"dd/MM/yyyy"];
	[anAxis setTickLabelsColor: ([UIColor blackColor])];
	[anAxis setTickLabelsFont: ([UIFont fontWithName: @"ArialMT" size: 8])];
}

+ (void) getValueAxisWithAxis: (IPCValueAxis *) anAxis
{
	[anAxis setTitle: @"Value"];
	[anAxis setTitleColor: ([UIColor darkGrayColor])];
	[anAxis setTitleFont: ([UIFont fontWithName: @"ArialMT" size: 8])];
	
	[anAxis setShowAxisLine: TRUE];
	[anAxis setShowMajorGridLines: FALSE];
	[anAxis setShowTickLabels: TRUE];
	[anAxis setShowMajorTickMark: TRUE];
	[anAxis setTickLabelsColor: ([UIColor blackColor])];
	[anAxis setTickLabelsFont: ([UIFont fontWithName: @"ArialMT" size: 8])];
	
	[anAxis setAutoRange: TRUE];
	[anAxis setMajorUnit: 50];
	[anAxis setAxisPlacement: kIPCBOTTOM_OR_LEFT];
}

+ (void) getRenderWithRender: (IPCRenderTimeSeries *) aRender
{
	[aRender setShowLine: TRUE];
	DTCStroke *pStroke = [[DTCStroke alloc] initWithWidth: 3 endCap: DTC_STROKE_CAP_SQUARE lineJoin: DTC_STROKE_JOIN_BEVEL];
	[aRender setLineStroke: pStroke];
	[pStroke release];
	
	[aRender setShowShapes: TRUE];
	[aRender setShapeFilled: TRUE];
}

@end