//
//  StartDateSelectorViewController.m
//  ChartComparison
//
//  Created by Chris Grant on 29/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StartDateSelectorViewController.h"
#import "ChartTypeSelectionTableViewController.h"

@implementation StartDateSelectorViewController

-(id)initWithStockPriceContainer:(StockPriceDataContainer*)priceContainer
{
    self = [super init];
    if (self) 
    {
        _priceContainer = [priceContainer retain];
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setDateFormat:@"dd/MM/yyyy"];
    }
    return self;
}

-(void)loadView
{
    [super loadView];
    [self setTitle:@"Start Date"];

    UIImage *bg;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        bg = [UIImage imageNamed:@"background_iPad.png"];
    else
        bg = [UIImage imageNamed:@"background.png"];
    
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:bg]];

    _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 40, self.view.frame.size.width - 20, 40)];
    [_dateLabel setTextAlignment:UITextAlignmentCenter];
    [_dateLabel setBackgroundColor:[UIColor clearColor]];
    [_dateLabel setTextColor:[UIColor whiteColor]];
    [_dateLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:22]];
    [_dateLabel setText:@"Please select a date..."];
    [self.view addSubview:_dateLabel];
    
    CGRect pickerFrame = CGRectMake(0, 180, 0, 0);
    UIDatePicker *datePicker = [[UIDatePicker alloc] initWithFrame:pickerFrame];
    [datePicker setCenter:CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height - 151)];
    [datePicker setMaximumDate:[NSDate date]];
    [datePicker setDatePickerMode:UIDatePickerModeDate];
    [datePicker addTarget:self action:@selector(pickerChanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:datePicker];
    [datePicker release];
    
    // Auto Stretch Button
    _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_nextButton setTitle:@"Next" forState:UIControlStateNormal];
    
    UILabel *sendButtonLabel = [_nextButton titleLabel];
    [sendButtonLabel setShadowColor:[UIColor blackColor]];
    [sendButtonLabel setShadowOffset:CGSizeMake(0.0f, 1.0f)];
    [sendButtonLabel setText:@"Next"];
    [sendButtonLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:16]];
    [sendButtonLabel setTextColor:[UIColor whiteColor]];
    
    UIImage *buttonBackgroundImage = [UIImage imageNamed:@"button.png"];
    UIImage *stretchedBackground = [buttonBackgroundImage stretchableImageWithLeftCapWidth:8 topCapHeight:0];
    
    //sendButton is declared as an instance variable UIButton in the interface
    [_nextButton setBackgroundImage:stretchedBackground forState:UIControlStateNormal];
    [_nextButton setFrame:CGRectMake(10, 120, self.view.frame.size.width - 20, 40)];
    [_nextButton addTarget:self action:@selector(nextButtonTouched) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_nextButton];
}

-(void)nextButtonTouched
{
    [_priceContainer setStartDate:_selectedDate];
    ChartTypeSelectionTableViewController *chartTypeSelector = [[ChartTypeSelectionTableViewController alloc] initWithStockPriceContainer:_priceContainer];
    [self.navigationController pushViewController:chartTypeSelector animated:YES];
    [chartTypeSelector release];
}

-(void)pickerChanged:(id)sender
{
    _selectedDate = [sender date];
    [_dateLabel setText:[_dateFormatter stringFromDate:_selectedDate]];
}

-(void)dealloc
{
    [_priceContainer release];
    [_selectedDate release];
    [_dateFormatter release];
    [_dateLabel release];
    
    [super dealloc];
}

@end