#import "IOSChartViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation IOSChartViewController

-(void)loadView
{    
    [super loadView];
    
	chartView = [[IOSChartView alloc] initWithFrame:self.view.frame];
	[chartView setCenter:self.view.center];
    _chart = [[TDGChart alloc] init];
    _chart.backgroundFrame.fill.color = [UIColor whiteColor];
    _chart.legend.legendArea.fill.color = [UIColor whiteColor];
    _chart.subtitle.visible = YES;
	_chart.chartType = BLAChart;
    _chart.sizeOfDataPoint = 1;
    _chart.backgroundFrameSize = chartView.frame;
    _chart.legend.visible = NO;
    _chart.title.visible = NO;
    _chart.footnote.visible = NO;
    _chart.subtitle.visible = NO;
    _chart.numericY1Axis.title.visible = NO;
    _chart.ordinalAxis.title.visible = NO;
    _chart.ordinalAxis.useAutoLayout = YES;
    [chartView setChart:_chart];
    [self setData];
    [self.view addSubview:chartView];

    [self updateChartFrame];
}

-(void)setData
{
	id<TDGDataProtocol> data = chartView.chart.dataManager;
	
    chartView.chart.seriesCount = 1;
    chartView.chart.groupCount = [[_priceContainer priceDataArray] count];
    [[[chartView chart]seriesAtIndex:0] setFormat:1];

    for(PriceData *pd in [_priceContainer priceDataArray])
        [data setYPoint:0 group:[[_priceContainer priceDataArray] count] - [pd index] data:[pd close]];
}

- (void)updateChartFrame
{
    chartView.frame = self.view.frame;
    [chartView setNeedsDisplay];
    [chartView updateFrame];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self updateChartFrame];
}

-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    [self updateChartFrame];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation { return YES; }

-(void)dealloc
{
    [_chart release];
    [chartView release];
    [selectionView release];

    [super dealloc];
}

@end