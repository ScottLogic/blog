
//  StockPriceDataContainer.h
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StockData.h"
#import "PriceData.h"

@interface StockPriceDataContainer : NSObject

@property(nonatomic, retain) StockData *stockData;
@property(nonatomic, retain) NSMutableArray *priceDataArray;
@property(nonatomic, retain) NSDate *startDate;

@end