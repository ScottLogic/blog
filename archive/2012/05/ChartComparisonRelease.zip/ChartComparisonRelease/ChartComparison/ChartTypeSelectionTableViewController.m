//
//  HomeNavigationTable.m
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "ChartTypeSelectionTableViewController.h"
#import "ShinobiViewController.h"
#import "StockPriceDataContainer.h"
#import "ChartTypeCell.h"
#import "CorePlotViewController.h"
#import "IOSChartViewController.h"
#import "KeepEdgeViewController.h"

#define ROW_HEIGHT 65

@implementation ChartTypeSelectionTableViewController

-(id)initWithStockPriceContainer:(StockPriceDataContainer*)priceContainer;
{
    self = [super init];
    if (self) 
    {
        [self setTitle:@"Chart Type"];
        [[self tableView] setScrollEnabled:NO];
        [[self tableView] setAllowsSelection:NO];

        self.tableView.rowHeight = ROW_HEIGHT;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        UIColor *background = [UIColor darkGrayColor];
        UIView *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.width)];
        imageView.backgroundColor = background;
        [self.tableView setBackgroundView:imageView];
        [imageView release];

        NSString* corePlot = @"Core Plot";
        NSString* shinobi = @"Shinobi Charts";
        NSString* iOS = @"iOS Charts";
        NSString* keepEdge = @"KeepEdge";
        
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setDateFormat:@"dd/MM/yyyy"];
        
        _items = [[NSArray alloc] initWithObjects:corePlot, shinobi, iOS, keepEdge, nil];
        _priceContainer = [priceContainer retain];
        
        loaded = NO;
        loading = NO;
        
        [self loadData];
    }
    return self;
}

-(void)loadData
{
    loading = YES;
    
    NSOperationQueue *queue = [NSOperationQueue new];
    NSInvocationOperation *operation = [[NSInvocationOperation alloc]
                                        initWithTarget:self
                                        selector:@selector(loadDataWithOperation:)
                                        object:[[_priceContainer stockData] symbol]];
    [queue addOperation:operation];
    [operation release];
    [queue release];
}

-(void)loadDataWithOperation:(NSString*)symbol
{
    DataManager *dm = [[DataManager alloc] init];

    NSMutableArray *array = [dm getDataForStock:symbol fromStartDate:[_priceContainer startDate]];
    
    if([array count] > 0)
        [self performSelectorOnMainThread:@selector(loadStockPrices:) withObject:array waitUntilDone:YES];
    else
        [self performSelectorOnMainThread:@selector(errorLoading) withObject:nil waitUntilDone:YES];
    
    [dm release];
}

-(void)errorLoading
{
    [_countLabel setText:@"Error Loading data."];
    [_spinner stopAnimating];
}

-(void)loadStockPrices:(NSMutableArray*)stocks
{
    [_priceContainer setPriceDataArray:[stocks retain]];
    
    if([stocks count] > 0)
    {
        loaded = YES;
        loading = NO;
        [[self tableView] setAllowsSelection:YES];
        [_spinner stopAnimating];
    }
    else
    {
        [self errorLoading];
    }
    [self refreshView];
}

-(void)loadView
{
    [super loadView];
    UIView *dataStatsView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 131)];
    
    UIImage *headerImage;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        headerImage = [UIImage imageNamed:@"chartTypeHeader_iPad.png"];
    else
        headerImage = [UIImage imageNamed:@"chartTypeHeader.png"];
    
    [dataStatsView setBackgroundColor:[UIColor colorWithPatternImage:headerImage]];
    
    _stockNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 300, 25)];
    [_stockNameLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:16.0]];
    [_stockNameLabel setTextColor:[UIColor whiteColor]];
    [_stockNameLabel setBackgroundColor:[UIColor clearColor]];
    [dataStatsView addSubview:_stockNameLabel];
    
    _stockSectorLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 26, 300, 25)];
    [_stockSectorLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Italic" size:16.0]];
    [_stockSectorLabel setTextColor:[UIColor whiteColor]];
    [_stockSectorLabel setBackgroundColor:[UIColor clearColor]];
    [dataStatsView addSubview:_stockSectorLabel];
    
    _stockSymbolLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 45, 300, 25)];
    [_stockSymbolLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Medium" size:12.0]];
    [_stockSymbolLabel setTextColor:[UIColor whiteColor]];
    [_stockSymbolLabel setBackgroundColor:[UIColor clearColor]];
    [dataStatsView addSubview:_stockSymbolLabel];
    
    _countLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 70, 300, 25)];
    [_countLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Medium" size:12.0]];
    [_countLabel setTextColor:[UIColor whiteColor]];
    [_countLabel setBackgroundColor:[UIColor clearColor]];
    [dataStatsView addSubview:_countLabel];
    
    _spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [_spinner setCenter:CGPointMake(20, 83)];
    [_spinner startAnimating];
    [dataStatsView addSubview:_spinner];
    
    _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 90, 300, 20)];
    [_dateLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Medium" size:12.0]];
    [_dateLabel setTextColor:[UIColor whiteColor]];
    [_dateLabel setBackgroundColor:[UIColor clearColor]];
    [dataStatsView addSubview:_dateLabel];
    
    [[self tableView] setTableHeaderView:dataStatsView];
    [dataStatsView release];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self refreshView];
}

-(void)refreshView
{
    [_stockNameLabel setText:[[_priceContainer stockData] name]];
    [_stockSectorLabel setText:[[_priceContainer stockData] sector]];
    [_stockSymbolLabel setText:[[_priceContainer stockData] symbol]];
    
    if(loaded)
    {
        [_countLabel setText:[NSString stringWithFormat:@"%i Price Points", [[_priceContainer priceDataArray] count]]];

        NSDate *startDate = [[[_priceContainer priceDataArray] objectAtIndex:[[_priceContainer priceDataArray] count] - 1] date];
        NSDate *endDate = [[[_priceContainer priceDataArray] objectAtIndex:0] date];
        [_dateLabel setText:[NSString stringWithFormat:@"Data from %@ to %@",
                             [_dateFormatter stringFromDate:startDate], 
                             [_dateFormatter stringFromDate:endDate]]];
        
        numberOfRows = [_items count];
    }
    else
    {
        [_countLabel setText:@"        Loading data..."];
        numberOfRows = 0;
    }
    
    [[self tableView] reloadData];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	ChartTypeCell *tableCell = (ChartTypeCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (tableCell == nil)
    {
		tableCell = [[[ChartTypeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		tableCell.frame = CGRectMake(0.0, 0.0, self.tableView.bounds.size.width, self.tableView.bounds.size.height);
    }
    
    if(indexPath.row == 0)
        [tableCell setChartTypeName:[_items objectAtIndex:indexPath.row] andImage:[UIImage imageNamed:@"corePlotIcon.png"]];
    else if (indexPath.row == 1)
        [tableCell setChartTypeName:[_items objectAtIndex:indexPath.row] andImage:[UIImage imageNamed:@"shinobiIcon.png"]];
    else if (indexPath.row == 2)
        [tableCell setChartTypeName:[_items objectAtIndex:indexPath.row] andImage:[UIImage imageNamed:@"iosChart.png"]];
    else if (indexPath.row == 3)
        [tableCell setChartTypeName:[_items objectAtIndex:indexPath.row] andImage:[UIImage imageNamed:@"keepEdge.png"]];
    
	return tableCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *chartTypeViewController;
    
    if(indexPath.row == 0)
        chartTypeViewController = [[CorePlotViewController alloc] initWithPriceContainer:_priceContainer];
    else if (indexPath.row == 1)
        chartTypeViewController = [[ShinobiViewController alloc] initWithPriceContainer:_priceContainer];
    else if (indexPath.row == 2)
        chartTypeViewController = [[IOSChartViewController alloc] initWithPriceContainer:_priceContainer];
    else
        chartTypeViewController = [[KeepEdgeViewController alloc] initWithPriceContainer:_priceContainer];
    
    [self.navigationController pushViewController:chartTypeViewController animated:YES];
    [chartTypeViewController release];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 1; }

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return numberOfRows; }

-(void)dealloc
{
    [_items release];
    [_priceContainer release];
    [_dateFormatter release];
    
    [_stockNameLabel release];
    [_stockSectorLabel release];
    [_stockSymbolLabel release];
    [_countLabel release];
    [_dateLabel release];
    [_spinner release];
    
    [super dealloc];
}

@end