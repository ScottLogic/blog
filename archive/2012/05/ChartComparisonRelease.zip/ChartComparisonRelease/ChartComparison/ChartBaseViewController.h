//
//  ChartBaseViewController.h
//  ChartComparison
//
//  Created by Chris Grant on 19/03/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StockPriceDataContainer.h"

@interface ChartBaseViewController : UIViewController
{
    StockPriceDataContainer *_priceContainer;
}

-(id)initWithPriceContainer:(StockPriceDataContainer*)priceContainer;

@end