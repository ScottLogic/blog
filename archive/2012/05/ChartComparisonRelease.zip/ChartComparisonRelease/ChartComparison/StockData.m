//
//  StockData.m
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StockData.h"

@implementation StockData

@synthesize symbol, name, sector, url;

-(void)dealloc
{
    [symbol release];
    [name release];
    [sector release];
    [url release];
    
    [super dealloc];
}

@end