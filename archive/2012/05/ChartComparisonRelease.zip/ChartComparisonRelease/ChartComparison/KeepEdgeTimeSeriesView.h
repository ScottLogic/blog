#import <UIKit/UIKit.h>
#import "StockPriceDataContainer.h"

@interface KeepEdgeTimeSeriesView : UIView {
@private
	BOOL mouseSwiped;
	BOOL isPainting;
	CGPoint prevOrgPoint;
	CGPoint startPoint;
	CGPoint stopPoint;
	int demoIdx;
    StockPriceDataContainer *_data;
}

-(id)initWithFrame:(CGRect)frame andData:(StockPriceDataContainer*)data;

@end