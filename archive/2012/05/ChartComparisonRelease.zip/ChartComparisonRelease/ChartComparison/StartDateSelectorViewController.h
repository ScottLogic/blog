//
//  StartDateSelectorViewController.h
//  ChartComparison
//
//  Created by Chris Grant on 29/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StockPriceDataContainer.h"

@interface StartDateSelectorViewController : UIViewController
{
    StockPriceDataContainer *_priceContainer;
    NSDate *_selectedDate;
    NSDateFormatter *_dateFormatter;
    
    UILabel *_dateLabel;
    UIButton *_nextButton;
}

-(id)initWithStockPriceContainer:(StockPriceDataContainer*)priceContainer;
-(void)nextButtonTouched;

@end