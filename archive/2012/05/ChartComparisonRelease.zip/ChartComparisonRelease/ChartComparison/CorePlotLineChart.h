//
//  CPTTestAppScatterPlotController.h
//  CPTTestApp-iPhone
//
//  Created by Brad Larson on 5/11/2009.
//

#import <UIKit/UIKit.h>
#import "StockPriceDataContainer.h"


@interface CorePlotLineChart : UIViewController <CPTPlotDataSource>
{
	CPTXYGraph *_chart;
	StockPriceDataContainer *dataForPlot;
	CPTGraphHostingView *_hostingView;
}

-(id)initWithHostingView:(CPTGraphHostingView *)hostingView andData:(StockPriceDataContainer*)data;

-(void)initialisePlot;

@property(readwrite, retain, nonatomic) StockPriceDataContainer *dataForPlot;

@end