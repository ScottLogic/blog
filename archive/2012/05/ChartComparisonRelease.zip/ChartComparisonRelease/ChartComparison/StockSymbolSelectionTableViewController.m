//
//  StockSymbolSelectionTableViewController.m
//  ChartComparison
//
//  Created by Chris Grant on 25/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "StockSymbolSelectionTableViewController.h"
#import "DataManager.h"
#import "StockData.h"
#import "StartDateSelectorViewController.h"
#import "StockPriceDataContainer.h"
#import "StockSymbolCell.h"

@implementation StockSymbolSelectionTableViewController

#define ROW_HEIGHT 65

- (id)init
{
    self = [super init];
    if (self)
    {
        _visibleStockList = [[NSMutableArray arrayWithArray:_stockList] retain];
        
        self.tableView.rowHeight = ROW_HEIGHT;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        UIColor *background = [UIColor darkGrayColor];
        UIView *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 480)];
        imageView.backgroundColor = background;
        [self.tableView setBackgroundView:imageView];
        [imageView release];
        [self loadData];
    }
    return self;
}

-(void)loadView
{
    [super loadView];
    [self setTitle:@"Stocks"];
    
    // Add the search bar
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:
                              CGRectMake(0, 0, self.tableView.frame.size.width, 40)];
    [searchBar setBackgroundColor:[UIColor blackColor]];
    [searchBar setTintColor:[UIColor darkGrayColor]];
    [searchBar setDelegate:self];
    [[self tableView] setTableHeaderView:searchBar];
    [searchBar release];
    
    // Add a refresh button
    UIBarButtonItem *refreshItem = [[UIBarButtonItem alloc] 
                                    initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh 
                                    target:self 
                                    action:@selector(loadData)];
    self.navigationItem.rightBarButtonItem = refreshItem;
    [refreshItem release];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	StockSymbolCell *tableCell = (StockSymbolCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (tableCell == nil)
    {
		tableCell = [[[StockSymbolCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		tableCell.frame = CGRectMake(0.0, 0.0, self.tableView.bounds.size.width, 30);
	}
    
    StockData *sd = [_visibleStockList objectAtIndex:indexPath.row];
    [tableCell setStockData:sd];
    
	return tableCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    StockPriceDataContainer *priceContainer = [[StockPriceDataContainer alloc] init];
    [priceContainer setStockData:[_visibleStockList objectAtIndex:indexPath.row]];
    
    StartDateSelectorViewController *startDateSelector = [[StartDateSelectorViewController alloc] initWithStockPriceContainer:priceContainer];
    [[self navigationController] pushViewController:startDateSelector animated:YES];
    [priceContainer release];
    [startDateSelector release];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView setContentOffset:CGPointMake(0,40)];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 1; }

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return [_visibleStockList count]; }

-(void)loadData
{
    NSOperationQueue *queue = [NSOperationQueue new];
    NSInvocationOperation *operation = [[NSInvocationOperation alloc] 
                                        initWithTarget:self 
                                        selector:@selector(loadDataWithOperation)object:nil];
    [queue addOperation:operation];
    [operation release];
    [queue release];
}

-(void)loadDataWithOperation
{
    DataManager *_dm = [[DataManager alloc] init];
    NSMutableArray *list = [[_dm getStockList] retain];
    
    if([list count] > 0)
    {
        [self performSelectorOnMainThread:@selector(reloadTableWithStocks:) withObject:list waitUntilDone:YES];
    }
    else
    {
        // Display an error message on the UI Thread.
    }
    
    [_dm release];
    [list release];
}

-(void)reloadTableWithStocks:(NSMutableArray*)stocks
{
    _stockList = [stocks retain];
    _visibleStockList = [[NSMutableArray arrayWithArray:_stockList] retain];
    [[self tableView] reloadData];
}

-(void)searchBarTextDidBeginEditing:(UISearchBar*)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
    [[self tableView] setAllowsSelection:NO];
    [[self tableView] setScrollEnabled:NO];
}

- (void)searchBarCancelButtonClicked:(UISearchBar*)searchBar 
{
    [searchBar setText:@""];
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    [[self tableView] setAllowsSelection:YES];
    [[self tableView] setScrollEnabled:YES];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar 
{
    NSArray *results = [self doSearch:searchBar.text]; // TOOD different thread.
	
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    [[self tableView] setAllowsSelection:YES];
    [[self tableView] setScrollEnabled:YES];
	
    [_visibleStockList removeAllObjects];
    [_visibleStockList addObjectsFromArray:results];
    [[self tableView] reloadData];
}

-(NSMutableArray*)doSearch:(NSString*)searchText
{
    if([searchText isEqualToString:@""])
       return _stockList;
       
    NSMutableArray *results = [[NSMutableArray alloc] init];
    
    for(StockData *sd in _stockList)
    {
        if ([[sd name] rangeOfString:searchText options:NSCaseInsensitiveSearch].length > 0)
        {
            [results addObject:sd];
        }
        else if([[sd symbol] rangeOfString:searchText options:NSCaseInsensitiveSearch].length > 0)
        {
            [results addObject:sd];
        }
    }
    return [results autorelease];
}

-(void)dealloc
{
    [_stockList release];
    [_visibleStockList release];
    
    [super dealloc];
}

@end