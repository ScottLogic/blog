//
//  ChartTypeCellView.h
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import "ChartTypeCellView.h"

@implementation ChartTypeCellView

@synthesize Name;
@synthesize Image;
@synthesize highlighted;
@synthesize editing;

-(id)initWithFrame:(CGRect)frame 
{	
	if (self = [super initWithFrame:frame]) 
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
            _backgroundImage = [UIImage imageNamed:@"row_iPad.png"];
        else
            _backgroundImage = [UIImage imageNamed:@"row.png"];
	}
	return self;
}

-(void)setName:(NSString*)newName
{
	if (Name != newName)
    {
		[Name release];
		Name = [newName retain];
	}
	[self setNeedsDisplay];
}

-(void)setImage:(UIImage*)newImage
{
	if (Image != newImage)
    {
		[Image release];
		Image = [newImage retain];
	}
	[self setNeedsDisplay];
}

- (void)setHighlighted:(BOOL)lit 
{
	if (highlighted != lit) 
    {
		highlighted = lit;	
		[self setNeedsDisplay];
	}
}

-(void)drawRect:(CGRect)rect
{
    UIFont *mainFont = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        _backgroundImage = [[UIImage imageNamed:@"row_iPad.png"] retain];
        [_backgroundImage drawAtPoint:CGPointMake(0, 0)];
    }
    else
    {
        _backgroundImage = [[UIImage imageNamed:@"row.png"] retain];
        [_backgroundImage drawAtPoint:CGPointMake(0, 0)];
    }
    
    CGPoint point;
    point = CGPointMake(5, 7);
    [Image drawAtPoint:point];

    [[UIColor blackColor] set];
    point = CGPointMake(60, 19);
    [Name drawAtPoint:point forWidth:280 withFont:mainFont minFontSize:18 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
    
    [[UIColor whiteColor] set];
    point = CGPointMake(60, 20);
    [Name drawAtPoint:point forWidth:400 withFont:mainFont minFontSize:18 actualFontSize:NULL lineBreakMode:UILineBreakModeTailTruncation baselineAdjustment:UIBaselineAdjustmentAlignBaselines];
}

- (void)dealloc
{
    [name release];
    [image release];
    [_backgroundImage release];

    [Name release];
    [Image release];
    
    [super dealloc];
}

@end