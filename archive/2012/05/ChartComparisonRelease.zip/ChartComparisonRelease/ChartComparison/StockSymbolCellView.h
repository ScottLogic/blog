//
//  StockSymbolCellView.h
//  ChartComparison
//
//  Created by Chris Grant on 17/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//


#import <UIKit/UIKit.h>

@class StockData;

@interface StockSymbolCellView : UIView 
{
    StockData *data;
	BOOL highlighted;
	BOOL editing;
    UIImage *_backgroundImage;
}

@property (nonatomic, retain) StockData *Data;
@property (nonatomic, getter=isHighlighted) BOOL highlighted;
@property (nonatomic, getter=isEditing) BOOL editing;

@end