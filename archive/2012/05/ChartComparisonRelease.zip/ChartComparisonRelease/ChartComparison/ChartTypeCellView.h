//
//  ChartTypeCellView.h
//  ChartComparison
//
//  Created by Chris Grant on 28/01/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChartTypeCellView : UIView 
{
    NSString *name;
    UIImage *image;
	BOOL highlighted;
	BOOL editing;
    UIImage *_backgroundImage;
}

@property (nonatomic, retain) NSString *Name;
@property (nonatomic, retain) UIImage *Image;
@property (nonatomic, getter=isHighlighted) BOOL highlighted;
@property (nonatomic, getter=isEditing) BOOL editing;

@end