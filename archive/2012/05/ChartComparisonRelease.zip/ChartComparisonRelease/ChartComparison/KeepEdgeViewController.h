//
//  KeepEdgeViewController.h
//  ChartComparison
//
//  Created by Chris Grant on 04/02/2012.
//  Copyright (c) 2012 Scott Logic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChartBaseViewController.h"

@interface KeepEdgeViewController : ChartBaseViewController { }

@end