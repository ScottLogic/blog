﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
#if WINDOWS_PHONE
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
#elif SILVERLIGHT
using Microsoft.Maps.MapControl;
#else
using Microsoft.Maps.MapControl.WPF;
#endif

namespace MapsDemo
{
    public static class Extensions
    {
        public static string GetShortName(this Assembly asm)
        {
            return new AssemblyName(asm.FullName).Name;
        }

        public static IEnumerable<string> GetResourceNames(this Assembly asm)
        {
            var name = new AssemblyName(asm.FullName).Name;
            using (var res = new ResourceManager(name + ".g", asm)
                .GetResourceSet(CultureInfo.CurrentCulture, true, true))
            {
                return res.Cast<DictionaryEntry>()
                          .Select(d => (string)d.Key)
                          .ToList();
            }
        }

        /// <summary>
        /// Workaround for the obnoxious LocationCollection with no copy constructor or AddRange.
        /// </summary>
        public static LocationCollection ToLocationCollection(this IEnumerable<Location> locations)
        {
            var locs = new LocationCollection();
            foreach (var loc in locations)
            {
                locs.Add(loc);
            }
            return locs;
        }
    }
}
