﻿using System.Windows;
#if WINDOWS_PHONE
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
#elif SILVERLIGHT
using Microsoft.Maps.MapControl;
#else
using Microsoft.Maps.MapControl.WPF;
#endif

namespace MapsDemo
{
    public static class Mapping
    {
        public static LocationRect GetView(DependencyObject obj)
        {
            return (LocationRect)obj.GetValue(ViewProperty);
        }

        public static void SetView(DependencyObject obj, LocationRect value)
        {
            obj.SetValue(ViewProperty, value);
        }

        public static readonly DependencyProperty ViewProperty =
            DependencyProperty.RegisterAttached("View", typeof(LocationRect), typeof(Mapping), new PropertyMetadata(OnViewPropertyChanged));

        private static void OnViewPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Map map = d as Map;
            var rect = e.NewValue as LocationRect;
            if (map != null && rect != null)
            {
                map.SetView(rect);
            }
        }
    }
}
