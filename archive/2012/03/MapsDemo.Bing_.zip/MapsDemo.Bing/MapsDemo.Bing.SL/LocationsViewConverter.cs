﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Data;
#if WINDOWS_PHONE
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
using System.Device.Location;
#elif SILVERLIGHT
using Microsoft.Maps.MapControl;
#else
using Microsoft.Maps.MapControl.WPF;
#endif

namespace MapsDemo
{
    /// <summary>
    /// Convert collection of locations to its bounding rectangle.
    /// </summary>
    public class LocationsViewConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
#if WINDOWS_PHONE
            var locs = value as IEnumerable<GeoCoordinate>;
#else
            var locs = value as IEnumerable<Location>;
#endif
            if (locs != null && locs.Any())
            {
                return new LocationRect(locs.Max(l => l.Latitude), locs.Min(l => l.Longitude), // NWSE
                                        locs.Min(l => l.Latitude), locs.Max(l => l.Longitude));
            }
            else
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
