﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows;
using System.Xml.Linq;
#if WINDOWS_PHONE
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Controls.Maps.Platform;
#elif SILVERLIGHT
using Microsoft.Maps.MapControl;
#else
using Microsoft.Maps.MapControl.WPF;
#endif

namespace MapsDemo
{
    public class GpxPath : INotifyPropertyChanged
    {
        #region Properties

        LocationCollection loc;
        public LocationCollection Locations
        {
            get { return loc; }
            set
            {
                if (loc == value) return;
                loc = value;
                OnPropertyChanged("Locations");
            }
        }

        LocationCollection pins;
        public LocationCollection PushPins
        {
            get { return pins; }
            set
            {
                if (pins == value) return;
                pins = value;
                OnPropertyChanged("PushPins");
            }
        }

        public IEnumerable<string> AllTracks
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetResourceNames()
                    .Where(r => r.EndsWith(".gpx"))
                    .Select(file => new Regex(".*/(.*)\\.gpx").Replace(file, "$1"));
            }
        }

        private string _track;
        public string Track
        {
            get { return _track; }
            set
            {
                if (value == _track) return;
                _track = value;
                LoadTrack(_track);
                OnPropertyChanged("Track");
            }
        }

        #endregion

        private void LoadTrack(string _track)
        {
            using (var streamReader = new StreamReader(Application.GetResourceStream(new Uri(
                String.Format("/{0};component/Data/{1}.gpx", Assembly.GetExecutingAssembly().GetShortName(), _track), UriKind.Relative)).Stream))
            {
                XDocument doc = XDocument.Parse(streamReader.ReadToEnd());
                var ns = doc.Root.GetDefaultNamespace();

                var locations = doc.Descendants()
                    .Where(el => el.Name == ns + "wpt" || el.Name == ns + "trkpt")
                    .Select(trkpt =>
                        new Location
                        {
                            Latitude = double.Parse(trkpt.Attribute("lat").Value),
                            Longitude = double.Parse(trkpt.Attribute("lon").Value)
                        });
                Locations = locations.ToLocationCollection();
                PushPins = new Location[] { locations.First(), locations.Last() }.ToLocationCollection();
            };
        }

        #region INotifyPropertyChanged
        protected void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion
    }
}
