package com.scottlogic.blogs.markrhodes.initdatastructures.test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.junit.Test;

/**
 * Unit tests to verify that initialising data hash maps is done efficiently using a default size
 * defined by: <code>(int) Math.ceil(requiredCapacity / loadFactor);</code>
 * See: http://stackoverflow.com/questions/434989/hashmap-intialization-parameters-load-initialcapacity
 *
 * @author Mark Rhodes
 */
public class InitMapTest {

	//Returns the initial capacity to use when creating maps (this is effectively the method
	//being tested by the tests in this class)..
	private int getInitialCapacity(int requiredCapacity, float loadFactor){
		return (int) Math.ceil(requiredCapacity / loadFactor);
	}

	/**
	 * Verifies that defining the initial size of a <code>java.util.HashMap</code> as
	 * <code>(int) Math.ceil(requiredCapacity / loadFactor);</code> is optimal in terms of
	 * both not resizing and not using excessive space.
	 */
	@Test
	public void testHashMapInitialisation() throws
	                IllegalArgumentException, IllegalAccessException,
	                SecurityException, NoSuchFieldException {

		testMapInit(new TestInstanceFactory(){
			@Override
			public HashMap<Integer, Integer> createTestInstance(int requiredCapacity, float loadFactor){
				int initialCapacity = getInitialCapacity(requiredCapacity, loadFactor);
				return new HashMap<Integer, Integer>(initialCapacity, loadFactor);
			}

			//Returns a map which always has the smallest possible initial capacity (1).
			@Override
			public HashMap<Integer, Integer> createSmallerMapInstance(int initialCapacity, float loadFactor){
				return new HashMap<Integer, Integer>(0, loadFactor);
			}

		});
	}

	/**
	 * Verifies that defining the initial size of a code>java.util.Hashtable</code> as
	 * <code>(int) Math.ceil(requiredCapacity / loadFactor);</code> is optimal in terms of
	 * both not resizing and not using excessive space.
	 */
	@Test
	public void testHashtableInitialisation() throws
	                IllegalArgumentException, IllegalAccessException,
	                SecurityException, NoSuchFieldException {

		testMapInit(new TestInstanceFactory(){
			@Override
			public Hashtable<Integer, Integer> createTestInstance(int requiredCapacity, float loadFactor){
				int initialCapacity = getInitialCapacity(requiredCapacity, loadFactor);
				return new Hashtable<Integer, Integer>(initialCapacity, loadFactor);
			}

			//Returns a map which has size which is the larger of zero and the value of getInitialCapacity minus one.
			@Override
			public Hashtable<Integer, Integer> createSmallerMapInstance(int requiredCapacity, float loadFactor){
				int initialCapacity = getInitialCapacity(requiredCapacity, loadFactor);
				initialCapacity = Math.max(0, initialCapacity-1);
				return new Hashtable<Integer, Integer>(initialCapacity, loadFactor);
			}

		});
    }

	//Verifies that instances provided by the given factory do not increase their internal tables
	//and that their capacities are not overly large, for a range of load factors and sizes..
	@SuppressWarnings("unchecked")
	private <T> void testMapInit(TestInstanceFactory instanceFactory) throws
		    IllegalArgumentException, IllegalAccessException,
		    SecurityException, NoSuchFieldException {

		// Whether or not at least one instance provided by the createSmallerMapInstance method
		//had to resize it's backing array..
		boolean smallerCapMapResized = false;

        float [] loadFactors = { 0.25f, 0.5f, 0.75f /* default */, 1, 5 };
        for(int f = 0; f < loadFactors.length; f++){
	        float loadFactor = loadFactors[f];
        	for(int i = 0; i < 1026; i++){

        		Map<Integer, Integer> map = instanceFactory.createTestInstance(i,  loadFactor);
                Map<Integer, Integer> smallerCapMap = instanceFactory.createSmallerMapInstance(i, loadFactor);

                //make it so that we can see the private fields..
                Field tableField = map.getClass().getDeclaredField("table");
                tableField.setAccessible(true);
                Field thresholdField = map.getClass().getDeclaredField("threshold");
                thresholdField.setAccessible(true);

                Map.Entry<Integer, Integer>[] table = (Map.Entry<Integer, Integer>[]) tableField.get(map);
                Map.Entry<Integer, Integer>[] smallCapTable = (Map.Entry<Integer, Integer>[]) tableField.get(smallerCapMap);
                assertTrue(table.length >= smallCapTable.length); //check "small one" really is no larger..

                //add entries to the maps..
                int startSize = table.length;
                for(int j = 0; j < i; j++){
                    map.put(j, j);
                    smallerCapMap.put(j, j);
                }

                //check to see if the smallCapTable is different..
                if(smallCapTable != tableField.get(smallerCapMap)){
                	smallerCapMapResized = true;
                }

                //check that the map has not had to resize it's table..
                table = (Map.Entry<Integer, Integer>[]) tableField.get(map);  //could be pointing to old one..
                assertEquals(startSize, table.length);

                //check that the map is not too large..
                Map.Entry<Integer, Integer>[] smallerMapTable =
                		(Map.Entry<Integer, Integer>[]) tableField.get(smallerCapMap);
                int smallestCapMapThreshold = (int) thresholdField.get(smallerCapMap);
                if(smallestCapMapThreshold >= smallerCapMap.size()){
	                assertTrue(smallerMapTable.length >= table.length);
                }
	        }
        }

        //if no smaller cap map resized then we could be allocating too much memory sometimes..
        assertTrue(smallerCapMapResized);
	}

	//Defined a factory for providing map instances for testing..
	interface TestInstanceFactory {
		//Returns the instance of the Map being tested using the given initial
		//capacity and load factor.
		Map<Integer, Integer> createTestInstance(int requiredCapacity, float loadFactor);

		//Returns an a new map instance which should be guaranteed to have a
		//table which is smaller than or equal to instances returned from the
		//#getTestInstance method when called with the same parameters.
		//Note: the returned instance need not actually have the given required capacity.
		Map<Integer, Integer> createSmallerMapInstance(int requiredCapacity, float loadFactor);
	}
}


