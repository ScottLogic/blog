//
//  UITextViewHideKeyboardOnEnterBehaviour.m
//  MulticastDelegateDemo
//
//  Created by Colin Eberhardt on 16/11/2012.
//  Copyright (c) 2012 Colin Eberhardt. All rights reserved.
//

#import "UITextViewHideKeyboardOnEnterBehaviour.h"
#import "UITextView+Multicast.h"

@implementation UITextViewHideKeyboardOnEnterBehaviour

- (id)initWithTextView:(UITextView *)textView
{
    if (self=[super init])
    {
        [textView.multicastDelegate addDelegate:self];
    }
    return self;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    // see: http://stackoverflow.com/questions/703754/how-to-dismiss-keyboard-for-uitextview-with-return-key
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    return YES;
}

@end
