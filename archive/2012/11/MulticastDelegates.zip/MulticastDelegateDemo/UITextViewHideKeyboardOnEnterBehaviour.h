//
//  UITextViewHideKeyboardOnEnterBehaviour.h
//  MulticastDelegateDemo
//
//  Created by Colin Eberhardt on 16/11/2012.
//  Copyright (c) 2012 Colin Eberhardt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UITextViewHideKeyboardOnEnterBehaviour : NSObject <UITextViewDelegate>

- (id) initWithTextView:(UITextView*) textView;

@end
