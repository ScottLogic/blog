//
//  UITextFieldHideKeyboardBehaviour.m
//  MulticastDelegateDemo
//
//  Created by Colin Eberhardt on 16/11/2012.
//  Copyright (c) 2012 Colin Eberhardt. All rights reserved.
//

#import "UITextFieldHideKeyboardBehaviour.h"
#import "UITextField+Multicast.h"

@implementation UITextFieldHideKeyboardBehaviour

- (id)initWithTextField:(UITextField *)textField
{
    if (self=[super init])
    {
        [textField.multicastDelegate addDelegate:self];
    }
    return self;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}

@end
