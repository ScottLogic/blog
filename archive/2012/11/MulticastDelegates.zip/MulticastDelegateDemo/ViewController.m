//
//  ViewController.m
//  MulticastDelegateDemo
//
//  Created by Colin Eberhardt on 16/11/2012.
//  Copyright (c) 2012 Colin Eberhardt. All rights reserved.
//

#import "ViewController.h"
#import "UITextFieldHideKeyboardBehaviour.h"
#import "UITextViewHideKeyboardOnEnterBehaviour.h"
#import "UITextView+Multicast.h"

@interface ViewController ()

@end

@implementation ViewController 

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // add the hide-keyboard-on-enter behaviour
    [[UITextViewHideKeyboardOnEnterBehaviour alloc] initWithTextView:self.textView];
    
    // add 'self' as a delegate to provide a character count
    [self.textView.multicastDelegate addDelegate:self];
    
}

-(void)textViewDidChange:(UITextView *)textView
{
    self.countLabel.text = [NSString stringWithFormat:@"%d", self.textView.text.length]; 
}

@end
