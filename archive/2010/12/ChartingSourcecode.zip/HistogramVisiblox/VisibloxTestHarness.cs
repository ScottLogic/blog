﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using Histogram;

namespace Visiblox.Charts.Examples
{
  public class VisibloxTestHarness : HistogramTestHarness
  {
    private VisibloxChart _chart;

    public VisibloxTestHarness()
    {

      Image.Source = new BitmapImage(new Uri("hare.jpg", UriKind.Relative));
      _chart = new VisibloxChart();
      ChartPresenter.Content = _chart;
    }

    protected override void RenderDataToChart(List<List<Histogram.DataPoint>> rgbData)
    {
      _chart.Chart.Series[0].DataSeries = ListToSeries(rgbData[0]);
      _chart.Chart.Series[1].DataSeries = ListToSeries(rgbData[1]);
      _chart.Chart.Series[2].DataSeries = ListToSeries(rgbData[2]);
    }

    private DataSeries<double, double> ListToSeries(List<Histogram.DataPoint> data)
    {
      return new DataSeries<double, double>(data.Select(pt => 
        new DataPoint<double, double>(pt.Location, pt.Intensity)));
    }
  }
}
