﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Collections.Generic;

namespace Histogram
{
  public class AmChartTestHarness : HistogramTestHarness
  {
    private AmChart _chart;

    public AmChartTestHarness()
    {

      Image.Source = new BitmapImage(new Uri("pronghorn.jpg", UriKind.Relative));
      _chart = new AmChart();
      ChartPresenter.Content = _chart;
    }

    protected override void RenderDataToChart(List<List<Histogram.DataPoint>> rgbData)
    {
      _chart.Chart.DataSource = GetRGBData(rgbData);
    }

    private List<RGBData> GetRGBData(List<List<Histogram.DataPoint>> rgbData)
    {
      var data =
          from r in rgbData[0]
          join g in rgbData[1] on r.Location equals g.Location
          join b in rgbData[2] on r.Location equals b.Location
          select new RGBData() { Location = r.Location, RIntensity = r.Intensity, GIntensity = g.Intensity, BIntensity = b.Intensity };

      return data.ToList();
    }
  }

  public class RGBData
  {
    public double Location { get; set; }
    public double RIntensity { get; set; }
    public double GIntensity { get; set; }
    public double BIntensity { get; set; }
  }
}
