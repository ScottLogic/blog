﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Media.Imaging;
using Histogram;

namespace HistogramToolkit
{
  public partial class ToolkitTestHarness : HistogramTestHarness
  {
    private ToolkitChart _chart;

    public ToolkitTestHarness()
    {

      Image.Source = new BitmapImage(new Uri("tortoise.jpg", UriKind.Relative));
      _chart = new ToolkitChart();
      ChartPresenter.Content = _chart;
    }

    protected override void RenderDataToChart(List<List<Histogram.DataPoint>> rgbData)
    {
      ((LineSeries)_chart.Chart.Series[0]).ItemsSource = rgbData[0];
      ((LineSeries)_chart.Chart.Series[1]).ItemsSource = rgbData[1];
      ((LineSeries)_chart.Chart.Series[2]).ItemsSource = rgbData[2];
    }
  }
}
