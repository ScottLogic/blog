﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using Visifire.Charts;

namespace Histogram
{
  public class VisifireTestHarness : HistogramTestHarness
  {
    private VisifireChart _chart;

    public VisifireTestHarness()
    {

      Image.Source = new BitmapImage(new Uri("snail.jpg", UriKind.Relative));
      _chart = new VisifireChart();
      ChartPresenter.Content = _chart;
    }

    protected override void RenderDataToChart(List<List<Histogram.DataPoint>> rgbData)
    {
      AddDataToSeries(_chart.Chart.Series[0], rgbData[0]);
      AddDataToSeries(_chart.Chart.Series[1], rgbData[1]);
      AddDataToSeries(_chart.Chart.Series[2], rgbData[2]);
    }

    private void AddDataToSeries(DataSeries series, List<Histogram.DataPoint> list)
    {
      series.DataPoints.Clear();
      foreach (var pt in list)
      {
        series.DataPoints.Add(new Visifire.Charts.DataPoint()
        {
          XValue = pt.Location,
          YValue = pt.Intensity
        });
      }
    }
  }
}
