﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using Microsoft.Research.DynamicDataDisplay;

namespace Histogram
{
  public class DDDTestHarness : HistogramTestHarness
  {
    private DDDChart _chart;

    public DDDTestHarness()
    {

      Image.Source = new BitmapImage(new Uri("horse.jpg", UriKind.Relative));
      _chart = new DDDChart();
      ChartPresenter.Content = _chart;
    }

    protected override void RenderDataToChart(List<List<DataPoint>> rgbData)
    {
      RenderDataToGraph(_chart.LineGraphR, rgbData[0]);
      RenderDataToGraph(_chart.LineGraphG, rgbData[1]);
      RenderDataToGraph(_chart.LineGraphB, rgbData[2]);

      // re-scale the chart based on teh rendered data
      _chart.Plotter.FitToView();
    }

    private void RenderDataToGraph(LineGraph graph, List<DataPoint> histogram)
    {
      var source = graph.DataSource as CompositeDataSource;

      // obtain the two sources which the composiet is composed of
      var xSource = source.DataParts.ElementAt(0) as EnumerableDataSource<double>;
      var ySource = source.DataParts.ElementAt(1) as EnumerableDataSource<double>;

      var dataX = new List<double>();
      var dataY = new List<double>();
      foreach(var point in histogram)
      {
        dataX.Add(point.Location);
        dataY.Add(point.Intensity);
      }
      xSource.Data = dataX;
      ySource.Data = dataY;
    }

    
  }
}

