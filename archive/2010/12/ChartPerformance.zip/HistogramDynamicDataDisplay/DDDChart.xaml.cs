﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using Microsoft.Research.DynamicDataDisplay;
using System.Diagnostics;
using Microsoft.Research.DynamicDataDisplay.Navigation;
using LinqToVisualTree;

namespace Histogram
{
  public partial class DDDChart : UserControl
  {
    private EnumerableDataSource<double> _xSource = null;

    private EnumerableDataSource<double> _ySource = null;

    private LineGraph _graphOne;
    private LineGraph _graphTwo;
    private LineGraph _graphThree;


    public DDDChart()
    {
      InitializeComponent();

      this.Loaded += new RoutedEventHandler(DDDChart_Loaded);
    }

    public LineGraph LineGraphR
    {
      get
      {
        return _graphOne;
      }
    }

    public LineGraph LineGraphG
    {
      get
      {
        return _graphTwo;
      }
    }

    public LineGraph LineGraphB
    {
      get
      {
        return _graphThree;
      }
    }


    public ChartPlotter Plotter
    {
      get
      {
        return plotter;
      }
    }

    private LineGraph InitGraph(Color color)
    {
      var animatedX = new List<double>();
      var animatedY = new List<double>();

      // add some points, otherwise we get some layout-related exception
      animatedX.Add(0);
      animatedY.Add(0);

      // create the X & Y sources
      _xSource = new EnumerableDataSource<double>(animatedX);
      _xSource.SetXMapping(x => x);
      _ySource = new EnumerableDataSource<double>(animatedY);
      _ySource.SetYMapping(y => y);

      // Adding graph to plotter
      var graph = new LineGraph(new CompositeDataSource(_xSource, _ySource), "");
      graph.LineColor = color;
      graph.LineThickness = 1;
      plotter.Children.Add(graph);

      return graph;
    }

    private void DDDChart_Loaded(object sender, RoutedEventArgs e)
    {
      // remove the mouse pan and zoom controls
      var navigationControl = plotter.Children.OfType<MouseNavigation>().Single();
      plotter.Children.Remove(navigationControl);

      var zoomControl = plotter.Descendants().OfType<buttonsNavigation>().Single();
      ((Panel)zoomControl.Ancestors().First()).Children.Remove(zoomControl);
    
      _graphOne = InitGraph(Color.FromArgb(255,200,0,0));
      _graphTwo = InitGraph(Color.FromArgb(255, 0, 200, 0));
      _graphThree = InitGraph(Color.FromArgb(255, 0, 0, 200));

      // Force everything plotted to be visible
      plotter.FitToView();

      plotter.Legend.Visibility = Visibility.Collapsed;

      
    }
  }
}
