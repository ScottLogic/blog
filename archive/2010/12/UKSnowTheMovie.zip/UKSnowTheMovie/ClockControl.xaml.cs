﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace UKSnowTheMovie
{
  public partial class ClockControl : UserControl
  {
    public ClockControl()
    {
      InitializeComponent();

      var hourAngles = new List<double>();
      for(double hour=0;hour<12;hour++)
      {
        hourAngles.Add (hour * 360.0 / 12.0);
      }

      MinuteHand.DataContext = 0;
      HourHand.DataContext = 0;

      HoursIndicator.ItemsSource = hourAngles; 
    }

    public void SetDate(DateTime date)
    {
      MinuteHand.DataContext = (double)date.Minute * 360.0 / 60.0;
      HourHand.DataContext = (double)date.Hour * 360.0 / 12.0;
    }
  }
}
