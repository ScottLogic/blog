﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace UKSnowTheMovie
{
  public partial class CalendarControl : UserControl
  {
    public CalendarControl()
    {
      InitializeComponent();
    }

    public void SetDate(DateTime date)
    {
      DayOfWeek.Text = date.ToString("ddd");
      Day.Text = date.ToString("dd");
    }
  }
}
