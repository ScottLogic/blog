﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Maps.MapControl;
using System.Windows.Media.Imaging;
using Visiblox.Charts;
using System.ComponentModel;
using System.Windows.Threading;
using System.Windows.Media.Effects;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace UKSnowTheMovie
{
  public partial class MainPage : UserControl
  {

    /// <summary>
    /// The number of minutes either side of the current time for which 
    /// #uksnow will be plotted for.
    /// </summary>
    private const double SnowRangeFactor = 15;

    /// <summary>
    /// The tick rate for the playback timer
    /// </summary>
    private static readonly TimeSpan PlaybackRate = TimeSpan.FromMilliseconds(50);

    /// <summary>
    /// The nubmer of minutes to add for each timer tick
    /// </summary>
    private static readonly TimeSpan PlaybackIncrement = TimeSpan.FromMinutes(4);

    private List<GeoCodedUKSnowTweet> _tweets = new List<GeoCodedUKSnowTweet>();

    private DateLineBehaviour _dateLine;

    private DispatcherTimer _playbackTimer;

    private BitmapSource _snowBitmap;

    private BitmapSource _snowAndPic;

    public MainPage()
    {
      InitializeComponent();

      _snowBitmap = new BitmapImage(new Uri("/UKSnowTheMovie;component/snow.png", UriKind.Relative));
      _snowAndPic = new BitmapImage(new Uri("/UKSnowTheMovie;component/snowAndPic.png", UriKind.Relative));

      _playbackTimer = new DispatcherTimer();
      _playbackTimer.Interval = PlaybackRate;
      _playbackTimer.Tick += new EventHandler(PlaybackTimer_Tick);

      var doc = XDocument.Load("/UKSnowTheMovie;component/tweets.xml");

      // parse the XML file
      _tweets = doc.Descendants("tweet").Select(el => new GeoCodedUKSnowTweet()
                                        {
                                          Author = el.Attribute("author").Value,
                                          Title = el.Attribute("title").Value,
                                          ProfileImageUrl = el.Attribute("profile").Value,
                                          Location = StringToPoint(el.Attribute("loc").Value),
                                          SnowFactor = int.Parse(el.Attribute("snowfactor").Value),
                                          Timestamp = DateTime.Parse(el.Attribute("timestamp").Value)
                                        })
                                        .OrderBy(t => t.Timestamp)                                        
                                        .ToList();

      // total the tweets per 30 minute interval
      var groupedByHour = _tweets.GroupBy(t => RoundDateToMinutes(t.Timestamp, 30))
                                .Select(group => 
                                  new TweetsPerHour() {
                                    Hour = group.Key,
                                    Tweets = group.Count()
                                  }).ToList();

      // associate the above with the chart
      chart.Series[0].YAxis = chart.SecondaryYAxis;
      ((BindableDataSeries)chart.Series[0].DataSeries).ItemsSource = groupedByHour;

      _dateLine = new DateLineBehaviour();
      _dateLine.PropertyChanged += new PropertyChangedEventHandler(DateLineBehaviour_PropertyChanged);
      
      chart.Behaviour = _dateLine;
      chart.Loaded += new RoutedEventHandler(Chart_Loaded);

      // set the view to the UK
      Map.SetView(new Location(54.51655, -3.22), 5.0);
      Map.Mode = new AerialMode(false);
    }

    private void Chart_Loaded(object sender, RoutedEventArgs e)
    {
      _dateLine.CurrentDate = _tweets.First().Timestamp;
    }

    private void PlayPause_Click(object sender, RoutedEventArgs e)
    {
      if (_playbackTimer.IsEnabled)
      {
        _playbackTimer.Stop();
        VisualStateManager.GoToState(PlayPauseButton, "Paused", true);
      }
      else
      {
        if (_dateLine.CurrentDate > _tweets.Last().Timestamp)
        {
          _dateLine.CurrentDate = _tweets.First().Timestamp;
        }

        _playbackTimer.Start();

        VisualStateManager.GoToState(PlayPauseButton, "Playing", true);
      }
    }

    private void PlaybackTimer_Tick(object sender, EventArgs e)
    {
      _dateLine.CurrentDate = _dateLine.CurrentDate.Add(PlaybackIncrement);

      if (_dateLine.CurrentDate > _tweets.Last().Timestamp)
      {
        _playbackTimer.Stop();
        VisualStateManager.GoToState(PlayPauseButton, "Paused", true);
      }
    }

    private void DateLineBehaviour_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      ShowSnowForTime(_dateLine.CurrentDate);
      CalendarControl.SetDate(_dateLine.CurrentDate);
      ClockControl.SetDate(_dateLine.CurrentDate);
    }

    /// <summary>
    /// Renders all the #uksnow around the given time
    /// </summary>
    /// <param name="dateTime"></param>
    private void ShowSnowForTime(DateTime dateTime)
    {

      // filter the tweets to capture those in the timerange
      var tweets = _tweets.Select(t => new
                            {
                              Tweet = t,
                              NormalDistance = 1.0 - Math.Abs((t.Timestamp - dateTime).TotalMinutes) / SnowRangeFactor
                            })
                            .Where(t => t.NormalDistance > 0)
                            .Take(200)
                            .ToList();
      
      // add snow to the map - recycling any existing images
      int minIndex = Math.Min(tweets.Count, Map.Children.Count);
      for (int i = 0; i < minIndex; i++)
      {
        var filteredTweet = tweets[i];
        var snowImage = Map.Children[i] as Image;
        ConfigureImage(snowImage, filteredTweet.Tweet, filteredTweet.NormalDistance);
      }

      if (tweets.Count > Map.Children.Count)
      {
        for (int i = minIndex; i < tweets.Count; i++)
        {
          var filteredTweet = tweets[i];
          ConfigureImage(CreateImage(), filteredTweet.Tweet, filteredTweet.NormalDistance);
        }
      }
      else if (Map.Children.Count > tweets.Count)
      {
        var imagesToRemove = Map.Children.Skip(tweets.Count).ToList();
        foreach(var image in imagesToRemove)
        {
          Map.Children.Remove(image);
        }
      }      
    }

    /// <summary>
    /// Creates an image and adds it to the map
    /// </summary>
    private Image CreateImage()
    {
      Image snowImage = new Image();      
      snowImage.Stretch = Stretch.None;
      MapLayer.SetPositionOrigin(snowImage, PositionOrigin.Center);
      Map.Children.Add(snowImage);
      snowImage.MouseEnter += new MouseEventHandler(snowImage_MouseEnter);
      snowImage.MouseLeave += new MouseEventHandler(snowImage_MouseLeave);
      return snowImage;
    }

    private void snowImage_MouseEnter(object sender, MouseEventArgs e)
    {
      Image snowImage = sender as Image;
      GeoCodedUKSnowTweet tweet = snowImage.Tag as GeoCodedUKSnowTweet;
      TweetControl.DataContext = tweet;
      Tweet.Show();

      snowImage.Opacity = 1.0;
      snowImage.Effect = new DropShadowEffect()
      {
        Color = Colors.Red,
        BlurRadius = 10,
        ShadowDepth = 0
      };
    }

    private void snowImage_MouseLeave(object sender, MouseEventArgs e)
    {
      Image snowImage = sender as Image;
      GeoCodedUKSnowTweet tweet = snowImage.Tag as GeoCodedUKSnowTweet;
      Tweet.Hide();

      double opacityFactor = 1.0 - Math.Abs((tweet.Timestamp - _dateLine.CurrentDate).TotalMinutes) / SnowRangeFactor;
      snowImage.Opacity = ((double)tweet.SnowFactor / 10.0) * opacityFactor;
      snowImage.Effect = null;
    }

    /// <summary>
    /// Configrues the image to represent the given geotweet
    /// </summary>
    private void ConfigureImage(Image image, GeoCodedUKSnowTweet geoTweet, double opacityFactor)
    {
      var location = new Location(geoTweet.Location.X, geoTweet.Location.Y);
      int factor = geoTweet.SnowFactor;
      image.Effect = null;
      image.Source = string.IsNullOrEmpty(geoTweet.PicUrl) ? _snowBitmap : _snowAndPic;
      image.Tag = geoTweet;
      image.Opacity = ((double)factor / 10.0) * opacityFactor;      
      MapLayer.SetPosition(image, location);     
    }


    public static DateTime RoundDateToMinutes(DateTime date, int minutes)
    {
      var bar = new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute - date.Minute % minutes, 0);
      return bar;
    }

    public static Point StringToPoint(string pt)
    {
      var coords = pt.Split(',');
      return new Point(double.Parse(coords[0]), double.Parse(coords[1]));
    }



    /// <summary>
    /// Adds the given tweet to the map
    /// </summary>
    private void AddSnow(GeoCodedUKSnowTweet geoTweet, double opactityFactor)
    {
      var location = new Location(geoTweet.Location.X, geoTweet.Location.Y);
      int factor = geoTweet.SnowFactor;

      Image image = new Image();
      image.Tag = geoTweet;
      image.Source = new BitmapImage(new Uri("/UKSnowTheMovie;component/snow.png", UriKind.Relative));
      image.Stretch = Stretch.None;
      image.Opacity = ((double)factor / 10.0) * opactityFactor;
      Map.Children.Add(image);

      MapLayer.SetPosition(image, location);
      MapLayer.SetPositionOrigin(image, PositionOrigin.Center);
    }

    
  }

  /// <summary>
  /// A tweet!
  /// </summary>
  public class Tweet
  {
    private string _title;

    public long Id { get; set; }    
    public string Author { get; set; }
    public string ProfileImageUrl { get; set; }
    public DateTime Timestamp { get; set; }
    public string PicUrl { get; set; }    

    public string Title
    {
      get { return _title; }
      set
      {
        _title = value;

        // extract any pictures within this tweet
        string pictureUrl = _title.GetFirstMatch(Regex.Escape("http://twitpic.com/") + @"[^\s]*");
        if (pictureUrl!="")
        {
          PicUrl = "http://twitpic.com/show/thumb/" + pictureUrl.Substring(19);
        }        
      }
    }


    public Tweet()
    { }

    public Tweet(Tweet tweet)
    {
      Id = tweet.Id;
      Title = tweet.Title;
      ProfileImageUrl = tweet.ProfileImageUrl;
      Author = tweet.Author;
      Timestamp = tweet.Timestamp;
    }

    public override string ToString()
    {
      return Title;
    }
  }

  /// <summary>
  /// A tweet with a postcode and snowfall factor
  /// </summary>
  public class UKSnowTweet : Tweet
  {
    public string Postcode { get; set; }

    private int _snowFactor;

    public int SnowFactor
    {
      get { return _snowFactor; }
      set { _snowFactor = Math.Min(10, value); }
    }

    public UKSnowTweet()
    {
    }

    public UKSnowTweet(Tweet tweet)
      : base(tweet)
    {
    }

    public UKSnowTweet(UKSnowTweet tweet)
      : this((Tweet)tweet)
    {
      Postcode = tweet.Postcode;
      SnowFactor = tweet.SnowFactor;
    }

    public override string ToString()
    {
      return Postcode + " " + SnowFactor.ToString() + " " + base.ToString();
    }
  }

  /// <summary>
  /// A geocoded tweet
  /// </summary>
  public class GeoCodedUKSnowTweet : UKSnowTweet
  {
    public Point Location { get; set; }
    
    public GeoCodedUKSnowTweet()
    {
    }

    public GeoCodedUKSnowTweet(UKSnowTweet tweet)
      : base(tweet)
    {
    }
  }

  public class TweetsPerHour
  {
    public DateTime Hour { get; set; }
    public double Tweets { get; set; }
  }
}
