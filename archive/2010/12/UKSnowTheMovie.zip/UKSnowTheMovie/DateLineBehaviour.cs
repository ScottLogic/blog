﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;

namespace UKSnowTheMovie
{
  /// <summary>
  /// Adds a vertical line to the chart that the user can drag
  /// </summary>
  public class DateLineBehaviour : BehaviourBase
  {
    private Line _line;

    private Rectangle _rectangle;

    private Canvas _canvas;

    private DateTime _currentDate;

    private bool _mouseDown;

    public double BarThicknessInMinutes { get; set;}

    /// <summary>
    /// Gets / sets the date that the vertical line indicates
    /// </summary>
    public DateTime CurrentDate
    {
      get { return _currentDate; }
      set
      {
        _currentDate = value;

        if (Chart != null)
          UpdateVisuals();
        
        OnPropertyChanged("CurrentDate");
      }
    }
    
    public DateLineBehaviour()
      : base("VerticalLineBehaviour")
    {
      _currentDate = DateTime.Now;
      BarThicknessInMinutes = 300;

      _canvas = new Canvas();
      
      _line = new Line()
      {
        Stroke = new SolidColorBrush(Color.FromArgb(100,255,255,255)),
        IsHitTestVisible = true,
        StrokeThickness = 2.0,
        Cursor = Cursors.SizeWE
      };

      _rectangle = new Rectangle()
      {
        Fill = new SolidColorBrush(Color.FromArgb(100, 62, 173, 242)),
        IsHitTestVisible = true,
        Cursor = Cursors.SizeWE
      };

      _canvas.Children.Add(_rectangle);
      _canvas.Children.Add(_line);
    }

    public override void DeInit()
    {
      base.PlotArea.Children.Remove(_canvas);
    }

    protected override void Init()
    {
      base.PlotArea.Children.Add(_canvas);
      UpdateVisuals();
    }

    public override void MouseLeftButtonDown(Point position)
    {
      base.MouseLeftButtonDown(position);
      _mouseDown = true;
    }

    public override void MouseLeftButtonUp(Point position)
    {
      base.MouseLeftButtonUp(position);
      _mouseDown = false;
    }

    public override void MouseMove(Point position)
    {
      if (_mouseDown)
      {
        CurrentDate = (DateTime)Chart.XAxis.GetRenderPositionAsDataValueWithZoom(position.X);
      }
    }

    /// <summary>
    /// Update the location of the line and rectangle
    /// </summary>
    private void UpdateVisuals()
    {
      double center = Chart.XAxis.GetDataValueAsRenderPositionWithZoom(CurrentDate);
      double right = Chart.XAxis.GetDataValueAsRenderPositionWithZoom(CurrentDate.AddMinutes(BarThicknessInMinutes / 2));
      double left = Chart.XAxis.GetDataValueAsRenderPositionWithZoom(CurrentDate.AddMinutes(-BarThicknessInMinutes / 2));

      _line.X1 = center;
      _line.X2 = center;
      _line.Y1 = 0;
      _line.Y2 = 1000;

      _rectangle.Height = 1000;
      _rectangle.Width = right - left;
      Canvas.SetLeft(_rectangle, left);
    }

    
  }
}
