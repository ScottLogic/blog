﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Globalization;

namespace WPFUniversalConveter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // http://www.kirupa.com/blend_wpf/value_converters_pg4.htm

        // http://stackoverflow.com/questions/505397/built-in-wpf-ivalueconverters


        public MainWindow()
        {
            InitializeComponent();
                      
            var conv = new UniversalValueConverter();
            rect1.SetValueEx(Rectangle.FillProperty, Colors.Red);
            rect2.SetValueEx(Rectangle.FillProperty, "Blue");
            rect3.SetValueEx(Rectangle.FillProperty, "#FFEE55");
            rect4.SetValueEx(Rectangle.FillProperty, new SolidColorBrush(Colors.Orange));
        }
    }

    public static class ExtensionMethods
    {
        /// <summary>
        /// Sets the given dependency property, applying type conversion where required
        /// </summary>
        public static void SetValueEx(this DependencyObject element, DependencyProperty property, object value)
        {
            var conv = new UniversalValueConverter();
            var convertedValue = conv.Convert(value, property.PropertyType, null, CultureInfo.InvariantCulture);
            element.SetValue(property, convertedValue);
        }
    }
}
