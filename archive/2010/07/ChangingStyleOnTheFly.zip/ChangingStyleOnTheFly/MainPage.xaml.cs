﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ChangingStyleOnTheFly
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            Style ellipseStyle = new Style(typeof(Ellipse));
            ellipseStyle.Setters.Add(new Setter(FrameworkElement.WidthProperty, 30));
            ellipseStyle.Setters.Add(new Setter(FrameworkElement.HeightProperty, 30));
            MyEllipse.Style = ellipseStyle;          
        }

        private void ChangeSetterValue_Click(object sender, RoutedEventArgs e)
        {
            Message.Text = "";
            try
            {
                (MyEllipse.Style.Setters[0] as Setter).Value = 20;
            }
            catch (UnauthorizedAccessException ex)
            {
                // UnauthorizedAccessException is thrown with the message "Attempted to perform an unauthorized operation"
                Message.Text = ex.GetType().Name + ": " + ex.Message;                
            }
        }

        private void AddStyleSetter_Click(object sender, RoutedEventArgs e)
        {
            Message.Text = "";
            try
            {
                MyEllipse.Style.Setters.Add(new Setter(FrameworkElement.OpacityProperty, 0.9));
            }
            catch (Exception ex)
            {
                // Exception is thrown with the message "Error HRESULT E_FAIL has been returned from a call to a COM component"
                Message.Text = ex.GetType().Name + ": " + ex.Message;        
            }
        }

        private void RemoveStyleSetter_Click(object sender, RoutedEventArgs e)
        {
            Message.Text = "";
            // Nothing will happen when removing a setter from the Style's Setter
            MyEllipse.Style.Setters.Remove(MyEllipse.Style.Setters[1]);
        }
    }
}
