﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CloningStyles
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void BtnUseTopStyle_Click(object sender, RoutedEventArgs e)
        {
            // Create a new style using the style of the top ellipse
            var newStyle = TopEllipse.Style.Clone();
            // Change stroke thickness to 3
            newStyle.Setters.Add(new Setter(Ellipse.StrokeThicknessProperty, 3));
            // Remove the fill Setter
            newStyle.Setters.RemoveAt(0);
            BottomEllipse.Style = newStyle;
        }
    }

    public static class Extensions
    {
        public static Style Clone(this Style style)
        {
            if (style == null)
                return null;
            Style clonedStyle = new Style(style.TargetType);
            clonedStyle.BasedOn = style.BasedOn;
            foreach (Setter setterToCopy in style.Setters)
            {
                clonedStyle.Setters.Add(new Setter()
                {
                    Property = setterToCopy.Property,
                    Value = setterToCopy.Value
                });
            }
            return clonedStyle;
        }
    }

}
