﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Diagnostics;
using System.ComponentModel;

namespace ScrollOffsetBinding
{
  public partial class MainPage : UserControl, INotifyPropertyChanged
  {
    private double _yPosition;

    private double _xPosition;

    public MainPage()
    {
      _yPosition = 200;
      _xPosition = 200;

      InitializeComponent();

      LayoutRoot.DataContext = this;
    }

    public double YPosition
    {
      get { return _yPosition; }
      set 
      {
        _yPosition = value;
        OnPropertyChanged("YPosition");
      }
    }

    public double XPosition
    {
      get { return _xPosition; }
      set
      {
        _xPosition = value;
        OnPropertyChanged("XPosition");
      }
    }

    #region INotifyPropertyChanged Members

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }

    #endregion

    private void Button_Click(object sender, RoutedEventArgs e)
    {
     // YPosition = 0;
      //XPosition = 0;
     /* var sb = new Storyboard();
      var anim = new DoubleAnimation()
      {
        Duration = new Duration(TimeSpan.FromSeconds(0.2)),
        To = 0,
        
      };
      Storyboard.SetTarget(anim, scrollViewer);
      Storyboard.SetTargetProperty(anim, new PropertyPath("(ScrollViewerBinding.VerticalOffset)"));
      sb.Children.Add(anim);
      sb.Duration = new Duration(TimeSpan.FromSeconds(0.2));
      this.Resources.Add("foo", sb);
      sb.Begin();*/

      Storyboard sb = (Storyboard)Resources["foo"];
      sb.Begin(); 
    }
  }
}
