﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace MemoryLeakExamples
{
    /// <summary>
    /// A service which broadcasts stock price updates
    /// </summary>
    public class StockPricesService
    {
        private static readonly List<string> s_symbols = new List<string>()
            { "AAL.L", "ABF.L", "AMEC.L", "ANTO.L", "AUL.L", "AV.L", "AZN.L", "BA.L" };

        private static Random _rand = new Random();

        private Timer _timer;

        public StockPricesService(Form hostForm)
        {
            _timer = new Timer();
            _timer.Interval = 300;
            _timer.Tick += Timer_Tick;
            _timer.Start();

            hostForm.Disposed += new EventHandler(hostForm_Disposed);
        }

        
        /// <summary>
        /// Provides a list of random stock prices
        /// </summary>
        public IEnumerable<StockPrice> GetCurrentPrices()
        {
            foreach (string symbol in s_symbols)
            {
                yield return new StockPrice()
                    {
                        Symbol =  symbol,
                        Price = RandomPrice()
                    };
            }
        }

        /// <summary>
        /// An event which indicates that some stock price has changed
        /// </summary>
        public event EventHandler<StockPriceUpdateEventArgs> StockPriceUpdate;

        /// <summary>
        /// Raises the StockPriceUpdate event
        /// </summary>
        protected void OnStockPriceUpdate(string symbol, double price)
        {
            if (StockPriceUpdate != null)
            {
                StockPriceUpdate(this, new StockPriceUpdateEventArgs(symbol, price));
            }
        }

        private double RandomPrice()
        {
            return _rand.NextDouble() * 100 + 10;
        }

        /// <summary>
        /// Handles the timer tick event to raise a random price update.
        /// </summary>
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (_rand.Next(2) != 0)
                return;

            string symbol = s_symbols[_rand.Next(s_symbols.Count)];
            OnStockPriceUpdate(symbol, RandomPrice());
        }

        private void hostForm_Disposed(object sender, EventArgs e)
        {
            _timer.Dispose();

            CheckEventHasNoSubscribers(StockPriceUpdate);
        }

        /// <summary>
        /// Detects whether an event has any subscribers
        /// </summary>
        [Conditional("DEBUG")]
        private void CheckEventHasNoSubscribers(Delegate eventDelegate)
        {
            if (eventDelegate != null)
            {
                // if the event has any subscribers, create an informative error message.
                if (eventDelegate.GetInvocationList().Length != 0)
                {
                    int subscriberCount = eventDelegate.GetInvocationList().Length;

                    // determine the consumers of this event
                    StringBuilder subscribers = new StringBuilder();
                    foreach (Delegate del in eventDelegate.GetInvocationList())
                    {
                        subscribers.Append((subscribers.Length != 0 ? ", " : "") + del.Target.ToString());
                    }

                    // name and shame them!
                    Debug.WriteLine(string.Format("Event: {0} still has {1} subscribers, with the following targets [{2}]",
                        eventDelegate.Method.Name, subscriberCount, subscribers.ToString()));
                }
            }
        }
    }

}
