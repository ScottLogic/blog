﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace MemoryLeakExamples
{
    public class StockPrice : INotifyPropertyChanged
    {
        private string _symbol;

        public string Symbol
        {
            get { return _symbol; }
            set { _symbol = value; OnPropertyChanged("Symbol"); }
        }

        private double _price;

        public double Price
        {
            get { return _price; }
            set
            {
                Change = value - _price;
                _price = value;
                OnPropertyChanged("Price");
            }
        }

        private double _change;

        public double Change
        {
            get { return _change; }
            private set { _change = value; OnPropertyChanged("Change"); }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion
    }
}
