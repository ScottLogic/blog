﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MemoryLeakExamples
{
    public class StockPriceUpdateEventArgs : EventArgs
    {
        public string Symbol { get; private set; }

        public double Price { get; private set; }

        public StockPriceUpdateEventArgs(string symbol, double price)
        {
            Symbol = symbol;
            Price = price;
        }
    }
}
