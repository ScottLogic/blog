﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MemoryLeakExamples
{
    public partial class StockPriceViewer : Form
    {
        private BindingList<StockPrice> _stockPrices;

        private StockPricesService _priceService;

        public StockPriceViewer(StockPricesService priceService)
        {
            InitializeComponent();

            _priceService = priceService;
            _stockPrices = new BindingList<StockPrice>(priceService.GetCurrentPrices().ToList());

            // subscribe to price updates
            priceService.StockPriceUpdate += PriceService_StockPriceUpdate;

            stockPriceBindingSource.DataSource = _stockPrices;

            Disposed += StockPriceViewer_Disposed;
        }

        private void StockPriceViewer_Disposed(object sender, EventArgs e)
        {
            // #####################################
            // un-comment this line to fix the memory leak!

            //_priceService.StockPriceUpdate -= PriceService_StockPriceUpdate;
        }
        

        /// <summary>
        /// Handles a price update event, updating the UI state.
        /// </summary>
        private void PriceService_StockPriceUpdate(object sender, StockPriceUpdateEventArgs e)
        {
            StockPrice price = _stockPrices.FirstOrDefault(s => s.Symbol == e.Symbol);
            if (price == null)
            {
                price = new StockPrice();
                _stockPrices.Add(price);
            }

            price.Price = e.Price;
        }
    }

}
