﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MemoryLeakExamples
{
    public partial class MainWindow : Form
    {
        StockPricesService _priceService;

        public MainWindow()
        {
            InitializeComponent();

            _priceService = new StockPricesService(this);

        }

        private void buttonPriceList_Click(object sender, EventArgs e)
        {
            StockPriceViewer viewer = new StockPriceViewer(_priceService);
            viewer.Show();
        }
    }
}
