﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Printing;

namespace PrintingExample
{
    public partial class MainPage : UserControl
    {

        private FrameworkElement _elementToPrint;
        private Double _elementOriginalWidth;
        private Double _elementOriginalHeight;

        public MainPage()
        {
            InitializeComponent();
        }

        private void Print(FrameworkElement elementToPrint, string documentName, bool stretchToFullSize)
        {
            PrintDocument doc = new PrintDocument();
            _elementToPrint = elementToPrint;
            doc.PrintPage += (s, args) =>
            {
                // Set element to be printed
                _elementOriginalWidth = _elementToPrint.Width;
                _elementOriginalHeight = _elementToPrint.Height;
                if (stretchToFullSize)
                {
                    _elementToPrint.Width = args.PrintableArea.Width;
                    _elementToPrint.Height = args.PrintableArea.Height;
                    // Printing only starts when args.PageVisual != null
                    // Only set args.PageVisual to elementToPrint once its size has been updated
                    _elementToPrint.SizeChanged += (s1, args1) =>
                    {
                        args.PageVisual = elementToPrint;
                    };
                }
                else
                {
                    args.PageVisual = elementToPrint;
                }
                             
            };

            doc.BeginPrint += (s, args) =>
            {
                // Show that printing has begun: not implemented in this case
            };
            doc.EndPrint += (s, args) =>
            {
                // Show that printing has ended: not implemented in this case

                // Reset printed element size to original
                _elementToPrint.Width = _elementOriginalWidth;
                _elementToPrint.Height = _elementOriginalHeight;
            };

            doc.Print(documentName);
        }

        #region Click even handlers

        private void PrintColumnChartButton_Click(object sender, RoutedEventArgs e)
        {
            Print(ColumnChart, "Column Chart", false);
        }

        private void PrintColumnChartButtonStrech_Click(object sender, RoutedEventArgs e)
        {
            Print(ColumnChart, "Column Chart", true);
        }

        private void PrintStackedLineChartButton_Click(object sender, RoutedEventArgs e)
        {
            Print(StackedLineChart, "Stacked Line Chart", false);
        }

        private void PrintStackedLineChartButtonStrech_Click(object sender, RoutedEventArgs e)
        {
            Print(StackedLineChart, "Stacked Line Chart", true);
        }

        private void PrintStackedAreaChartButton_Click(object sender, RoutedEventArgs e)
        {
            Print(StackedAreaChart, "Stacked Area", false);
        }

        private void PrintStackedAreaChartStrech_Click(object sender, RoutedEventArgs e)
        {
            Print(StackedAreaChart, "Stacked Area", true);
        }

        private void PrintPieChartButton_Click(object sender, RoutedEventArgs e)
        {
            Print(PieChart, "Pie Chart", false);
        }

        private void PrintPieChartButtonStrech_Click(object sender, RoutedEventArgs e)
        {
            Print(PieChart, "Pie Chart", true);
        }

        private void PrintWholePageButton_Click(object sender, RoutedEventArgs e)
        {
            Print(LayoutRoot, "Whole Page", false);
        }

        private void PrintWholePageButtonStrech_Click(object sender, RoutedEventArgs e)
        {
            Print(LayoutRoot, "Whole Page", true);
        }

        #endregion
        
    }
}
