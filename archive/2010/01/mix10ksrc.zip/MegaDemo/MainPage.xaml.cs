﻿using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Media.Imaging;
using System;
using System.Windows.Media;
using System.Windows;
using System.Windows.Resources;
using System.Collections.Generic;
using k = System.Windows.Media.MediaSourceAttributesKeys;
using j = System.Windows.Media.MediaStreamAttributeKeys;
using M = System.Math;
using System.IO;
using System.Windows.Shapes;

namespace S
{
		public class A : Application
		{
				public A()
				{
						Startup += (i, j) => RootVisual = new MainPage();
				}
		}

    public partial class MainPage : UserControl
    {
        int time = 0;
        double scrollPos = 700;
        int[] sins;
        int[] wave;
        Random rand = new Random();

        M3 mediaSource;

        public MainPage()
        {
            var bitmap = new WriteableBitmap(300, 200);

            InitializeComponent();

            grid.Clip = new RectangleGeometry()
            {
                Rect = new Rect(0, 0, grid.Width, grid.Height)
            };

            var mediaElement = new MediaElement() { Volume = 1 };
            LayoutRoot.Children.Add(mediaElement);
            var f = Application.GetResourceStream(new Uri("S;component/4k_chill.mp3", UriKind.Relative));
            mediaSource = new M3(f.Stream);
            mediaElement.SetSource(mediaSource);

            for (int u = 0; u < 50; u++)
            {
                var w = new Point(rand.Next(700), rand.Next(500));
                var n = new Ellipse()
                {
                    Width = 3,
                    Height = 3,
                    Tag = w,
                    Opacity = rand.NextDouble(),
                    Fill = rec.Fill
                };
                n.SetValue(Canvas.LeftProperty, w.X);
                n.SetValue(Canvas.TopProperty, w.Y);
                n.SetValue(Canvas.ZIndexProperty, (int)(n.Opacity * 100));
                LayoutRoot.Children.Add(n);
            }

            scroll.Text = "Welcome to Colin E's Mix10k Old Skool Demo! Scrolly text~ starfields & MP3 music~ all packed into 10k. Thanx to uB of 8bitcollective.com for the MP3 music and boomlinde for his help. Greetz to the WPF Disciples~ and all @jugglingdb.com. A big shout out to all at ScottLogic~ especially Team Saxo. Vote Colin E. ... Silverlight rocks - RIP Flash";

            int[] d = new int[8];
            int[] p = new int[8];
            sins = new int[360];
            wave = new int[32];
            for (int i = 0; i < 360; i++)
            {
                sins[i] = (int)(M.Sin(((double)i) * 0.0174) * 35);
                wave[i % 32] = (byte)(i % 32 == 16 ? 255 : i % 16 * (((i / 16) % 2) == 0 ? 15 : -15));
                p[i % 8] = rand.Next(300) + 100;
                d[i % 8] = rand.Next(10) - 5;
            }

            for (double h = 0; h < 6.28; h += 1.04)
            {
                var b = new TextBlock()
                {
                    Text = scroll.Text,
                    FontSize = 65,
                    FontWeight = scroll.FontWeight,
                    Foreground = rec.Fill
                };
                b.SetValue(Canvas.TopProperty, M.Sin(h) * 3);
                b.SetValue(Canvas.LeftProperty, M.Cos(h) * 3);
                scrollHost.Children.Insert(0, b);
            }

            var t = new DispatcherTimer();
            t.Tick += (s, e2) =>
            {
                var h = sin2(10) / 15 + .8;
                border.RenderTransform = new ScaleTransform()
                {
                    CenterX = 350,
                    CenterY = 350,
                    ScaleX = h,
                    ScaleY = h
                };
                border.Projection = new PlaneProjection()
                {
                    RotationY = sin2(15) * 15,
                    RotationX = sin2(18) * 10
                };
                foreach (var b in LayoutRoot.Children)
                {
                    var n = b as Ellipse;
                    if (n != null)
                    {
                        var a = (Point)n.Tag;
                        a.X -= n.Opacity * 20;
                        if (a.X < 0)
                        {
                            a.X = 700;
                            a.Y = rand.Next(500);
                        }
                        n.SetValue(Canvas.LeftProperty, a.X);
                        n.SetValue(Canvas.TopProperty, a.Y);
                        n.Tag = a;
                    }
                }

                if (mediaSource.p == 1224)
                    u = true;
                if (mediaSource.p == 1080 && u)
                {
                    u = false;
                    canvas.Children.Clear();
                    for (int i = 0; i < 60000; i++)
                        bitmap.Pixels[i] = 0;
                    bitmap.Invalidate();

                    rec.Opacity = 1.0;
                    fx++;
                    gx = 0;
                }

                if (mediaSource.p == 3024 || mediaSource.p == 3312)
                {
                    rec.Opacity = 1.0;
                    gx = mediaSource.p == 3024 ? 1 : 2;
                }

                rec.Opacity -= 0.1;
                time++;
                if (fx % 4 == 0)
                {
                    for (int i = 0; i < 8; i++)
                        EnforceBounds(ref d[i], ref p[i], i);

                    CreateLine(p[0], p[1], p[2], p[3]);
                    CreateLine(p[2], p[3], p[4], p[5]);
                    CreateLine(p[4], p[5], p[6], p[7]);
                    CreateLine(p[6], p[7], p[0], p[1]);
                }
                else
                {
                    int i = 0;
                    for (int y = 0; y < 200; y++) for (int x = 0; x < 300; x++)
                        {
                            int px = 1;
                            if (fx % 5 == 0 || fx % 5 == 1)
                            {
                                if (gx > 0) px = 15;
                            }
                            if (fx % 5 == 2)
                            {
                                px = 5;
                            }
                            if (fx % 5 == 3)
                            {
                                px = 10;
                            }
                            int tx = x - x % px, ty = y - y % px;
                            if (fx % 4 == 1)
                            {
                                int x1 = sin1(8) + 200, y1 = sin1(3) * 10 + 100, g = (tx - x1) * (tx - x1);
                                var d2 = M.Sqrt(g + (ty - y1) * (ty - y1));
                                int y2 = sin1(13) * 2 + 80;
                                d2 += M.Sqrt(g + (ty - y2) * (ty - y2));
                                int n = (int)d2 + (tx + time * 6) % 360;
                                bitmap.Pixels[i++] = 255 << 24 | (sins[n % 360] * 3 + 110) << 16 | (sins[(n + 90) % 360] * 3 + 110) << 8;
                            }
                            else
                            {
                                int x1 = sin1(8) + 150, y1 = sin1(3) + 100, x2 = sin1(4) + 150, y2 = sin1(7) + 100;
                                byte c = fn(tx, ty, x1, y1);
                                c += fn(tx, ty, x2, y2);
                                bitmap.Pixels[i++] = 255 << 24 | c << (8 * (fx % 3));
                            }
                        }
                    bitmap.Invalidate();
                }
                scrollHost.SetValue(Canvas.LeftProperty, scrollPos);
                scrollPos -= 5;
                if (scrollPos < -13000)
                    scrollPos = 700;
                scrollHost.SetValue(Canvas.TopProperty, 200 -
                    M.Abs(sin1(10)) * ((double)(sin1(2)) + 70) / 50);
            };
            t.Interval = new TimeSpan(400000);
            t.Start();

            image.Source = bitmap;

        }



        int fx = 0;
        int gx = 0;
        bool u = false;

        double sin2(double f)
        {
            return M.Sin(((double)time) / f);
        }



        void CreateLine(int x, int y, int x2, int y2)
        {
            canvas.Children.Add(new Line()
            {
                X1 = x,
                X2 = x2,
                Y1 = y,
                Y2 = y2,
                Stroke = new SolidColorBrush(
                    Color.FromArgb(255, i(4), i(0), i(7)))
            });
        }

        byte i(int j) { return (byte)(sin1(j) + 70); }

        void EnforceBounds(ref int d, ref int v, int i)
        {
            int z = i % 2 == 0 ? 600 : 400;
            v += d;
            if (v > z || v < 0)
            {
                v -= d;
                d = -M.Sign(d) * (rand.Next(10) + 4);
            }
        }

        int sin1(int f)
        {
            return sins[time * f % 360];
        }

        byte fn(int x, int y, int x1, int y1)
        {
            return (byte)(wave[((int)M.Sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1))) % 32] / 2);
        }


    }

    public class M3 : MediaStreamSource
    {
        protected override void CloseMedia() { }protected override void GetDiagnosticAsync(MediaStreamSourceDiagnosticKind diagnosticKind) { }protected override void SwitchMediaStreamAsync(MediaStreamDescription mediaStreamDescription) { }
        Stream s; MediaStreamDescription d; volatile public int p = 0;
        public M3(Stream e)
        { s = e; }
        protected override void OpenMediaAsync()
        {
            var sb = new Dictionary<k, string>() { { k.Duration, "300" } };
            d = new MediaStreamDescription(MediaStreamType.Audio, new Dictionary<j, string>() { { MediaStreamAttributeKeys.CodecPrivateData, "55000100401F0000E8030000010000000C00010000000000480001000000" } });
            var md = new List<MediaStreamDescription>() { d };
            s.Position = 189;
            ReportOpenMediaCompleted(sb, md);
        }
        protected override void GetSampleAsync(MediaStreamType t)
        {
            if (p + 289 > s.Length)
            { s.Position = p = 0; }
            var w = new MediaStreamSample(d, s, p, 72, p, new Dictionary<MediaSampleAttributeKeys, string>());
            ReportGetSampleCompleted(w);
            p = (int)s.Position;
            s.Position += 4;
        }
        protected override void SeekAsync(long s)
        { ReportSeekCompleted(s); }
    }
}
