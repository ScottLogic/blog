﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Crunch
{
	class Program
	{
		static string sourceDir = @"..\..\..\MegaDemo\";
		static string targetDir = @"..\..\..\MegaDemoMinified\";

static Dictionary<string, string> reps = new Dictionary<string, string>()
{
  {System.Environment.NewLine, ""}, 
  {"  ", " "},
	{" = ", "="},
  {" == ", "=="},
  {" * ", "*"},
	{" > ", ">"},
  {" < ", "<"},
  {" && ", "&&"},
  {" || ", "||"},
  {" += ", "+="},
  {" ? ", "?"},
  {" + ", "+"},
  {" % ", "%"},
  {" : ", ":"},
  {" { ", "{"},
  {" } ", "}"},
  {" - ", "-"},
	{", ", ","},
  {"; ", ";"},
  {" (", "("},
  {") ", ")"},
	{"\t", ""},

  // methods 
  {"Timer_Tick", "T"},
  {"CreateLine", "g"},
  {"DrawLines", "ln"},
  {"EnforceBounds", "b"},  
  {"sin1", "Q"},  
  {"sin2", "W"},  

  // global
  {"bitmap", "bm"},
  {"mediaSource", "ms"},
  {"time", "w"},
  {"sins", "r"},
  {"rand", "R"},
  {"scrollHost", "S"},    
  {"scrollPos", "l"},    
  

  // xaml
  {"grid", "q"},
  {"image", "o"},
  {"canvas", "c"},
  {"MainPage", "Y"},
  {"LayoutRoot", "rt"},
  {"border", "k"},
  {"rec", "z"},


  // local
  {"mediaElement", "e"},            
	
};


		static void Main(string[] args)
		{
			go("MainPage.xaml.cs");
			go("MainPage.xaml");
		}

		static int go(string file)
		{
			StreamReader streamReader = new StreamReader(sourceDir + file);
			string text = streamReader.ReadToEnd();
			streamReader.Close();

			int len = text.Length;
			text = text.Replace("  ", " ");
			while (text.Length != len)
			{
				len = text.Length;
				text = text.Replace("  ", " ");
			}


			int old = text.Length;

			foreach (var rep in reps)
			{
				text = text.Replace(rep.Key, rep.Value);
			}



			File.WriteAllText(targetDir + file, text);

			return text.Length;
		}
	}
}
