﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TemplatedListBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Person> _people = new List<Person>();

        public MainWindow()
        {
            InitializeComponent();

            _people.Add(new Person(14, "John, the Tester", @"First details text is used to check it out, if text fits correctly the bounds of an item.
As you can see, everything fits nicely.", "image1.jpg"));
            _people.Add(new Person(99, "Bill", "phone +345645464, fax +6546546546, email email@email.com", "image2.jpg"));
            _people.Add(new Person(71, "Peter", "ICQ 56465464, msn hot@hotmail.com, phone +5465464654", "image3.jpg"));

            DataContext = _people;
        }
    }
}
