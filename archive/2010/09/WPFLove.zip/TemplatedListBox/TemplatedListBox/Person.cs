﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemplatedListBox
{
    /// <summary>
    /// A simple business object
    /// </summary>
    public class Person
    {
        public Person()
        {
        }

        public Person(int id, string name, string details, string image)
        {
            Id = id;
            Name = name;
            Details = details;
            Image = image;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }
        public string Image { get; set; }
    }

    public class PersonCollection : List<Person>
    {
    }
}
