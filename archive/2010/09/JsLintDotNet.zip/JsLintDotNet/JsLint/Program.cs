﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ScottLogic.JsLintDotNet;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
			if (args.Length == 0 || args.Length % 2 == 1)
			{
				Console.WriteLine("JsLint -i file.js [-o options]");
				Console.WriteLine();
				Console.Write("Options Format:");
				Console.WriteLine(JsLintConfiguration.GetParseOptions());
				Console.WriteLine();
				Console.WriteLine("E.g.");
				Console.WriteLine("JsLint -i input.js -i input2.js");
				Console.WriteLine("JsLint -i input.js -o \"evil=False,eqeqeq,predef=Microsoft System\"");
				return;
			}

			List<string> inputFiles = new List<string>();
			JsLintConfiguration configuration = null;

			for (int i = 0; i < args.Length; i+=2 )
			{
				string arg = args[i].Trim().ToLower();
				string value = args[i + 1];
				string filter = null;
				switch (arg)
				{
					case "-i":
						if (File.Exists(value))
						{
							inputFiles.Add(value);
						}
						else
						{
							Console.WriteLine(String.Format("Cannot find file {0}", value));
							return;
						}
						break;
					case "-d":
					case "-rd":

						if (value.Contains("*"))
						{
							filter = Path.GetFileName(value);
							value = value.Substring(0, value.Length - filter.Length);
						}
						if (!Directory.Exists(value))
						{
							Console.WriteLine(string.Format("Directory does not exist {0}", value));
							return;
						}

						List<DirectoryInfo> directorys = new List<DirectoryInfo>() { 
							new DirectoryInfo(value) };

						while (directorys.Count > 0)
						{
							DirectoryInfo di = directorys[0];
							directorys.RemoveAt(0);
							FileInfo[] files;
							if (!string.IsNullOrWhiteSpace(filter))
							{
								files = di.GetFiles(filter);
							}
							else
							{
								files = di.GetFiles();
							}

							foreach (FileInfo fi in files)
							{
								inputFiles.Add(fi.FullName);
							}

							if (arg == "-rd")
							{
								directorys.AddRange(di.GetDirectories());
							}
						}
						break;
					case "-o":
						if (configuration != null)
						{
							Console.WriteLine("Cannot specify multiple options");
						}
						try
						{
							configuration = JsLintConfiguration.ParseString(value);
						}
						catch (Exception e)
						{
							Console.WriteLine(e.Message);
							return;
						}
						break;
				}
			}

			if (configuration == null)
			{
				configuration = new JsLintConfiguration();
			}

            JsLinter lint = new JsLinter();

			foreach (string file in inputFiles)
			{
				string fileContents = File.ReadAllText(file);
				JsLintResult result = lint.Lint(fileContents, configuration);

				if (result.Errors.Count > 0)
				{
					if (inputFiles.Count > 0)
					{
						Console.WriteLine(String.Format("File {0}", file));
					}
					foreach (JsLintData error in result.Errors)
					{
						Console.WriteLine(string.Format("Line: {0} Character: {1} Reason: {2}", error.Line, error.Character, error.Reason));
					}
				}
			}

            Console.ReadKey();
        }


    }
}
