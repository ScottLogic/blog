﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScottLogic.JsLintDotNet
{
	/// <summary>
	///  Represents configuring the Js Lint(er)
	/// </summary>
	public class JsLintConfiguration
	{
		public JsLintConfiguration()
		{
			BoolOptions = JsLintBoolOption.browser | 
						JsLintBoolOption.bitwise | 
						JsLintBoolOption.evil | 
						JsLintBoolOption.eqeqeq | 
						JsLintBoolOption.forin |
						JsLintBoolOption.immed |
						JsLintBoolOption.newcap |
						JsLintBoolOption.undef;
			ErrorOnUnused = true;
		}

		/// <summary>
		///  Maximum errors reported
		/// </summary>
		public int MaxErrors { get; set; } 

		/// <summary>
		///  List of strings predefined
		/// </summary>
		public List<string> PreDefined { get; set; }

		/// <summary>
		///  The Js Lint boolean options specified
		/// </summary>
		public JsLintBoolOption BoolOptions { get; set; }

		/// <summary>
		///  Whether to show unused variables as errors
		/// </summary>
		public bool ErrorOnUnused { get; set; }

		/// <summary>
		///  Descriptions of each option, pulled from Js Lint
		/// </summary>
		public static readonly Dictionary<JsLintBoolOption, string> Descriptions = new Dictionary<JsLintBoolOption, string>() {
					{ JsLintBoolOption.adsafe, "if ADsafe should be enforced" },
					{ JsLintBoolOption.bitwise, "if bitwise operators should not be allowed" },
					{ JsLintBoolOption.browser, "if the standard browser globals should be predefined" },
					{ JsLintBoolOption.cap, "if upper case HTML should be allowed" },
					{ JsLintBoolOption.css, "if CSS workarounds should be tolerated" },
					{ JsLintBoolOption.debug, "if debugger statements should be allowed" },
					{ JsLintBoolOption.devel, "if logging should be allowed (console, alert, etc.)" },
					{ JsLintBoolOption.eqeqeq, "if === should be required" },
					{ JsLintBoolOption.es5, "if ES5 syntax should be allowed" },
					{ JsLintBoolOption.evil, "if eval should be allowed" },
					{ JsLintBoolOption.forin, "if for in statements must filter" },
					{ JsLintBoolOption.fragment, "if HTML fragments should be allowed" },
					{ JsLintBoolOption.immed, "if immediate invocations must be wrapped in parens" },
					{ JsLintBoolOption.laxbreak, "if line breaks should not be checked" },
					{ JsLintBoolOption.newcap, "if constructor names must be capitalized" },
					{ JsLintBoolOption.nomen, "if names should be checked" },
					{ JsLintBoolOption.on, "if HTML event handlers should be allowed" },
					{ JsLintBoolOption.onevar, "if only one var statement per function should be allowed" },
					{ JsLintBoolOption.passfail, "if the scan should stop on first error" },
					{ JsLintBoolOption.plusplus, "if increment/decrement should not be allowed" },
					{ JsLintBoolOption.regexp, "if the . should not be allowed in regexp literals" },
					{ JsLintBoolOption.rhino, "if the Rhino environment globals should be predefined" },
					{ JsLintBoolOption.undef, "if variables should be declared before used" },
					{ JsLintBoolOption.safe, "if use of some browser features should be restricted" },
					{ JsLintBoolOption.windows, "if MS Windows-specigic globals should be predefined" },
					{ JsLintBoolOption.strict, "require the \"use strict\"; pragma" },
					{ JsLintBoolOption.sub, "if all forms of subscript notation are tolerated" },
					{ JsLintBoolOption.white, "if strict whitespace rules apply" },
					{ JsLintBoolOption.widget , "if the Yahoo Widgets globals should be predefined" }};

		/// <summary>
		///  Returns human readable text description of what the Parse function will process
		/// </summary>
		public static string GetParseOptions()
		{
			StringBuilder returner = new StringBuilder();

			returner.AppendLine("[option : value | option][,option: value | option]...");
			returner.AppendLine();
			returner.AppendLine("maxerr  : Number - maximum number of errors");
			returner.AppendLine("predef  : String - space seperated list of predefined globals");
			returner.AppendLine("unused  : Boolean - If true, errors on unused local vars");

			foreach (JsLintBoolOption boolOption in Enum.GetValues(typeof(JsLintBoolOption)))
			{
				returner.AppendFormat("{0} : Boolean - {1}", boolOption.ToString(), Descriptions[boolOption]);
				returner.AppendLine();
			}

			return returner.ToString();
		}

		/// <summary>
		///  Parses a string and extracts the options, returning a new JsLintConfiguration object
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		public static JsLintConfiguration ParseString(string s)
		{
			JsLintConfiguration returner = new JsLintConfiguration();

			// if there are no options we return an empty default object
			if (!string.IsNullOrWhiteSpace(s))
			{
				// otherwise, wipe the bool options
				returner.BoolOptions = (JsLintBoolOption)0;

				// now go through each string
				string[] options = s.Split(',');
				foreach (string option in options)
				{

					string[] optionValue = option.Split(':', '=');

					// test if it is a single value without assigment ("evil" == "evil:true")
					if (optionValue.Length == 1)
					{
						if (optionValue[0].Trim() == "unused")
						{
							returner.ErrorOnUnused = true;
						}
						else
						{
							// assume boolean value
							JsLintBoolOption truthy;
							if (Enum.TryParse<JsLintBoolOption>(optionValue[0].Trim(), out truthy))
							{
								returner.BoolOptions |= truthy;
							}
							else
							{
								throw new Exception("Unrecognised boolean option: " + optionValue[0]);
							}
						}
					}
					else if (optionValue.Length == 2)
					{
						// otherwise we have key value pair

						string key = optionValue[0].Trim();
						switch (key)
						{
							case "maxerr":
								int maxerr;
								if (int.TryParse(optionValue[1].Trim(), out maxerr))
								{
									returner.MaxErrors = maxerr;
								}
								else
								{
									throw new Exception("Maximum Errors value is not an integer: " + optionValue);
								}
								break;
							case "unused":
								bool unused;
								if (bool.TryParse(optionValue[1].Trim(), out unused))
								{
									returner.ErrorOnUnused = unused;
								}
								else
								{
									throw new Exception("Unrecognised boolean: " + optionValue);
								}

								break;
							case "predef":
								string[] predefines = optionValue[1].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

								if (predefines.Length > 0)
								{
									returner.PreDefined = new List<string>(predefines);
								}
								break;
							default:
								// assume boolean value
								JsLintBoolOption boolOption;
								if (Enum.TryParse<JsLintBoolOption>(optionValue[0].Trim(), out boolOption))
								{
									bool onOff;

									if (bool.TryParse(optionValue[1].Trim(), out onOff))
									{
										if (onOff)
										{
											returner.BoolOptions |= boolOption;
										}
										else
										{
											returner.BoolOptions &= ~boolOption;
										}
									}
									else
									{
										throw new Exception("Ivalid boolean: " + optionValue[1]);
									}
								}
								else
								{
									throw new Exception("Unrecognised boolean option: " + optionValue[0]);
								}

								break;
						}
					}
					else
					{
						throw new Exception("Unrecognised option format - too many colons");
					}
				}
			}

			return returner;
		}

		/// <summary>
		///  Creates an (javascript compatible) object that JsLint can use for options.
		/// </summary>
		/// <returns></returns>
		public Dictionary<string, object> ToJsOptionVar()
		{
			Dictionary<string, object> returner = new Dictionary<string, object>();

			foreach (JsLintBoolOption option in Enum.GetValues(typeof(JsLintBoolOption)))
			{
				returner[option.ToString()] = (option & BoolOptions) == option;
			}			

			if (PreDefined != null && PreDefined.Count > 0)
			{
				returner["predef"] = String.Join(",", PreDefined.ToArray());
			}

			if (MaxErrors > 0)
			{
				returner["maxerr"] = MaxErrors;
			}

			return returner;
		}
	}
}
