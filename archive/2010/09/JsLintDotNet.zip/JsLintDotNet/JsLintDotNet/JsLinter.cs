﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Noesis.Javascript;
using System.IO;
using System.Reflection;

namespace ScottLogic.JsLintDotNet
{
	/// <summary>
	///  Constructs an object capable of linting javascript files and returning the result of JS Lint
	/// </summary>
    public class JsLinter
    {
        private JavascriptContext _context;
        private object _lock = new Object();

        public JsLinter()
        {
            _context = new JavascriptContext();
			string jslint = "";
			using (Stream jslintStream = Assembly.GetExecutingAssembly()
											.GetManifestResourceStream(
											@"JsLintDotNet.fulljslint.js"))
			{
				using (StreamReader sr = new StreamReader(jslintStream))
				{
					jslint = sr.ReadToEnd();
				}
			}

            _context.Run(jslint);

            _context.Run(
@"lintRunner = function (dataCollector, javascript, options) {
    JSLINT(javascript, options);
    var data = JSLINT.data();
    if  (data) {
        dataCollector.ProcessData(data);
    }
};");
        }

		public JsLintResult Lint(string javascript)
		{
			return Lint(javascript, new JsLintConfiguration());
		}

        public JsLintResult Lint(string javascript, JsLintConfiguration configuration)
        {
			if (string.IsNullOrEmpty(javascript))
			{
				throw new ArgumentNullException("javascript");
			}

			if (configuration == null)
			{
				throw new ArgumentNullException("configuration");
			}

            lock (_lock)
            {
				LintDataCollector dataCollector = new LintDataCollector(configuration.ErrorOnUnused);
                // Setting the externals parameters of the context
				_context.SetParameter("dataCollector", dataCollector);
                _context.SetParameter("javascript", javascript);
				_context.SetParameter("options", configuration.ToJsOptionVar());

                // Running the script
                _context.Run("lintRunner(dataCollector, javascript, options);");

                JsLintResult result = new JsLintResult() { Errors = dataCollector.Errors };

                return result;
            }
        }

		private class LintDataCollector
		{
			private List<JsLintData> _errors = new List<JsLintData>();
			private bool _processUnuseds = false;

			public List<JsLintData> Errors
			{
				get { return _errors; }
			}

			public LintDataCollector(bool processUnuseds)
			{
				_processUnuseds = processUnuseds;
			}

			public void ProcessData(object data)
			{
				Dictionary<string, object> dataDict = data as Dictionary<string, object>;

				if (dataDict != null)
				{
					if (dataDict.ContainsKey("errors"))
					{
						ProcessListOfObject(dataDict["errors"], (error) =>
						{
							JsLintData jsError = new JsLintData();
							if (error.ContainsKey("line"))
							{
								jsError.Line = (int)error["line"];
							}

							if (error.ContainsKey("character"))
							{
								jsError.Character = (int)error["character"];
							}

							if (error.ContainsKey("reason"))
							{
								jsError.Reason = (string)error["reason"];
							}

							_errors.Add(jsError);
						});
					}

					if (_processUnuseds && dataDict.ContainsKey("unused"))
					{
						ProcessListOfObject(dataDict["unused"], (unused) =>
						{
							JsLintData jsError = new JsLintData();
							if (unused.ContainsKey("line"))
							{
								jsError.Line = (int)unused["line"];
							}

							if (unused.ContainsKey("name"))
							{
								jsError.Reason = string.Format("Unused Variable : {0}", unused["name"]);
							}

							_errors.Add(jsError);
						});
					}
				}
			}

			private void ProcessListOfObject(object obj, Action<Dictionary<string, object>> processor)
			{
				object[] array = obj as object[];

				if (array != null)
				{
					foreach (object objItem in array)
					{
						Dictionary<string, object> objItemDictionary = objItem as Dictionary<string, object>;

						if (objItemDictionary != null)
						{
							processor(objItemDictionary);
						}
					}
				}
			}
		}
    }
}
