﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ScottLogic.JsLintDotNet;

namespace JsLintDotNet.Test
{
	[TestClass]
	public class LinterUnitTests
	{
		[TestMethod]
		public void TestMultipleCalls()
		{
			JsLinter lint = new JsLinter();
            JsLintResult result = lint.Lint(
							@"var i, y; for (i = 0; i < 5; i++) console.Print(message + ' (' + i + ')'); number += i;");

			Assert.AreEqual(4, result.Errors.Count);

			JsLintResult result2 = lint.Lint(
							@"function annon() { var i, number; for (i = 0; i === 5; i++) { number += i; } }");

			Assert.AreEqual(0, result2.Errors.Count);

            JsLintResult result3 = lint.Lint(
							@"function annon() { var i, number, x; for (i = 0; i == 5; i++) { number += i; } }");

			Assert.AreEqual(2, result3.Errors.Count);
		}

		[TestMethod]
		public void TestMultipleDifferentOptions()
		{
			JsLinter lint = new JsLinter();
            JsLintResult result = lint.Lint(
							@"function annon() { var i, number, x; for (i = 0; i === 5; i++) { number += ++i; } }", 
							new JsLintConfiguration() { ErrorOnUnused = true, BoolOptions = JsLintBoolOption.eqeqeq | JsLintBoolOption.plusplus} );

			Assert.AreEqual(3, result.Errors.Count);

			JsLintResult result2 = lint.Lint(
							@"function annon() { var i, number; for (i = 0; i === 5; i++) { number += i; } }",
							new JsLintConfiguration() { ErrorOnUnused = false, BoolOptions = (JsLintBoolOption)0 });

			Assert.AreEqual(0, result2.Errors.Count);
		}

		[TestMethod]
		public void TestArgumentParsing()
		{
			JsLintConfiguration config = JsLintConfiguration.ParseString("  maxerr : 2,eqeqeq,unused :    TRUE,predef : test1 TEST2   3 ,evil:false , browser : true");

			Assert.AreEqual(2, config.MaxErrors);
			Assert.AreEqual(JsLintBoolOption.eqeqeq | JsLintBoolOption.browser, config.BoolOptions);
			Assert.AreEqual(true, config.ErrorOnUnused);
			Assert.AreEqual(3, config.PreDefined.Count);
			Assert.AreEqual("test1", config.PreDefined[0]);
			Assert.AreEqual("TEST2", config.PreDefined[1]);
			Assert.AreEqual("3", config.PreDefined[2]);
		}

		[TestMethod]
		public void TestArgumentParsing2()
		{
			JsLintConfiguration config = JsLintConfiguration.ParseString("  maxerr : 400,eqeqeq : true,unused :    FALSE,predef : 1,evil:true , browser : false");

			Assert.AreEqual(400, config.MaxErrors);
			Assert.AreEqual(JsLintBoolOption.eqeqeq | JsLintBoolOption.evil, config.BoolOptions);
			Assert.AreEqual(false, config.ErrorOnUnused);
			Assert.AreEqual(1, config.PreDefined.Count);
			Assert.AreEqual("1", config.PreDefined[0]);
		}

	}
}
