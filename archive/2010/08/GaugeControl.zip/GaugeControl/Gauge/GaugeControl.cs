﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace GaugeControl
{
  public class GaugeControl : Control, INotifyPropertyChanged
  {
    public GaugeControl()
    {
      QualitativeRange = new QualitativeRanges();
      this.DefaultStyleKey = typeof(GaugeControl);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();

      Grid root = GetTemplateChild("LayoutRoot") as Grid;
      root.DataContext = this;
    }

    #region Value DP

    /// <summary>
    /// Gets / sets the Gauge value
    /// </summary>
    public double Value
    {
      get { return (double)GetValue(ValueProperty); }
      set { SetValue(ValueProperty, value); }
    }

    DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(double),
      typeof(GaugeControl), new PropertyMetadata(50.0, OnValuePropertyChanged));

    private static void OnValuePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
      ((GaugeControl)d).OnPropertyChanged("Value");
    }

    #endregion

    #region Maximum DP

    /// <summary>
    /// Gets / sets the Gauge Maximum
    /// </summary>
    public double Maximum
    {
      get { return (double)GetValue(MaximumProperty); }
      set { SetValue(MaximumProperty, value); }
    }

    DependencyProperty MaximumProperty = DependencyProperty.Register("Maximum", typeof(double),
      typeof(GaugeControl), new PropertyMetadata(100.0));

    #endregion

    #region QualitativeRanges DP

    /// <summary>
    /// Gets / sets the Gauges Qualitative Ranges
    /// </summary>
    public QualitativeRanges QualitativeRange
    {
      get { return (QualitativeRanges)GetValue(QualitativeRangeProperty); }
      set { SetValue(QualitativeRangeProperty, value); }
    }

    DependencyProperty QualitativeRangeProperty = DependencyProperty.Register("QualitativeRange", typeof(QualitativeRanges),
      typeof(GaugeControl), new PropertyMetadata(null));

    #endregion

    #region Minimum DP

    /// <summary>
    /// Gets / set the Gauge minimum value
    /// </summary>
    public double Minimum
    {
      get { return (double)GetValue(MinimumProperty); }
      set { SetValue(MinimumProperty, value); }
    }

    DependencyProperty MinimumProperty = DependencyProperty.Register("Minimum", typeof(double),
      typeof(GaugeControl), new PropertyMetadata(0.0));

    #endregion

    #region INotifyPropertyChanged

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }

    #endregion
  }

  public class QualitativeRanges : ObservableCollection<QualitativeRange>
  { }

  /// <summary>
  /// Defines a single qualitative range value
  /// </summary>
  public class QualitativeRange
  {
    private double maximum;

    public double Maximum
    {
      get { return maximum; }
      set { maximum = value; }
    }

    private Color color;

    public Color Color
    {
      get { return color; }
      set { color = value; }
    }
  }
}
