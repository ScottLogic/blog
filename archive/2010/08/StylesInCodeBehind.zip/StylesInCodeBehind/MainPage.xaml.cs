﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace StylesInCodeBehind
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            // Create the Style object and set it's TargetType
            var style = new Style();
            style.TargetType = typeof(Ellipse);

            // Add the Setters to the Style
            var fillColor = new SolidColorBrush(){Color=Colors.Green};
            var strokeColor = new SolidColorBrush() { Color = Colors.Blue };
            style.Setters.Add(new Setter(){Property =Ellipse.FillProperty,Value=fillColor});
            style.Setters.Add(new Setter() { Property = Ellipse.StrokeProperty, Value = strokeColor });
            style.Setters.Add(new Setter() { Property = Ellipse.StrokeThicknessProperty, Value = 4 });

            // Assign the Style to an element
            MyEllipse.Style = style;
        }
    }
}
