﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Windows.Threading;

namespace StylePropertyChanged
{
    public partial class MainPage : UserControl
    {

        private static TextBlock _tbxBoxMessage;

        public MainPage()
        {
            InitializeComponent();
            RegisterStyleChangedNotification();
            _tbxBoxMessage = TbxMessage;
        }

        private void RegisterStyleChangedNotification()
        {
            // Create a binding for the Style property on the MyEllipse element
            string propertyName = "Style";
            FrameworkElement element = MyEllipse;
            Binding binding = new Binding(propertyName) { Source = element };

            // Create an attached property with the ListenAttached_Style name
            // The OnStylePropertyChanged handler will be called when this property has changed
            var prop = System.Windows.DependencyProperty.RegisterAttached(
                "ListenAttached" + propertyName,
                typeof(object),
                typeof(UserControl),
                new System.Windows.PropertyMetadata(OnStylePropertyChanged));

            // Bind the newly created attached property to the Style
            element.SetBinding(prop, binding);
        }

        private static void OnStylePropertyChanged(DependencyObject d,  DependencyPropertyChangedEventArgs e)
        {
            Ellipse myClass = d as Ellipse;
            if (e.OldValue != null)
            {
                _tbxBoxMessage.Text = "The style of the ellipse has been changed!";
            }
        }

        private void ButtonChangeEllipseStyle_Click(object sender, RoutedEventArgs e)
        {
            MyEllipse.Style = Resources["BlueEllipseStyle"] as Style;
        }        
    }
}
