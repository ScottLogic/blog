﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Controls.DataVisualization.Charting;

namespace HistogramToolkit
{
  public partial class MainPage : UserControl
  {
    private int[] pixelData;

    private WriteableBitmap bitmap;

    private bool lButtonDown = false;

    public MainPage()
    {
      InitializeComponent();

      image.ImageOpened += new EventHandler<RoutedEventArgs>(Image_ImageOpened);
      
      var throttledEvent = new ThrottledMouseMoveEvent(image);
      throttledEvent.ThrottledMouseMove += new MouseEventHandler(ThrottledEvent_ThrottledMouseMove);
    }

    /// <summary>
    /// Obtains the image data once it is loaded
    /// </summary>
    private void Image_ImageOpened(object sender, RoutedEventArgs e)
    {
      if (bitmap == null)
      {
        bitmap = new WriteableBitmap((BitmapImage)image.Source);
        image.Source = bitmap;
        pixelData = bitmap.Pixels;
      }
    }

    /// <summary>
    /// Handles mouse move to draw the line and intensity histograms
    /// </summary>
    private void ThrottledEvent_ThrottledMouseMove(object sender, MouseEventArgs e)
    {
      if (!lButtonDown)
        return;

      line.X2 = e.GetPosition(grid).X;
      line.Y2 = e.GetPosition(grid).Y;

      // compute distance between the points
      double distance = Math.Sqrt((line.X1 - line.X2) * (line.X1 - line.X2) +
          (line.Y1 - line.Y2) * (line.Y1 - line.Y2));

      // create the series for the R, G & B components
      var dataR = new List<DataPoint>();
      var dataG = new List<DataPoint>();
      var dataB = new List<DataPoint>();

      // build the charts
      for (double pt = 0; pt < distance; pt++)
      {
        double xPos = line.X1 + (line.X2 - line.X1) * pt / distance;
        double yPos = line.Y1 + (line.Y2 - line.Y1) * pt / distance;

        int xIndex = (int)xPos;
        int yIndex = (int)yPos;

        int pixel = pixelData[xIndex + yIndex * 300];

        // the RGB values are 'packed' into an int, here we unpack them
        byte B = (byte)(pixel & 0xFF);
        pixel >>= 8;
        byte G = (byte)(pixel & 0xFF);
        pixel >>= 8;
        byte R = (byte)(pixel & 0xFF);
        pixel >>= 8;

        // add each datapoint to the series
        dataR.Add(new DataPoint(pt, R));
        dataG.Add(new DataPoint(pt, G));
        dataB.Add(new DataPoint(pt, B));
      }

      // add each series to the chart
      ((LineSeries)chart.Series[0]).ItemsSource = dataR;
      ((LineSeries)chart.Series[1]).ItemsSource = dataG;
      ((LineSeries)chart.Series[2]).ItemsSource = dataB;

    }

    private void image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
      instructions.Visibility = Visibility.Collapsed;
      lButtonDown = true;
      line.X1 = line.X2 = e.GetPosition(grid).X;
      line.Y1 = line.Y2 = e.GetPosition(grid).Y;
    }

    private void Grid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      lButtonDown = false;
    }

    /// <summary>
    /// A value object used to present the data to the chart
    /// </summary>
    public class DataPoint
    {
      public double Location { get; private set; }
      public double Intensity { get; private set; }

      public DataPoint(double location, double intensity)
      {
        Location = location;
        Intensity = intensity;
      }
    }
  }
}
