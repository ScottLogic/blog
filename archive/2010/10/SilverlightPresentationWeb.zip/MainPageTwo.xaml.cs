﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Presentation
{
  public partial class MainPageTwo : UserControl
  {
    private int _slideCount;
    private int _slideNumber = 0;
    private List<FrameworkElement> _slides;
    private bool _buttonsShown = false;
    private DispatcherTimer _timer;

    public MainPageTwo()
    {
      InitializeComponent();

      _timer = new DispatcherTimer();
      _timer.Interval = new TimeSpan(0, 0, 0, 3);
      _timer.Tick += new EventHandler(Timer_Tick);

      Application.Current.Host.Content.FullScreenChanged += new EventHandler(Content_FullScreenChanged);
      
      _slides = SlidePresenter.Items
                     .SelectMany(i => i is ListBox ? ((ListBox)i).Items : i.ToEnumerable())
                     .Cast<FrameworkElement>()
                     .ToList();

      _slideCount = _slides.Count;

      LayoutRoot.AddHandler(Grid.MouseLeftButtonUpEvent,
        new MouseButtonEventHandler(LayoutRoot_MouseLeftButtonUp), false);

    }

    private void Content_FullScreenChanged(object sender, EventArgs e)
    {
      FullScreenButton.Visibility = Application.Current.Host.Content.IsFullScreen ? Visibility.Collapsed : Visibility.Visible;
    }

    /// <summary>
    /// Hide the buttons on timeout
    /// </summary>
    private void Timer_Tick(object sender, EventArgs e)
    {
      if (_buttonsShown)
      {
        _buttonsShown = false;
        ForwardButtonGrid.Hide();
        BackButtonGrid.Hide();

        _timer.Stop();
      }
    }

    /// <summary>
    /// Selects the given slide by ensuring it is selected in its
    /// parent listbox, then recursing
    /// </summary>
    private void SelectSlide(FrameworkElement slide)
    {
      ListBox parentListBox = slide.Parent as ListBox;
      if (parentListBox != null)
      {
        parentListBox.SelectedItem = slide;
        SelectSlide(parentListBox);
      }
    }

    private void FullScreenButton_Click(object sender, MouseButtonEventArgs e)
    {
      Application.Current.Host.Content.FullScreenOptions = System.Windows.Interop.FullScreenOptions.StaysFullScreenWhenUnfocused;
      Application.Current.Host.Content.IsFullScreen = true;
      e.Handled = true;
    }

    private void ForwardButton_Click(object sender, MouseButtonEventArgs e)
    {
      NextSlide();
      RestartTimer();
      e.Handled = true;
    }

    private void BackButton_Click(object sender, MouseButtonEventArgs e)
    {
      PreviousSlide();
      RestartTimer();
      e.Handled = true;
    }

    private void PreviousSlide()
    {
      if (_slideNumber <= 0)
        return;

      _slideNumber--;
      FrameworkElement slide = _slides[_slideNumber];
      SelectSlide(slide);
    }

    private void NextSlide()
    {
      if (_slideNumber >= _slideCount - 1)
        return;

      _slideNumber++;
      FrameworkElement slide = _slides[_slideNumber];
      SelectSlide(slide);
    }

    private void RestartTimer()
    {
      _timer.Stop();
      _timer.Start();
    }

    /// <summary>
    /// Show the navigation buttons on mouse move
    /// </summary>
    private void LayoutRoot_MouseMove(object sender, MouseEventArgs e)
    {
      if (!_buttonsShown)
      {
        _buttonsShown = true;
        ForwardButtonGrid.Show();
        BackButtonGrid.Show();

        _timer.Start();
      }
      else
      {
        RestartTimer();
      }
    }

    private void LayoutRoot_MouseLeftButtonUp(object sender, RoutedEventArgs e)
    {
      NextSlide();
    }

    private void LayoutRoot_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
      PreviousSlide();
      e.Handled = true;
    }

  }
}
