﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Presentation
{
  /// <summary>
  /// A container for elements which 'spins' each one into view.
  /// </summary>
  public class WheelSlidePresenter : ListBox
  {
    public WheelSlidePresenter()
    {
      DefaultStyleKey = typeof(WheelSlidePresenter);

      this.SizeChanged += new SizeChangedEventHandler(WheelSlidePresenter_SizeChanged);
      this.SelectionChanged += new SelectionChangedEventHandler(WheelSlidePresenter_SelectionChanged);
    }

    private void WheelSlidePresenter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      foreach (FrameworkElement element in Items)
      {
        int index = Items.IndexOf(element);
        double angle = (index - SelectedIndex) * 90;

        ListBoxItem listBoxItem = ItemContainerGenerator.ContainerFromItem(element) as ListBoxItem;
        if (listBoxItem == null)
          return;

        RotateTransform trans = listBoxItem.RenderTransform as RotateTransform;

        // rotates each element to the desired location
        var storyboard = listBoxItem.Resources["animation"] as Storyboard;
        var anim = storyboard.Children[0] as DoubleAnimation;
        anim.From = trans.Angle;
        anim.To = angle;
        storyboard.Stop();
        storyboard.Begin();

        // ensure that only the selected element, and the two either side are visible
        listBoxItem.Visibility = Math.Abs(SelectedIndex - index) <= 1 ? Visibility.Visible : Visibility.Collapsed;
      }
    }

    private void WheelSlidePresenter_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      foreach (FrameworkElement element in Items)
      {
        SetElementSize(element);
      }
    }

    protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
    {
      base.PrepareContainerForItemOverride(element, item);

      int index = Items.IndexOf(item);

      // add a rotate transform to the container
      ListBoxItem listBoxItem = element as ListBoxItem;
      RotateTransform trans = new RotateTransform();
      trans.Angle = index * 90;
      listBoxItem.RenderTransform = trans;

      // add a storyboard to animate the above rotate transform
      Storyboard storyboard = new Storyboard();
      var anim = new DoubleAnimation()
      {
        EasingFunction = new SineEase()
      };
      Storyboard.SetTarget(anim, trans);
      Storyboard.SetTargetProperty(anim, new PropertyPath("Angle"));
      storyboard.Children.Add(anim);
      listBoxItem.Resources.Add("animation", storyboard);

      listBoxItem.Visibility = Math.Abs(SelectedIndex - index) <= 1 ? Visibility.Visible : Visibility.Collapsed;

      SetElementSize(item as FrameworkElement);
    }


    private void SetElementSize(FrameworkElement element)
    {
      element.Width = this.ActualWidth;
      element.Height = this.ActualHeight;
    }
  }
}
