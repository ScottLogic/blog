﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Data;

namespace Presentation
{
  /// <summary>
  /// Renders a collection of elements, with animated transiions between each.
  /// </summary>
  public class PanormicSlidePresenter : ListBox
  {
    private ItemsPresenter _itemsPresenter;

    private FrameworkElement _title;

    #region Title Dependency Property

    public string Title
    {
      get { return (string)GetValue(TitleProperty); }
      set { SetValue(TitleProperty, value); }
    }

    public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title",
      typeof(string), typeof(PanormicSlidePresenter), new PropertyMetadata(""));

    #endregion

    public PanormicSlidePresenter() 
    {
      DefaultStyleKey = typeof(PanormicSlidePresenter);

      this.SelectionChanged += new SelectionChangedEventHandler(PanormicSlidePresenter_SelectionChanged);
      this.SizeChanged += new SizeChangedEventHandler(PanormicSlidePresenter_SizeChanged);
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();

      _itemsPresenter = this.GetTemplateChild("ItemsPresenter") as ItemsPresenter;
      _title = this.GetTemplateChild("Title") as FrameworkElement;
    }

    private void PanormicSlidePresenter_SizeChanged(object sender, SizeChangedEventArgs e)
    {
      // scale each slide
      foreach (FrameworkElement element in Items)
      {
        SetElementSize(element);
      }

      // offset to display the correct slide
      Canvas.SetLeft(_itemsPresenter, GetSlideOffset());

      // scale and offset the title
      _title.Width = ActualWidth * 1.5;
      Canvas.SetLeft(_title, GetTitleOffset());
    }

    private double GetTitleOffset()
    {
      return -((ActualWidth / 2) * SelectedIndex / (Items.Count-1));
    }

    private double GetSlideOffset()
    {
      return -SelectedIndex * ActualWidth;
    }

    /// <summary>
    /// Animates the current slide into view
    /// </summary>
    private void ShowCurrentSlide()
    {
      AnimateElementTo(_itemsPresenter, GetSlideOffset());
      AnimateElementTo(_title, GetTitleOffset());
    }

    /// <summary>
    /// Animates the given element to the given canvas offset
    /// </summary>
    private void AnimateElementTo(FrameworkElement element, double canvasLeft)
    {
      Storyboard anim = element.Resources["animation"] as Storyboard;

      var dblAnim = anim.Children[0] as DoubleAnimation;
      dblAnim.From = Canvas.GetLeft(element);
      dblAnim.To = canvasLeft;
      anim.Stop();

      Storyboard.SetTarget(anim, element);
      anim.Begin();
    }

    private void PanormicSlidePresenter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (_itemsPresenter == null)
        return;

      ShowCurrentSlide();
    }

    protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
    {
      base.PrepareContainerForItemOverride(element, item);

      // scale the elements as they are added
      SetElementSize(item as FrameworkElement);
    }

    /// <summary>
    /// Sets the size of the given element to match the size of this container
    /// </summary>
    private void SetElementSize(FrameworkElement element)
    {
      element.Width = this.ActualWidth;
      element.Height = this.ActualHeight;
    }
  }
}
