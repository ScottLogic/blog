﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Threading;

namespace Presentation
{
    public partial class MainPage : PhoneApplicationPage
    {
        private int _slideCount;
        private int _slideNumber = 0;
        private List<FrameworkElement> _slides;

        public MainPage()
        {
            InitializeComponent();

            _slides = SlidePresenter.Items
                           .SelectMany(i => i is ListBox ? ((ListBox)i).Items : i.ToEnumerable())
                           .Cast<FrameworkElement>()
                           .ToList();

            _slideCount = _slides.Count;


        }


        /// <summary>
        /// Selects the given slide by ensuring it is selected in its
        /// parent listbox, then recursing
        /// </summary>
        private void SelectSlide(FrameworkElement slide)
        {
            ListBox parentListBox = slide.Parent as ListBox;
            if (parentListBox != null)
            {
                parentListBox.SelectedItem = slide;
                SelectSlide(parentListBox);
            }
        }



        private void PreviousSlide()
        {
            if (_slideNumber <= 0)
                return;

            _slideNumber--;
            FrameworkElement slide = _slides[_slideNumber];
            SelectSlide(slide);
        }

        private void NextSlide()
        {
            if (_slideNumber >= _slideCount - 1)
                return;

            _slideNumber++;
            FrameworkElement slide = _slides[_slideNumber];
            SelectSlide(slide);
        }

        private void BackGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            PreviousSlide();
        }

        private void ForwardGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            NextSlide();
        }

    }
}