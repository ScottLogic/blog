﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;
using Visiblox.Charts.Primitives;
using System.Collections.Generic;

namespace VisibloxSplineSeries
{
  /// <summary>
  /// A Visiblox chart series that uses a splin to render a smoothed series.
  /// </summary>
  public class SplineSeries : ChartSeriesBase
  {
    #region Tension DP

    /// <summary>
    /// Uniform tension of the cardinal spline.
    /// </summary>
    public double Tension
    {
      get { return (double)GetValue(TensionProperty); }
      set { SetValue(TensionProperty, value); }
    }

    public static readonly DependencyProperty TensionProperty =
        DependencyProperty.Register("Tension", typeof(double), typeof(SplineSeries),
        new PropertyMetadata(2.0, OnTensionPropertyChanged));

    private static void OnTensionPropertyChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
    {
      ((SplineSeries)d).OnTensionPropertyChanged(e);
    }

    private void OnTensionPropertyChanged(DependencyPropertyChangedEventArgs e)
    {
      Invalidate();
    }

    #endregion


    public SplineSeries()
    {
      DefaultStyleKey = typeof(SplineSeries);
    }

    /// <summary>
    /// Uses the X & Y axes to map the data values to their required render position.
    /// </summary>
    public List<Point> GetRenderPoints()
    {
      var renderPoints = new List<Point>();
      foreach (IDataPoint point in this.DataSeries)
      {
        double xPos = XAxis.GetDataValueAsRenderPositionWithoutZoom(point.X);
        double yPos = YAxis.GetDataValueAsRenderPositionWithoutZoom(point.Y);
        renderPoints.Add(new Point(xPos, yPos));
      }
      return renderPoints;
    }
      
    protected override void InvalidateInternal()
    {
      RootZoomCanvas.Children.Clear();
      
      // obtain the render position of each point
      var renderPoints = GetRenderPoints();

      // create the bezier points as per:
      // http://www.codeproject.com/KB/silverlight/MapBezier.aspx
      PointCollection bezierPoints = GetBezierPoints(renderPoints, Tension);

      // create the figure composed of bezier segments
      Path path = new Path();
      PathGeometry geometry = new PathGeometry();
      PathFigure figure = new PathFigure();
      figure.StartPoint = bezierPoints[0];
      for (int i = 1; i < bezierPoints.Count; i += 3)
      {
        figure.Segments.Add(new BezierSegment()
        {
          Point1 = bezierPoints[i],       
          Point2 = bezierPoints[i + 1],   
          Point3 = bezierPoints[i + 2]    
        });
      }

      geometry.Figures.Add(figure);
      path.Data = geometry;
      path.StrokeThickness = 2;
      path.Stroke = new SolidColorBrush(Colors.Black);
      ZoomCanvas.SetIsScaledPath(path, true);
      RootZoomCanvas.Children.Add(path);

      // show how the spline is constructed
      ShowSplineConstruction(bezierPoints);
      
      // render the datapoints
      foreach (var renderPoint in renderPoints)
      {
        Ellipse el = CreateEllipse(7);
        RootZoomCanvas.Children.Add(el);
        ZoomCanvas.SetElementPosition(el, renderPoint);
      }
    }

    /// <summary>
    /// Renders the control points for each Bezier curve
    /// </summary>
    private void ShowSplineConstruction(PointCollection bezierPoints)
    {
      Point previousPoint = bezierPoints[0];
      for (int i = 1; i < bezierPoints.Count; i += 3)
      {
        var el = CreateEllipse(5);
        RootZoomCanvas.Children.Add(el);
        ZoomCanvas.SetElementPosition(el, bezierPoints[i]);

        el = CreateEllipse(5);
        RootZoomCanvas.Children.Add(el);
        ZoomCanvas.SetElementPosition(el, bezierPoints[i + 1]);

        var line = CreateLine(previousPoint, bezierPoints[i]);
        ZoomCanvas.SetIsScaledPath(line, true);
        RootZoomCanvas.Children.Add(line);

        line = CreateLine(bezierPoints[i+1], bezierPoints[i+2]);
        ZoomCanvas.SetIsScaledPath(line, true);
        RootZoomCanvas.Children.Add(line);

        previousPoint = bezierPoints[i + 2];
      }
    }

    /// <summary>
    /// Creates a line path that joins the given points
    /// </summary>
    private Path CreateLine(Point startPoint, Point endPoint)
    {
      Path path = new Path();
      PathGeometry geometry = new PathGeometry();
      PathFigure figure = new PathFigure();

      figure.StartPoint = startPoint;
      figure.Segments.Add(new LineSegment()
      {
        Point = endPoint
      });

      geometry.Figures.Add(figure);
      path.Data = geometry;
      path.Stroke = new SolidColorBrush(Colors.Red);
      return path;
    }

    /// <summary>
    /// Creates an ellipse of the given size.
    /// </summary>
    private Ellipse CreateEllipse(double size)
    {
      return new Ellipse()
        {
          Stroke = new SolidColorBrush(Colors.Black),
          StrokeThickness = 1.0,
          Fill = new SolidColorBrush(Colors.White),
          Width = size,
          Height = size,
          RenderTransform = new TranslateTransform()
          {
            X = -(size/2),
            Y = -(size/2)
          }
        };
    }

    /// <summary>
    /// Calculates scaled derivative of a point in a point collection.
    /// </summary>
    /// <param name="pts">Points on the curve.</param>
    /// <param name="i">Point no to calculate control point for.</param>
    /// <param name="a">Tension</param>        
    /// <returns></returns>
    private Point GetDerivative(List<Point> pts, int i, double a)
    {
      if (pts.Count < 2)
        throw new ArgumentOutOfRangeException("pts", "MapBezier must contain at least two points.");

      if (i == 0)
      {
        // First point.
        return new Point((pts[1].X - pts[0].X) / a, (pts[1].Y - pts[0].Y) / a);
      }
      if (i == pts.Count - 1)
      {
        // Last point.
        return new Point((pts[i].X - pts[i - 1].X) / a, (pts[i].Y - pts[i - 1].Y) / a);
      }

      return new Point((pts[i + 1].X - pts[i - 1].X) / a, (pts[i + 1].Y - pts[i - 1].Y) / a);
    }

    /// <summary>
    /// Calculates first control point of a Bézier curve.
    /// </summary>
    /// <param name="pts">Points on the curve.</param>
    /// <param name="i">Point no to calculate control point for.</param>
    /// <param name="a">Tension</param>
    /// <returns></returns>
    /// <remarks>Formula: B1i = Pi + Pi' / 3</remarks>
    private Point GetB1(List<Point> pts, int i, double a)
    {
      var drv = GetDerivative(pts, i, a);
      return new Point(pts[i].X + drv.X / 3, pts[i].Y + drv.Y / 3);
    }

    /// <summary>
    /// Calculates second control point of a Bézier curve.
    /// </summary>
    /// <param name="pts">Points on the curve.</param>
    /// <param name="i">Point no to calculate control point for.</param>
    /// <param name="a">Tension</param>
    /// <returns></returns>
    /// <remarks>Formula: B2i = P[i + 1] - P'[i + 1] / 3</remarks>
    private Point GetB2(List<Point> pts, int i, double a)
    {
      var drv = GetDerivative(pts, i + 1, a);
      return new Point(pts[i + 1].X - drv.X / 3, pts[i + 1].Y - drv.Y / 3);
    }

    /// <summary>
    /// Calculates Bézier control points for a curve that contains given set of points.
    /// </summary>
    /// <param name="pts">Points on the curve.</param>
    /// <param name="tension">Tension.</param>
    /// <returns></returns>
    private PointCollection GetBezierPoints(List<Point> pts, double tension)
    {
      PointCollection ret = new PointCollection();

      for (int i = 0; i < pts.Count; i++)
      {
        // for first point append as is.
        if (i == 0)
        {
          ret.Add(pts[0]);
          continue;
        }

        // for each point except first and last get B1, B2. next point. 
        // Last point do not have a next point.
        ret.Add(GetB1(pts, i - 1, tension));
        ret.Add(GetB2(pts, i - 1, tension));
        ret.Add(pts[i]);
      }

      return ret;
    }
  }
}
