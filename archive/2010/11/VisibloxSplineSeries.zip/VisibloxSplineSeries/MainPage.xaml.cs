﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Visiblox.Charts;

namespace VisibloxSplineSeries
{
  public partial class MainPage : UserControl
  {
    private Random rand = new Random();

    public MainPage()
    {
      InitializeComponent();

      CreateRandomSeries();

      // permit zooming
      chart.Behaviour = new ZoomBehaviour();
    }

    private void CreateRandomSeries()
    {
      var dataSeries = new DataSeries<double, double>();
      for (int i = 0; i < 10; i++)
      {
        dataSeries.Add(new DataPoint<double, double>(i, rand.NextDouble()));
      }
      chart.Series[0].DataSeries = dataSeries;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      CreateRandomSeries();
    }

  }
}
