﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace ItemsControlGrid
{
  public partial class MainPage : UserControl
  {
    ObservableCollection<ModelObject> data = new ObservableCollection<ModelObject>(new ModelObject[]
      {
        new ModelObject()
        {
          Item = "Sausages",
          Quantity = 4
        },
        new ModelObject()
        {
          Item = "Eggs",
          Quantity = 12
        },
        new ModelObject()
        {
          Item = "Milk",
          Quantity = 1
        },
        new ModelObject()
        {
          Item = "Bread",
          Quantity = 2
        },
      });

    public MainPage()
    {
      InitializeComponent();
      
      this.DataContext = data;
    }

    private void ButtonAddItem_Click(object sender, RoutedEventArgs e)
    {
      data.Add(new ModelObject()
        {
          Item = "Cheese",
          Quantity = 4
        });
    }

    private void ButtonDeleteItem_Click(object sender, RoutedEventArgs e)
    {
      if (data.Count>0) 
        data.RemoveAt(0);
    }
  }

  public class ModelObject : INotifyPropertyChanged
  {
    private string _item;

    private int _quantity;

    public string Item
    {
      get { return _item; }
      set { _item = value; OnPropertyChanged("Item"); }
    }

    public int Quantity
    {
      get { return _quantity; }
      set { _quantity = value; OnPropertyChanged("Quantity"); }
    }


    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string property)
    {
      if (PropertyChanged!=null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(property));
      }
    }
  }
}
