﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ModalDialogDemo
{
    /// <summary>
    /// An interface which provides a host for some content which should be rendered
    /// as a modal dialog
    /// </summary>
    public interface IModalDialogHost
    {
        /// <summary>
        /// Gets or sets the content to host
        /// </summary>
        UserControl HostedContent { get; set; }

        /// <summary>
        /// Gets the dialog title
        /// </summary>
        string Title { set; }

        /// <summary>
        /// Gets the dialog result (i.e. OK, Cancel)
        /// </summary>
        bool? DialogResult { get; }

        /// <summary>
        /// Shows the dialog, invoking the given callback when it is closed
        /// </summary>
        void Show(DialogClosed closedCallback);        
    }

    /// <summary>
    /// A callback which is invoked when a modal dialog is closed.
    /// </summary>
    public delegate void DialogClosed(IModalDialogHost host);
}
