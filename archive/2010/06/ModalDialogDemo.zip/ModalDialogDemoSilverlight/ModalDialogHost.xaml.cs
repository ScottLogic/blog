﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ModalDialogDemo
{
    /// <summary>
    /// A Silverlight implementation of IModalDialogHost
    /// </summary>
    public partial class ModalDialogHost : ChildWindow, IModalDialogHost
    {
        public ModalDialogHost()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        public UserControl HostedContent
        {
            get
            {
                return (UserControl)contentHost.Content;
            }
            set
            {
                contentHost.Content = value;
            }
        }

        public void Show(DialogClosed closedCallback)
        {
            Show();
            Closed += (s, e) =>
                {
                    closedCallback(this);
                };
        }
        
        public new string Title
        {
            set { base.Title = value; }
        }
    }
}

