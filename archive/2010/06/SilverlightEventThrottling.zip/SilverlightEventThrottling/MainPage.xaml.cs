﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Threading;

namespace SilverlightEventThrottling
{
  public partial class MainPage : UserControl
  {
    private double _thickness = 1.0;

    private double _angle = 0;

    private Point? _lastPosition = null;

    private DispatcherTimer _timer = new DispatcherTimer();

    public MainPage()
    {
      InitializeComponent();

      // standard mouse move event handling
      // uncomment this line to see the effect of not throttling the mouse events
      //MouseHandler.MouseMove += new MouseEventHandler(MainPage_MouseMove);

      // throttled mouse move event handling
      var throttledEvent = new ThrottledMouseMoveEvent(MouseHandler);
      throttledEvent.ThrottledMouseMove += new MouseEventHandler(ThrottledEvent_ThrottledMouseMove);

      var throttledWheelEvent = new ThrottledMouseWheelEvent(MouseHandler);
      throttledWheelEvent.ThrottledMouseWheel += new EventHandler<ThrottledMouseWheelEventArgs>(ThrottledWheelEvent_ThrottledMouseWheel);

      // starts a time
      _timer.Interval = new TimeSpan(0, 0, 0, 0, 10);
      _timer.Tick += new EventHandler(Timer_Tick);
      _timer.Start();
    }

    private void ThrottledWheelEvent_ThrottledMouseWheel(object sender, ThrottledMouseWheelEventArgs e)
    {
      Debug.WriteLine("Throttled Event e.Delta: " + e.Delta.ToString());
      _thickness += (double)e.Delta / 2000;
      if (_thickness < 0.5)
        _thickness = 0.5;

      if (_thickness > 10)
        _thickness = 10;

      if (LineContainer.Children.Count > 0)
      {
        Line line = LineContainer.Children[LineContainer.Children.Count - 1] as Line;
        line.StrokeThickness = _thickness;
      }

    }

    private void ThrottledEvent_ThrottledMouseMove(object sender, MouseEventArgs e)
    {      
      AddNewLine(e.GetPosition(this));
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
      RotateLines();
    }

    private void MainPage_MouseMove(object sender, MouseEventArgs e)
    {
      // uncomment this line to see the effect of not throttling the mouse events
      //AddNewLine(e.GetPosition(this));
    }

    /// <summary>
    /// Adds a new line at the given position
    /// </summary>
    private void AddNewLine(Point position)
    {
      if (_lastPosition != null)
      {
        // find the angle in which the mouse is moving
        double angleOfMovement = RaidansToRadians(Math.Atan2(
            _lastPosition.Value.Y - position.Y, _lastPosition.Value.X - position.X)) + 90;

        // move our current angle slightly in this direction
        double diff = DifferenceBetweenAngles(_angle, angleOfMovement);
        _angle = _angle + DifferenceBetweenAngles(_angle, angleOfMovement) / 10;

        // create a line 
        double dx = Math.Sin(DegreesToRadians(_angle)) * diff;
        double dy = Math.Cos(DegreesToRadians(_angle)) * diff;
        Line line = new Line()
        {
          X1 = position.X + dx,
          Y1 = position.Y + dy,
          X2 = position.X - dx,
          Y2 = position.Y - dy,
          Opacity = 0.7,
          Stroke = new SolidColorBrush(Colors.Black),
          StrokeThickness = _thickness,
          Tag = new Data() { Angle = _angle, Length = diff, Position = position }
        };

        // add to canvas
        LineContainer.Children.Add(line);

        // rotates all the lines that are currently displayed
        RotateLines();
      }
      _lastPosition = position;
    }

    /// <summary>
    /// Rotate, fades, copies the line thickness and enforces an upper bound of 2000 lines
    /// </summary>
    private void RotateLines()
    {
      for (int i = 0; i < LineContainer.Children.Count; i++)
      {
        Line line = LineContainer.Children[i] as Line;

        Data data = (Data)line.Tag;
        double angleDelta = Math.Min((1 / data.Length) * 5, 4);
        data.Angle += angleDelta;
        data.Length -= (data.Length * 0.001);

        double dx = Math.Sin(DegreesToRadians(data.Angle)) * data.Length;
        double dy = Math.Cos(DegreesToRadians(data.Angle)) * data.Length;
        line.X1 = data.Position.X + dx;
        line.Y1 = data.Position.Y + dy;
        line.X2 = data.Position.X - dx;
        line.Y2 = data.Position.Y - dy;

        if (i < LineContainer.Children.Count - 1)
        {
          Line nextLine = LineContainer.Children[i + 1] as Line;
          line.StrokeThickness = nextLine.StrokeThickness;
        }

        if (line.Opacity > 0.1)
          line.Opacity -= 0.0015;
      }

      if (LineContainer.Children.Count > 2000)
      {
        LineContainer.Children.RemoveAt(0);
      }

      lineCount.Text = LineContainer.Children.Count.ToString();
    }

    private double DegreesToRadians(double angle)
    {
      return angle * Math.PI / 180;
    }

    private double RaidansToRadians(double angle)
    {
      return angle / (Math.PI / 180);
    }

    private double DifferenceBetweenAngles(double firstAngle, double secondAngle)
    {
      double difference = secondAngle - firstAngle;
      while (difference < -180) difference += 360;
      while (difference > 180) difference -= 360;
      return difference;
    }


    /// <summary>
    /// Removes all of the lines
    /// </summary>
    private void Button_Click(object sender, RoutedEventArgs e)
    {
      LineContainer.Children.Clear();
    }

    /// <summary>
    /// A value object for storing Line data
    /// </summary>
    private class Data
    {
      public double Angle;
      public double Length;
      public Point Position;
    }

  }
}
