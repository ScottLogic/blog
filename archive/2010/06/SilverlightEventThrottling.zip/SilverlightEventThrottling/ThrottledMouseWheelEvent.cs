﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace SilverlightEventThrottling
{
  /// <summary>
  /// A class the adapts the MouseWheel event for a UIElement to ensure that 
  /// multiple events are not handled and acted upon without the UI being re-rendered.
  /// </summary>
  public class ThrottledMouseWheelEvent
  {
    #region fields

    /// <summary>
    /// Source element for the MouseWheel event
    /// </summary>
    private UIElement _source;

    /// <summary>
    /// The combined mouse-wheel delta
    /// </summary>
    private int _combinedDelta;

    /// <summary>
    /// A flag that indicates that a ThrottledMouseWheel event has been raised and we are waiting for
    /// the next Rendering event.
    /// </summary>
    private bool _awaitingRender = false;

    #endregion

    #region public API

    /// <summary>
    /// A 'throttled' MouseWheel event
    /// </summary>
    public event EventHandler<ThrottledMouseWheelEventArgs> ThrottledMouseWheel;


    public ThrottledMouseWheelEvent(UIElement source)
    {
      _source = source;
      _source.MouseWheel += new MouseWheelEventHandler(Source_MouseWheel);
    }

    #endregion

    #region private methods

    private void CompositionTarget_Rendering(object sender, EventArgs e)
    {
      Debug.WriteLine("CompositionTarget.Rendering Fired");

      if (_awaitingRender)
      {
        // if we have stored delta values, raise another ThrottledMouseWheel events
        if (_combinedDelta != 0)
        {
          OnThrottledMouseWheel(_combinedDelta);
        }
        _combinedDelta = 0;
        _awaitingRender = false;
      }

      CompositionTarget.Rendering -= CompositionTarget_Rendering;
    }

    /// <summary>
    /// Handles mouse wheel events from the source, either firing the ThrottledMouseWheel event,
    /// or queueing the event until a render has occured.
    /// </summary>
    private void Source_MouseWheel(object sender, MouseWheelEventArgs e)
    {
      Debug.WriteLine("Mousewheel Event e.Delta: " + e.Delta.ToString());
      if (!_awaitingRender)
      {
        // if we are not awaiting a render as a result of a previously handled event
        // raise a ThrottledMouseWheel event, and add a Rendering handler so that
        // we can determine when this event has been acted upon.
        OnThrottledMouseWheel(e.Delta);
        _combinedDelta = 0;
        _awaitingRender = true;
        CompositionTarget.Rendering += CompositionTarget_Rendering;
      }
      else
      {
        // if we are awaiting a render, store this delta value
        _combinedDelta += e.Delta;
      }
    }

    /// <summary>
    /// Raises the ThrottledMouseWheel event.
    /// </summary>
    protected void OnThrottledMouseWheel(int delta)
    {
      if (ThrottledMouseWheel != null)
      {
        ThrottledMouseWheel(_source, new ThrottledMouseWheelEventArgs()
        {
          Delta = delta
        });
      }
    }

    #endregion
  }

  /// <summary>
  /// Provides data for the ThrottledMouseWheel event.
  /// </summary>
  public class ThrottledMouseWheelEventArgs : EventArgs
  {
    public int Delta { get; internal set; }
  }

}
