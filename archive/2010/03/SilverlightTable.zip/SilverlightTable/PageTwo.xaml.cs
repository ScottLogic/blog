﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Windows.Data;
using System.IO;
using System.Xml.Linq;

namespace SilverlightTable
{
  public partial class PageTwo : UserControl
  {
    private RowIndexConverter _rowIndexConverter = new RowIndexConverter();

    public PageTwo()
    {
      InitializeComponent();

      // add some XML data to the text control
      Stream s = this.GetType().Assembly.
          GetManifestResourceStream(this.GetType(), "data.xml");
      using (StreamReader reader = new StreamReader(s))
      {
        _xmlInput.Text = reader.ReadToEnd();
      }

      // copy the data to the grid
      XmlToGrid();
    }

    /// <summary>
    /// Converts the contents of the grid into XML
    /// </summary>
    private void GridToXML()
    {
      var data = (SortableCollectionView)_dataGrid.ItemsSource;
      Row firstRow = data[0];

      // create the columns from the first row
      XElement xml = new XElement("data");
      xml.Add(new XElement("columns",
        firstRow.ColumnNames.Select(col => new XElement("column",
          new XAttribute("name", col)))));

      // add the rows
      XElement rows = new XElement("rows");
      foreach (Row row in data)
      {
        rows.Add(new XElement("row",
          firstRow.ColumnNames.Select(col =>
            new XElement("cell", row[col]))));
      }
      xml.Add(rows);

      _xmlInput.Text = xml.ToString();
    }

    /// <summary>
    /// Copies the XML contents of the textbox into the DataGrid
    /// </summary>
    private void XmlToGrid()
    {
      // clear the grid
      _dataGrid.ItemsSource = null;
      _dataGrid.Columns.Clear();

      // grab the xml into a XDocument
      XDocument xmlDoc = XDocument.Parse(_xmlInput.Text);

      // find the columns
      List<string> columnNames = xmlDoc.Descendants("column")
                                       .Attributes("name")
                                       .Select(a => a.Value)
                                       .ToList();

      // add them to the grid
      foreach (string columnName in columnNames)
      {
        _dataGrid.Columns.Add(CreateColumn(columnName));
      }

      SortableCollectionView data = new SortableCollectionView();

      // add the rows
      var rows = xmlDoc.Descendants("row");
      foreach (var row in rows)
      {
        Row rowData = new Row();
        int index = 0;
        var cells = row.Descendants("cell");
        foreach (var cell in cells)
        {
          rowData[columnNames[index]] = cell.Value;
          index++;
        }
        data.Add(rowData);
      }

      _dataGrid.ItemsSource = data;
    }

    /// <summary>
    /// Creates a column that binds to a property of the given name
    /// using the RowIndexConverter
    /// </summary>
    private DataGridColumn CreateColumn(string property)
    {
      return new DataGridTextColumn()
      {
        CanUserSort = true,
        Header = property,
        SortMemberPath = property,
        IsReadOnly = false,
        Binding = new Binding("Data")
        {
          Converter = _rowIndexConverter,
          ConverterParameter = property
        }
      };
    }

    private void ButtonGridToXML_Click(object sender, RoutedEventArgs e)
    {
      GridToXML();
    }

    private void ButtonXMLToGrid_Click(object sender, RoutedEventArgs e)
    {
      XmlToGrid();
    }

  }
}
