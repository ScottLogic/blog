﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Text.RegularExpressions;

namespace SilverlightTable
{
  /// <summary>
  /// Converter for formatting an age by appending a "yrs" suffix.
  /// </summary>
  public class AgeValueConverter : IValueConverter
  {
    #region IValueConverter Members

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      return string.Format("{0} yrs", value);
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      // strip out any non-numeric characters then parse.
      string strValue = value as string;
      strValue = Regex.Replace(strValue, "[^0-9]", "");
      return Int32.Parse(value as string);
    }

    #endregion
  }
}
