﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CustomFonts
{
    public partial class MainPage : UserControl
    {
        private bool _fontIsDynamicallyLoaded = false;

        public MainPage()
        {
            InitializeComponent();
        }

        private void ChangeFontButton_Click(object sender, RoutedEventArgs e)
        {
            if (_fontIsDynamicallyLoaded)
            {
                ChangeFontToLocalCustomFont();
                ChangeFontButton.Content = "Change font to a a dynamically loaded one";
            }
            else
            {
                ChangeFontToDynamicallyLoaded();
                ChangeFontButton.Content = "Change font to a custom font stored in the XAP";
            }
            _fontIsDynamicallyLoaded = !_fontIsDynamicallyLoaded;
            
        }

        void wc_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            // Once the font stream is read, set the FontSource to this
            MainText.FontSource = new FontSource(e.Result);
            MainText.FontFamily = new FontFamily("Baroque Antique Script");
        }

        private void ChangeFontToDynamicallyLoaded()
        {
            // Start downloading the font
            WebClient wc = new WebClient();
            wc.OpenReadAsync(new Uri("http://www.scottlogic.co.uk/blog/gergely/wp-content/uploads/2010/03/BaroqueAntiqueScript.zip", UriKind.Absolute));
            wc.OpenReadCompleted += new OpenReadCompletedEventHandler(wc_OpenReadCompleted);
            
        }

        private void ChangeFontToLocalCustomFont()
        {
            MainText.FontFamily = new FontFamily("Fonts/AAJAX.TTF#AajaxSurrealFreak");
        }
    }
}
